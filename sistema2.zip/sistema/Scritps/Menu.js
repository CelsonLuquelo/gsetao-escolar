         function atualizarHora() {
            const agora = new Date();
            const hora = agora.getHours().toString().padStart(2, '0');
            const minutos = agora.getMinutes().toString().padStart(2, '0');
            const segundos = agora.getSeconds().toString().padStart(2, '0');
            const dia = agora.getDate().toString().padStart(2, '0');
            const mes = (agora.getMonth() + 1).toString().padStart(2, '0');
            const ano = agora.getFullYear();
            
            document.getElementById('recebHora').innerText = `${dia}/${mes}/${ano} - ${hora}:${minutos}:${segundos}`;
        }
        
        // Atualizar a hora a cada segundo
        setInterval(atualizarHora, 1000);
        atualizarHora(); // Chamar imediatamente


 
 
 
 // ====== CONTROLE DE MENU MOBILE ======
                const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const sidebar = document.getElementById('sidebar');
        const mobileOverlay = document.getElementById('mobileOverlay');
        const toggleBtn = document.getElementById('toggle-btn');
		const iconBotton = document.getElementById('icon-botton');

        function toggleMobileMenu() {
            sidebar.classList.toggle('mobile-open');
            mobileOverlay.classList.toggle('active');
            
            // Mudança do ícone
            const icon = mobileMenuToggle.querySelector('i');
            if (sidebar.classList.contains('mobile-open')) {
				iconBotton.style.fontSize = "30px";
                icon.className = 'fas fa-times';
				iconBotton.className = 'fas fa-times';
            } else {
                icon.className = 'fas fa-bars';
				iconBotton.className = 'fas fa-bars';
            }
        }
 
        iconBotton.addEventListener('click', toggleMobileMenu);
        mobileMenuToggle.addEventListener('click', toggleMobileMenu);
        mobileOverlay.addEventListener('click', toggleMobileMenu);

        // Fechar menu ao clicar em um link (mobile)
        const sidebarLinks = document.querySelectorAll('#sidebar a');
        sidebarLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth <= 768) {
                    toggleMobileMenu();
                }
            });
        });	