const cadastroDeUsuario=document.getElementById("cadastrar");



//Editar Funcionários
function editarUsuario(email) {

    cadastroDeUsuario.classList.toggle("active");
    if(cadastroDeUsuario.classList.contains("active")){
    cadastroDeUsuario.innerHTML=`
    <div id="fundoCadastro">
    <form action="../Config/alterar_Usuario.php" method="POST">
    <button class="SairAlter fa-solid fa-xmark" type="button" onclick="sairAlter()"></button>
    <h3>Editar Funcionário</h3>
        <input type="hidden" value="${email.id_usuario}" name="id_usuario" id="id_usuario">
         <div class="grupForms">
            <div class="form-group">
                <label for="nome">Nome:</label>
                <input type="text" id="nome" value="${email.nome}" name="nome" required>
            </div>
            <div class="form-group">
              <label for="email">Email:</label>
              <input type="email" id="email" value="${email.email}" name="email" required>
          </div>
          </div>
           <div class="grupForms">
             <div class="form-group">
                  <label for="senha">Senha:</label>
                  <input type="password" id="senha" value="${email.senha}" name="senha" required>
              </div>
              <div class="form-group">
                  <label for="nivel_acesso">Nível de Acesso:</label>
                  <select id="nivel_acesso" name="nivel_acesso" value="${email.nivel_acesso}">
                      <option value="Administrador">Administrador</option>
                       <option value="secretario">Secretário</option>
                  </select>
            </div>
          </div>
        <button type="submit">Salvar</button>
    </form>
        </div>`;


    }else{
    cadastroDeUsuario.innerHTML="";
    }
    
}
const excluir = document.getElementById("fundo");
function sairAlter(){
  excluir.style.display ='none';
  cadastroDeUsuario.classList.remove("active");
}
function ExcluirUsuario(id){
    excluir.style.display ='block';
    if(excluir.style.display === "block"){
       document.getElementById("ContExcluir").innerHTML=`
         <button class="SairAlter fa-solid fa-xmark" onclick="sairAlter()"></button>
        <h2><i class="fa-solid fa-trash"></i> Excluir usuario</h2>
        <p>Tem certeza que deseja excluir este usuario?</p>
       <a href='gerenciarUsuario.php?delete=${id}'>Excluir</a>`;
    }else{
       document.getElementById("ContExcluir").innerHTML=''; 
    }
}
document.getElementById("cadastrarUsuario").addEventListener("click", function(){
   cadastroDeUsuario.classList.toggle("active");
   if(cadastroDeUsuario.classList.contains("active")){
    cadastroDeUsuario.innerHTML=` 
    <div id="fundoCadastro">
    <form action="gerenciarUsuario.php" method="POST">
    <button class="SairAlter fa-solid fa-xmark" type="button" onclick="sairAlter()"></button>
    <h3>Cadastrar Funcionário</h3>
        <input type="hidden" name="id_usuario" id="id_usuario">
         <div class="grupForms">
          <div class="form-group">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" required>
        </div>
          <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
         </div>
          </div>
          <div class="grupForms">
          <div class="form-group">
        <label for="senha">Senha:</label>
        <input type="password" id="senha" name="senha" required>
        </div>
          <div class="form-group">
        <label for="nivel_acesso">Nível de Acesso:</label>
        <select id="nivel_acesso" name="nivel_acesso">
            <option value="administrador">Administrador</option>
             <option value="secretario">Secretário</option>
        </select>
         </div>
          </div>
        <button type="submit">Salvar</button>
    </form>
        </div>`;
   }else{
    cadastroDeUsuario.innerHTML="";
   }
});

