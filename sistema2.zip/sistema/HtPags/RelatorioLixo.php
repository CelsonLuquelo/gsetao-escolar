<?php 
include '../Config/conexaoBD.php';

// Iniciar sessão e verificar login
session_start();
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}

// Definir fuso horário para facilitar relatórios por data
date_default_timezone_set('Africa/Luanda');

// Funções auxiliares para formatação de valores
function formatMoney($value) {
    return number_format($value, 2, ',', '.') . ' Kz';
}

// Obter informações básicas da escola (constantes usadas em vários cálculos)
$info_basicas = $pdo->query("SELECT * FROM informacoes_basicas WHERE id = 1")->fetch(PDO::FETCH_ASSOC);
$multa_percentual = isset($info_basicas['multa_percentual']) ? $info_basicas['multa_percentual'] : 0;
$valor_matricula = isset($info_basicas['valor_Matricula']) ? $info_basicas['valor_Matricula'] : 0;
$valor_uniforme = isset($info_basicas['valor_uniforme']) ? $info_basicas['valor_uniforme'] : 0;
$valor_cartao = isset($info_basicas['valor_cartao']) ? $info_basicas['valor_cartao'] : 0;
$valor_estagio = isset($info_basicas['valor_estagio']) ? $info_basicas['valor_estagio'] : 0;
$valor_declaracao = isset($info_basicas['valor_declaracao']) ? $info_basicas['valor_declaracao'] : 0;
$valor_certificado = isset($info_basicas['valor_certificado']) ? $info_basicas['valor_certificado'] : 0;

// Data atual
$diaAtual = date('d');
$mesAtual = date('m');
$anoAtual = date('Y');

// CÁLCULOS FINANCEIROS
// ===========================================

// Quantidade total de alunos (usado em vários cálculos)
$total_alunos = $pdo->query("SELECT COUNT(id_aluno) FROM alunos")->fetchColumn() ?? 0;

// Multas acumuladas - todas as multas aplicadas, independentemente de pagamentos
$multa_acumulada = $pdo->query("SELECT COALESCE(SUM(multa), 0) FROM pagamentos")->fetchColumn();

// Faturamento recebido (real) - apenas pagamentos com status 'pago'
$faturamento_recebido = $pdo->query("
    SELECT COALESCE(SUM(total), 0) AS faturamento_recebido 
    FROM pagamentos 
    WHERE status = 'pago'
")->fetchColumn();

// Cálculo correto do faturamento esperado - baseado nas propinas mensais
$faturamento_esperado_mensal = 0;
$stmt = $pdo->prepare("
    SELECT 
        c.valor_proprina, 
        cl.valor_percentual
    FROM alunos a
    JOIN cursos c ON a.id_curso = c.id_curso
    JOIN classe cl ON a.id_classe = cl.id_classe
");
$stmt->execute();
$registros = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($registros as $registro) {
    $valor_propina = floatval($registro['valor_proprina']);
    $valor_percentual = floatval($registro['valor_percentual']);
    
    // Calcular propina com percentual de classe
    $propina_mensal = $valor_propina + ($valor_propina * $valor_percentual / 100);
    $faturamento_esperado_mensal += $propina_mensal;
}

// Calcular o total esperado do ano letivo
$faturamento_esperado_anual = $faturamento_esperado_mensal * 12;

// Obter número do mês atual (1-12)
$mes_atual_numero = intval(date('m'));

// Faturamento esperado até o mês atual
$faturamento_esperado_ate_agora = $faturamento_esperado_mensal * $mes_atual_numero;

// Pagamento diário (todos os pagamentos de hoje)
$totalPagDiario = $pdo->query("
    SELECT COALESCE(SUM(total), 0) AS total 
    FROM pagamentos 
    WHERE DATE(data_created) = CURDATE()
")->fetchColumn();

// Pagamentos diários de outros serviços
$PagamentoTL1 = $pdo->query("
    SELECT COALESCE(SUM(c.total_pago), 0) 
    FROM alunos a 
    JOIN outros_pagamentos o ON a.id_aluno = o.id_aluno 
    JOIN certificado c ON o.id_certificado = c.id_certificado
    WHERE DATE(c.created_at) = CURDATE()
")->fetchColumn();

$PagamentoTL2 = $pdo->query("
    SELECT COALESCE(SUM(e.total_pago), 0) 
    FROM alunos a 
    JOIN outros_pagamentos o ON a.id_aluno = o.id_aluno 
    JOIN estagio e ON o.id_estagio = e.id_estagio
    WHERE DATE(e.created_at) = CURDATE()
")->fetchColumn();

$PagamentoTL3 = $pdo->query("
    SELECT COALESCE(SUM(d.total_pago), 0) 
    FROM alunos a 
    JOIN outros_pagamentos o ON a.id_aluno = o.id_aluno 
    JOIN declaracao d ON o.id_declaracao = d.id_declaracao
    WHERE DATE(d.created_at) = CURDATE()
")->fetchColumn();

$PagamentoTL = $PagamentoTL1 + $PagamentoTL2 + $PagamentoTL3;
$totalPagDiario += $PagamentoTL;

// Pagamento mensal (mês atual)
$totalPagMensal = $pdo->query("
    SELECT COALESCE(SUM(total), 0) AS total 
    FROM pagamentos 
    WHERE MONTH(data_created) = $mesAtual AND YEAR(data_created) = $anoAtual
")->fetchColumn();

// Pagamentos mensais de outros serviços
$PagamentoTB1 = $pdo->query("
    SELECT COALESCE(SUM(e.total_pago), 0) 
    FROM alunos a 
    JOIN outros_pagamentos o ON a.id_aluno = o.id_aluno 
    JOIN estagio e ON o.id_estagio = e.id_estagio
    WHERE MONTH(e.created_at) = $mesAtual AND YEAR(e.created_at) = $anoAtual
")->fetchColumn();

$PagamentoTB2 = $pdo->query("
    SELECT COALESCE(SUM(c.total_pago), 0) 
    FROM alunos a 
    JOIN outros_pagamentos o ON a.id_aluno = o.id_aluno 
    JOIN certificado c ON o.id_certificado = c.id_certificado
    WHERE MONTH(c.created_at) = $mesAtual AND YEAR(c.created_at) = $anoAtual
")->fetchColumn();

$PagamentoTB3 = $pdo->query("
    SELECT COALESCE(SUM(d.total_pago), 0) 
    FROM alunos a 
    JOIN outros_pagamentos o ON a.id_aluno = o.id_aluno 
    JOIN declaracao d ON o.id_declaracao = d.id_declaracao
    WHERE MONTH(d.created_at) = $mesAtual AND YEAR(d.created_at) = $anoAtual
")->fetchColumn();

$PagamentoTB = $PagamentoTB1 + $PagamentoTB2 + $PagamentoTB3;
$totalPagMensal += $PagamentoTB;

// Outros pagamentos acumulados
$PagamentoEstagio = $pdo->query("
    SELECT COALESCE(SUM(e.total_pago), 0) 
    FROM alunos a 
    JOIN outros_pagamentos o ON a.id_aluno = o.id_aluno 
    JOIN estagio e ON o.id_estagio = e.id_estagio
    WHERE e.status = 'pago'
")->fetchColumn();

$PagamentoDeclaracao = $pdo->query("
    SELECT COALESCE(SUM(d.total_pago), 0) 
    FROM alunos a 
    JOIN outros_pagamentos o ON a.id_aluno = o.id_aluno 
    JOIN declaracao d ON o.id_declaracao = d.id_declaracao
    WHERE d.status = 'pago'
")->fetchColumn();

$PagamentoCertificado = $pdo->query("
    SELECT COALESCE(SUM(c.total_pago), 0) 
    FROM alunos a 
    JOIN outros_pagamentos o ON a.id_aluno = o.id_aluno 
    JOIN certificado c ON o.id_certificado = c.id_certificado
    WHERE c.status = 'pago'
")->fetchColumn();

// Pagamentos de matrícula, uniforme e cartão
$PagamentoMatriculaTotal = $valor_matricula * $total_alunos;
$PagamentoUniformeTotal = $valor_uniforme * $total_alunos;
$PagamentoCartaoTotal = $valor_cartao * $total_alunos;
$PagamentoTTT2 = $PagamentoMatriculaTotal + $PagamentoUniformeTotal + $PagamentoCartaoTotal;

// Faturamento total (propinas + outros serviços)
$faturamento_total = $faturamento_recebido + $PagamentoEstagio + $PagamentoDeclaracao + $PagamentoCertificado + $PagamentoTTT2;

// Taxa de inadimplência recalculada
// Considera apenas os meses decorridos no ano atual (proporcional)
$taxa_inadimplencia = 0;
if ($faturamento_esperado_ate_agora > 0) {
    $taxa_inadimplencia = 100 - (($faturamento_recebido / $faturamento_esperado_ate_agora) * 100);
    $taxa_inadimplencia = max(0, min(100, $taxa_inadimplencia)); // Garantir entre 0% e 100%
}

// CONSULTAS PARA GRÁFICOS E TABELAS
// ===========================================

// Quantidade de alunos por curso
$cursos_query = $pdo->query("
    SELECT c.id_curso, c.curso AS cursoAL, COUNT(a.id_aluno) AS total 
    FROM cursos c 
    LEFT JOIN alunos a ON c.id_curso = a.id_curso 
    GROUP BY c.id_curso, c.curso
    ORDER BY total DESC
");
$cursos_data = $cursos_query->fetchAll(PDO::FETCH_ASSOC);

// Crescimento da escola ao longo dos anos
$crescimento_query = $pdo->query("
    SELECT YEAR(created_at) AS ano_letivo, COUNT(id_aluno) AS total_alunos 
    FROM alunos 
    GROUP BY YEAR(created_at) 
    ORDER BY ano_letivo ASC
");
$crescimento_data = $crescimento_query->fetchAll(PDO::FETCH_ASSOC);

// Relatório detalhado por curso - CORRIGIDO E OTIMIZADO
$cursos_detalhes_query = $pdo->query("
    SELECT 
        c.id_curso,
        c.curso,
        COUNT(DISTINCT a.id_aluno) AS total_alunos,
        (
            SELECT COALESCE(SUM(p.total), 0) 
            FROM pagamentos p 
            JOIN alunos a2 ON a2.id_aluno = p.id_aluno 
            WHERE a2.id_curso = c.id_curso AND p.status = 'pago'
        ) AS faturamento_atual,
        (
            SELECT SUM(
                (c.valor_proprina + (c.valor_proprina * cl.valor_percentual / 100)) * 
                (CASE 
                    WHEN YEAR(a3.created_at) = YEAR(CURRENT_DATE) THEN MONTH(CURRENT_DATE)
                    ELSE 12
                END)
            )
            FROM alunos a3
            JOIN classe cl ON cl.id_classe = a3.id_classe
            WHERE a3.id_curso = c.id_curso
        ) AS faturamento_esperado_anual,
        (
            SELECT COALESCE(SUM(p.multa), 0) 
            FROM pagamentos p 
            JOIN alunos a4 ON a4.id_aluno = p.id_aluno 
            WHERE a4.id_curso = c.id_curso
        ) AS multas_curso
    FROM cursos c
    LEFT JOIN alunos a ON c.id_curso = a.id_curso
    LEFT JOIN classe cl ON cl.id_classe = a.id_classe
    GROUP BY c.id_curso, c.curso
    ORDER BY total_alunos DESC
");
$cursos_detalhes = $cursos_detalhes_query->fetchAll(PDO::FETCH_ASSOC);

// Pagamentos por mês (últimos 12 meses)
$pagamentos_mensais_query = $pdo->query("
    SELECT 
        DATE_FORMAT(data_created, '%Y-%m') AS mes,
        SUM(total) AS valor_total
    FROM pagamentos
    WHERE data_created >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
    AND status = 'pago'
    GROUP BY DATE_FORMAT(data_created, '%Y-%m')
    ORDER BY mes ASC
");
$pagamentos_mensais = $pagamentos_mensais_query->fetchAll(PDO::FETCH_ASSOC);

// Verificamos se estamos no primeiro mês do ano para ajustar expectativas
$inicio_ano_letivo = ($mesAtual == 1);

// Coletar dados para os gráficos
$cursos = [];
$faturamentoAtual = [];
$faturamentoEsperado = [];
$total_alunos_cursos = [];

foreach ($cursos_detalhes as $curso) {
    $cursos[] = $curso['curso'];
    $faturamentoAtual[] = $curso['faturamento_atual'] ?: 0;
    $faturamentoEsperado[] = $curso['faturamento_esperado_anual'] ?: 0;
    $total_alunos_cursos[] = $curso['total_alunos'];
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório Financeiro Escolar</title>
    <link rel="stylesheet" href="../Styles/Relatorio.css">
    <link rel="icon" type="image/x-png" href="../arquivos/Logotipo/LOGO ICRA.jpg">
    <link rel="stylesheet" href="../Bibiliotecas/pace-1.2.4/themes/red/pace-theme-center-atom.css">
    <script src="../Bibiliotecas/pace-1.2.4/pace.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="../Bibiliotecas/Font-Awesome-6.x/css/all.min.css">
    <style>
        :root {
            --primary-color: #005ec2;
            --secondary-color: #333;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --white: #fff;
            --light-gray: #f8f9fa;
            --border-color: #ddd;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            color: #333;
        }

        
        .ContHora {
            text-align: right;
            margin-bottom: 10px;
            font-size: 18px;
            color: var(--secondary-color);
        }
        
        .ContLogo {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .ContLogo h1 {
            color: var(--primary-color);
            margin-top: 15px;
            font-size: 28px;
        }
        
        .card-container {
            display: flex;
            flex-wrap: wrap;
            width: 95%;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .card {
            flex: 1 1 200px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border-bottom: 5px solid var(--primary-color);
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
        }
        
        .card h3 {
            margin-top: 0;
            color: var(--secondary-color);
            font-size: 18px;
        }
        
        .card p {
            font-size: 22px;
            font-weight: bold;
            margin: 10px 0 0;
            color: var(--primary-color);
        }
        
        .card.warning p {
            color: var(--warning-color);
        }
        
        .card.success p {
            color: var(--success-color);
        }
        
        .card.danger p {
            color: var(--danger-color);
        }
        
        .tabela {
            width: 98%;
            border-collapse: collapse;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        
        .tabela th, .tabela td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        
        .tabela th {
           background-color: blue;
            color: var(--white);
            font-weight: 600;
        }
        
        .tabela td{
            background-color: var(--light-gray);
        }
        
        .tabela tr:hover {
            background-color: rgba(0, 94, 194, 0.05);
        }
        
        .btn-lista {
            background: linear-gradient(135deg, var(--primary-color), #0046a3);
            color: white;
            padding: 12px 24px;
            display: inline-block;
            border-radius: 8px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            transition: 0.3s;
            font-weight: bold;
            margin: 15px 0 30px;
            box-shadow: 0 4px 10px rgba(0, 94, 194, 0.3);
            text-decoration: none;
        }
        
        .btn-lista:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(0, 94, 194, 0.4);
        }
        
        .btn-lista i {
            margin-right: 8px;
        }
        
        .ContCards {
            display: flex;
            flex-wrap: wrap;
            gap: 25px;
            width: 98%;
            margin-bottom: 50px;
        }
        
        .card1 {
            flex: 1 1 400px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            padding: 25px;
            text-align: center;
            transition: 0.3s;
            border-bottom: 5px solid var(--primary-color);
        }
        
        .card1 h3 {
            margin-top: 0;
            color: var(--secondary-color);
            margin-bottom: 20px;
        }
        
        .card1 canvas {
            width: 100% !important;
            height: 300px !important;
        }
        
        .filtro-periodo {
            display: flex;
            margin-bottom: 20px;
            gap: 10px;
        }
        
        .filtro-periodo select, .filtro-periodo button {
            padding: 8px 12px;
            border-radius: 4px;
            border: 1px solid var(--border-color);
        }
        
        .filtro-periodo button {
            background-color: var(--primary-color);
            color: white;
            border: none;
            cursor: pointer;
        }
        
        .resumo-indicadores {
            background-color: white;
            border-radius: 12px;
            padding: 20px;
            width: 95%;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        
        .resumo-indicadores h3 {
            margin-top: 0;
            color: var(--primary-color);
            border-bottom: 2px solid var(--primary-color);
            padding-bottom: 10px;
            margin-bottom: 15px;
        }
        
        .progresso-container {
            margin-bottom: 20px;
        }
        
        .progresso-titulo {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
        }
        
        .barra-progresso {
            height: 12px;
            background-color: #e9ecef;
            border-radius: 6px;
            overflow: hidden;
        }
        
        .barra-valor {
            height: 100%;
            background: linear-gradient(90deg, var(--primary-color), #0046a3);
            border-radius: 6px;
            transition: width 1s ease;
        }
        
        @media (max-width: 768px) {
            .card-container {
                flex-direction: column;
            }
            
            .card {
                margin-bottom: 15px;
            }
            
            .tabela {
                font-size: 14px;
            }
            
            .tabela th, .tabela td {
                padding: 8px;
            }
            
            .ContCards {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <?php require "Menu.php"; ?>
    
    <div class="container">
        <div class="ContHora"><i class="fas fa-clock"></i><span style="font-size: 20px;" id="recebHora"></span></div>
        
        <div class="dashboard-header">
            <img src="../arquivos/Logotipo/LOGO ICRA.jpg" alt="Logo ICRA">
            <h1>Relatórios Financeiros da Escola</h1>
        </div>
           
        
        <!-- Filtro de período para relatórios -->
        <div class="filtro-periodo">
            <select id="periodoRelatorio">
                <option value="hoje">Hoje</option>
                <option value="semana">Esta semana</option>
                <option value="mes" selected>Este mês</option>
                <option value="ano">Este ano</option>
                <option value="todos">Todos</option>
            </select>
            <button onclick="filtrarPeriodo()"><i class="fas fa-filter"></i> Filtrar</button>
        </div>
        
        <!-- Cards de indicadores principais -->
        <div class="card-container">
            <?php if($_SESSION['nivel_acesso'] === "Administrador"): ?>
                <div class="card success">
                    <h3><i class="fas fa-money-bill-wave"></i> Faturamento Total</h3>
                    <p><?php echo formatMoney($faturamento_total); ?></p>
                </div>
                <div class="card success">
                    <h3><i class="fas fa-money-bill-wave"></i>Outros serviços</h3>
                    <p><?php echo formatMoney($PagamentoCertificado+$PagamentoDeclaracao+$PagamentoEstagio+$PagamentoTTT2); ?></p>
                </div>
                <div class="card">
                    <h3><i class="fas fa-calendar-check"></i> Faturamento Esperado (Anual)</h3>
                    <p><?php echo formatMoney($faturamento_esperado_anual); ?></p>
                </div>
            <?php endif; ?>
            <div class="card warning">
                <h3><i class="fas fa-exclamation-triangle"></i> Multas Acumuladas</h3>
                <p><?php echo formatMoney($multa_acumulada); ?></p>
            </div>
            <div class="card">
                <h3><i class="fas fa-calendar-day"></i> Faturamento de Hoje</h3>
                <p><?php echo formatMoney($totalPagDiario); ?></p>
            </div>
            <div class="card">
                <h3><i class="fas fa-calendar-alt"></i> Faturamento Mensal</h3>
                <p><?php echo formatMoney($totalPagMensal); ?></p>
            </div>
            <div class="card danger">
                <h3><i class="fas fa-percentage"></i> Taxa de Inadimplência</h3>
                <p><?php echo number_format($taxa_inadimplencia, 1, ',', '.'); ?>%</p>
            </div>
        </div>
        
        <!-- Resumo de indicadores -->
        <div class="resumo-indicadores">
            <h3><i class="fas fa-chart-line"></i> Indicadores Financeiros</h3>
            
            <!-- Progresso do faturamento -->
            <div class="progresso-container">
                <div class="progresso-titulo">
                    <span>Progresso do Faturamento (<?php echo $mesAtual; ?> meses)</span>
                    <span><?php 
                        $percentual_faturamento = ($faturamento_esperado_ate_agora > 0) ? 
                            min(100, ($faturamento_recebido / $faturamento_esperado_ate_agora) * 100) : 0;
                        echo number_format($percentual_faturamento, 1, ',', '.'); 
                    ?>%</span>
                </div>
                <div class="barra-progresso">
                    <div class="barra-valor" style="width: <?php echo $percentual_faturamento; ?>%"></div>
                </div>
            </div>
            
            <!-- Total de alunos -->
            <div class="progresso-container">
                <div class="progresso-titulo">
                    <span>Total de Alunos</span>
                    <span><?php echo $total_alunos; ?> alunos</span>
                </div>
                <div class="progresso-titulo">
                    <span>Média de Valor por Aluno (Mensal)</span>
                    <span><?php 
                        $media_por_aluno = $total_alunos > 0 ? 
                            $faturamento_recebido / $total_alunos / $mes_atual_numero : 0;
                        echo formatMoney($media_por_aluno); 
                    ?></span>
                </div>
            </div>
        </div>
        
        <!-- Tabela de Relatório por Curso -->
        <h3><i class="fas fa-table"></i> Relatório Detalhado por Curso</h3>
        <table class="tabela">
            <tr>
                <th>Curso</th>
                <th>Alunos Matriculados</th>
                <th>Faturamento Atual</th>
                <th>Faturamento Esperado (Anual)</th>
                <th>Multas</th>
                <th>Percentual</th>
            </tr>
           <?php foreach ($cursos_detalhes as $curso) {
    // Calcular percentual de realização (com verificação de divisão por zero)
    $percentual = $curso['faturamento_esperado_anual'] > 0 ? 
        ($curso['faturamento_atual'] / $curso['faturamento_esperado_anual']) * 100 : 0;
    
    // Define classe de cor com base no percentual
    $percentualClass = '';
    if ($percentual < 50) {
        $percentualClass = 'color: var(--danger-color);';
    } elseif ($percentual < 80) {
        $percentualClass = 'color: var(--warning-color);';
    } else {
        $percentualClass = 'color: var(--success-color);';
    }
    
    echo "<tr>
        <td>{$curso['curso']}</td>
        <td>{$curso['total_alunos']}</td>
        <td>" . formatMoney($curso['faturamento_atual']) . "</td>
        <td>" . formatMoney($curso['faturamento_esperado_anual']) . "</td>
        <td>" . formatMoney($curso['multas_curso']) . "</td>
        <td><span style='font-weight: bold; {$percentualClass}'>" . number_format($percentual, 1, ',', '.') . "%</span></td>
    </tr>";
} ?>
</table>

<!-- Botão para relatório detalhado -->
<a href="relatorio_detalhado.php" class="btn-lista">
    <i class="fas fa-file-alt"></i> Ver Relatório Completo
</a>

<!-- Gráficos -->
<div class="ContCards">
    <!-- Gráfico de distribuição de alunos por curso -->
    <div class="card1">
        <h3><i class="fas fa-chart-pie"></i> Distribuição de Alunos por Curso</h3>
        <canvas id="alunosPorCursoChart"></canvas>
    </div>
    
    <!-- Gráfico de faturamento mensal -->
    <div class="card1">
        <h3><i class="fas fa-chart-line"></i> Faturamento Mensal</h3>
        <canvas id="faturamentoMensalChart"></canvas>
    </div>
</div>

<div class="ContCards">
    <!-- Gráfico de realização x expectativa -->
    <div class="card1">
        <h3><i class="fas fa-chart-bar"></i> Faturamento Real vs. Esperado por Curso</h3>
        <canvas id="realizacaoChart"></canvas>
    </div>
    
    <!-- Gráfico de crescimento de alunos -->
    <div class="card1">
        <h3><i class="fas fa-user-graduate"></i> Crescimento da Escola</h3>
        <canvas id="crescimentoChart"></canvas>
    </div>
</div>

</div> <!-- Fechamento do container principal -->

<script>
// Função para atualizar o relógio em tempo real
function atualizarHora() {
    const agora = new Date();
    const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    };
    document.getElementById('recebHora').textContent = agora.toLocaleDateString('pt-AO', options);
}

// Atualizar a hora a cada segundo
setInterval(atualizarHora, 1000);
atualizarHora(); // Chamar imediatamente para exibir

// Função para filtrar relatórios por período
function filtrarPeriodo() {
    const periodo = document.getElementById('periodoRelatorio').value;
    // Implementar redirecionamento ou atualização AJAX aqui
    window.location.href = `relatorio_financeiro.php?periodo=${periodo}`;
}

// Configuração dos gráficos com Chart.js
document.addEventListener('DOMContentLoaded', function() {
    // Cores para gráficos
    const chartColors = [
        'rgba(54, 162, 235, 0.8)',
        'rgba(255, 99, 132, 0.8)',
        'rgba(75, 192, 192, 0.8)',
        'rgba(255, 159, 64, 0.8)',
        'rgba(153, 102, 255, 0.8)',
        'rgba(255, 205, 86, 0.8)',
        'rgba(201, 203, 207, 0.8)',
        'rgba(94, 233, 163, 0.8)',
        'rgba(233, 94, 94, 0.8)',
        'rgba(154, 94, 233, 0.8)'
    ];

    // Gráfico de distribuição de alunos por curso
    const ctxAlunos = document.getElementById('alunosPorCursoChart').getContext('2d');
    new Chart(ctxAlunos, {
        type: 'pie',
        data: {
            labels: <?php echo json_encode(array_column($cursos_data, 'cursoAL')); ?>,
            datasets: [{
                data: <?php echo json_encode(array_column($cursos_data, 'total')); ?>,
                backgroundColor: chartColors,
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                }
            }
        }
    });

    // Gráfico de faturamento mensal
    const ctxFaturamento = document.getElementById('faturamentoMensalChart').getContext('2d');
    
    // Formatar os dados para o gráfico - converter YYYY-MM para nomes de meses
    const mesesData = <?php echo json_encode(array_column($pagamentos_mensais, 'mes')); ?>;
    const mesesLabels = mesesData.map(mesStr => {
        const [ano, mes] = mesStr.split('-');
        const data = new Date(ano, mes - 1, 1);
        return data.toLocaleDateString('pt-AO', { month: 'short', year: 'numeric' });
    });
    
    new Chart(ctxFaturamento, {
        type: 'line',
        data: {
            labels: mesesLabels,
            datasets: [{
                label: 'Faturamento Mensal',
                data: <?php echo json_encode(array_column($pagamentos_mensais, 'valor_total')); ?>,
                borderColor: 'rgba(54, 162, 235, 1)',
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderWidth: 2,
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value.toLocaleString('pt-AO') + ' Kz';
                        }
                    }
                }
            }
        }
    });

    // Gráfico de Realização vs Expectativa por curso
    const ctxRealizacao = document.getElementById('realizacaoChart').getContext('2d');
    new Chart(ctxRealizacao, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode(array_column($cursos_detalhes, 'curso')); ?>,
            datasets: [
                {
                    label: 'Faturamento Atual',
                    data: <?php echo json_encode(array_column($cursos_detalhes, 'faturamento_atual')); ?>,
                    backgroundColor: 'rgba(54, 162, 235, 0.8)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Faturamento Esperado',
                    data: <?php echo json_encode(array_column($cursos_detalhes, 'faturamento_esperado_anual')); ?>,
                    backgroundColor: 'rgba(255, 99, 132, 0.8)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value.toLocaleString('pt-AO') + ' Kz';
                        }
                    }
                }
            }
        }
    });

    // Gráfico de crescimento da escola
    const ctxCrescimento = document.getElementById('crescimentoChart').getContext('2d');
    new Chart(ctxCrescimento, {
        type: 'line',
        data: {
            labels: <?php echo json_encode(array_column($crescimento_data, 'ano_letivo')); ?>,
            datasets: [{
                label: 'Total de Alunos',
                data: <?php echo json_encode(array_column($crescimento_data, 'total_alunos')); ?>,
                borderColor: 'rgba(75, 192, 192, 1)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderWidth: 2,
                fill: true,
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
});
</script>
  <script src='../Scritps/Menu.js'></script>
<?php require "Footer.php"; ?>
</body>
</html>