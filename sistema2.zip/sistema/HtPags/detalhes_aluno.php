<?php
session_start();
require '../Config/conexaoBD.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    die("ID do aluno não fornecido.");
}

$id = $_GET['id'];

// Busca os dados atuais do sistema
$sql = "SELECT * FROM informacoes_basicas WHERE id = 1";
$result = $conn->query($sql);
$infor = $result->fetch_assoc();

$queryOpag = $pdo->prepare("SELECT c.status AS estadoC, d.status AS estadoD, e.status AS estadoE FROM outros_pagamentos op 
    JOIN certificado c ON op.id_certificado = c.id_certificado 
    JOIN declaracao d ON op.id_declaracao = d.id_declaracao 
    JOIN estagio e ON op.id_estagio = e.id_estagio 
    JOIN alunos a ON op.id_aluno = a.id_aluno
    WHERE a.id_aluno = ?");
$queryOpag->execute([$id]);
$Opag = $queryOpag->fetch(PDO::FETCH_ASSOC);

// Buscar pagamentos do aluno
$queryAluno = $pdo->prepare("SELECT a.*, t.nome As turma, c.valor_percentual AS Valor_percentual, c.nome AS NomeClasse, cu.valor_proprina AS Valor_Proprina, cu.curso FROM alunos a 
    JOIN classe c ON a.id_classe = c.id_classe 
    JOIN cursos cu ON a.id_curso = cu.id_curso 
    JOIN turmas t ON a.id_turma = t.id_turma 
    WHERE a.id_aluno = ?
    ORDER BY a.created_at DESC");
$queryAluno->execute([$id]);
$aluno = $queryAluno->fetch(PDO::FETCH_ASSOC);


if (!$aluno) {
    die("Aluno não encontrado.");
}



// Buscar pagamentos do aluno
$queryPagamentos = $pdo->prepare("SELECT * FROM pagamentos WHERE id_aluno = ?");
$queryPagamentos->execute([$id]);
$pagamentos = $queryPagamentos->fetchAll(PDO::FETCH_ASSOC);

// Buscar pagamentos do aluno
$queryMeses = $pdo->prepare("SELECT * FROM meses ORDER BY data ASC");
$queryMeses->execute();
$mesesP = $queryMeses->fetchAll(PDO::FETCH_ASSOC);

// Buscar multa percentual
$queryMulta = $pdo->prepare("SELECT multa_percentual FROM informacoes_basicas");
$queryMulta->execute();
$multa_percentual = $queryMulta->fetchAll(PDO::FETCH_ASSOC);
$multa = 0;
foreach($multa_percentual as $multa_per){
     $multa = $multa_per['multa_percentual'];
}

$dadosPagamentos = [];
foreach ($pagamentos as $p) {
    $dadosPagamentos[$p['mes']] = $p;
}

 //Buscar meses pagos 
 $stmtPagos = $pdo->prepare("SELECT CONCAT(ano, '-', mes) FROM pagamentos WHERE id_aluno = ? AND pagamentos.status = 'pago'");
 $stmtPagos->execute([$id]);
 $meses_p = $stmtPagos->fetchAll(PDO::FETCH_COLUMN);
 $meses_pagos = count($meses_p);

 $meses_pendentes = 12 - $meses_pagos; 


 
// Buscar meses
$sqlMeses = "SELECT * FROM meses ORDER BY data ASC";
$resultMeses = $conn->query($sqlMeses);
$meses = [];
while ($row = $resultMeses->fetch_assoc()) {
    $meses[] = $row;
}
// Calcular idade a partir da data de nascimento
$dataNascimento = new DateTime($aluno['data_nascimento']);
$hoje = new DateTime();
$idade = $dataNascimento->diff($hoje)->y;


$anoAtual = date("Y");

 $valor_propinaLiquido = $aluno["Valor_Proprina"] + ($aluno["Valor_Proprina"] * $aluno["Valor_percentual"])/100; 


 $sqlClasses = "SELECT * FROM classe ORDER BY nome ASC";
$resultClasses = $conn->query($sqlClasses);
$classes = [];
while ($row = $resultClasses->fetch_assoc()) {
    $classes[] = $row;
}

$sqlCursos = "SELECT * FROM cursos ORDER BY curso ASC";
$resultCursos = $conn->query($sqlCursos);
$cursos = [];
while ($row = $resultCursos->fetch_assoc()) {
    $cursos[] = $row;
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalhes do Aluno</title>
    <link rel="icon" style="width: 100%; height:100%;" type="image/x-png" href="../arquivos/Logotipo/LOGO ICRA.jpg">
    <link rel="stylesheet" href="../Bibiliotecas/pace-1.2.4/themes/red/pace-theme-center-atom.css">
    <script src="../Bibiliotecas/pace-1.2.4/pace.min.js"></script>
	  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../Bibiliotecas/Font-Awesome-6.x/css/all.min.css"> <!-- Ícones FontAwesome -->
    <link rel="stylesheet" href="../Styles/detalhes_aluno.css">
	 <link rel="stylesheet" href="../Styles/detalhes_alunoT.css">
</head>
<body>
    <!--Menu-->
    <?php require "Menu.php"; ?>
    <div class="container">
    <div class="ContHora"><i class="fas fa-clock"></i><span style="font-size: 20px;" id="recebHora"></span></div>
     <div class="aluno-profile">
            <div class="profile-header">
                <div class="profile-image">
                    <img src="../arquivos/fotos_dos_alunos/<?= $aluno['foto'] ?>" alt="Foto de <?= $aluno['nome'] ?>">
                </div>
                <div class="profile-info">
                    <h2><?= $aluno['nome'] ?></h2>
                    <p class="student-id">ID: <?= $aluno['id_aluno'] ?></p>
                    <div class="status-badge <?= $meses_pendentes > 0 ? 'pending' : 'paid' ?>">
                        <?= $meses_pendentes > 0 ? 'Pendente' : 'Em dia' ?>
                    </div>
                </div>
            </div>
            
            <div class="profile-actions">
                <button id="efectuarPag" onclick="abrirModalOpcao()" class="btn-payment">
                    <i class="fas fa-money-bill-wave"></i> Efetuar Pagamento
                </button>
                <a href="Historico_factura.php?id=<?= $id ?>" class="btn-history">
                    <i class="fas fa-history"></i> Histórico de Faturas
                </a>
          
            </div>

            <div class="profile-details">
                <div class="detail-section">
                    <h3><i class="fas fa-user"></i> Dados Pessoais</h3>
                    <div class="details-grid">
                        <div class="detail-item">
                            <span class="detail-label">Nome Completo:</span>
                            <span class="detail-value"><?= $aluno['nome'] ?></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Data de Nascimento:</span>
                            <span class="detail-value"><?= date('d/m/Y', strtotime($aluno['data_nascimento'])) ?></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Idade:</span>
                            <span class="detail-value"><?= $idade ?> anos</span>
                        </div>
						   <div class="detail-item">
                            <span class="detail-label">BI:</span>
                            <span class="detail-value"><?= $aluno['BI'] ?></span>
                        </div>
                    </div>
                </div>

                <div class="detail-section">
                    <h3><i class="fas fa-map-marker-alt"></i> Contato</h3>
                    <div class="details-grid">
                        <div class="detail-item">
                            <span class="detail-label">Endereço:</span>
                            <span class="detail-value"><?= $aluno['morada'] ?></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Telefone:</span>
                            <span class="detail-value"><?= $aluno['numero_encarregado'] ?></span>
                        </div>
                    </div>
                </div>

                <div class="detail-section">
                    <h3><i class="fas fa-graduation-cap"></i> Dados Académicos</h3>
                    <div class="details-grid">
                        <div class="detail-item">
                            <span class="detail-label">Curso:</span>
                            <span class="detail-value"><?= $aluno['curso'] ?></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Classe:</span>
                            <span class="detail-value"><?= $aluno['NomeClasse'] ?>ª</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Turma:</span>
                            <span class="detail-value"><?= $aluno['turma'] ?></span>
                        </div>
                    </div>
                </div>

                <div class="detail-section">
                    <h3><i class="fas fa-money-check-alt"></i> Informações Financeiras</h3>
                    <div class="details-grid financial-grid">
                        <div class="detail-item highlight">
                            <span class="detail-label">Valor da Própina:</span>
                            <span class="detail-value"><?= number_format($valor_propinaLiquido, 2, ',', '.') ?> Kz</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Pagamentos Feitos:</span>
                            <span class="detail-value"><?= $meses_pagos ?> meses</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Pagamentos Pendentes:</span>
                            <span class="detail-value"><?= $meses_pendentes ?> meses</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Taxa de Multa:</span>
                            <span class="detail-value"><?= $multa ?>%</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

     <div class="payment-status">
            <h3><i class="fas fa-calendar-check"></i> Status de Pagamentos de Propina</h3>
            <div class="meses-container">
                <?php foreach ($meses as $mes) :
                $nomeMes = $mes['mes'];
                $dataMes = $mes['data'];

                // Verificar se o aluno pagou o mês atual
                $sqlPagamento = "SELECT * FROM pagamentos WHERE id_aluno = '$id' AND mes = '$nomeMes' AND ano = '$anoAtual' AND status = 'pago'";
                $resultPagamento = $conn->query($sqlPagamento);

                if ($resultPagamento->num_rows > 0) {
                    $cor = "pago"; // Verde (Pago)
                } else {
                    $dataMesTime = strtotime($dataMes);
                    $dataAtualTime = strtotime(date("Y-m-d"));

                    if ($dataMesTime < $dataAtualTime) {
                        $cor = "divida"; // Vermelho (Atrasado)
                    } else {
                        $cor = "futuro"; // Cinza (Pendente)
                    }
                }
            ?>
            <div class="mes <?= $cor ?>">
                <div class="card-body text-center">
                    <h3 class="card-title"><?= $nomeMes ?></h3>
                    <span class="card-text"><?= date("d/m/Y", strtotime($dataMes)) ?></p>
                </div>
            </div>
        <?php endforeach; ?>
            </div>
       <h3><i class="fas fa-file-invoice"></i> Status de Outros Pagamentos</h3>
        <div class="outros-pagamentos">
            <?php if ($aluno["id_classe"] == "4"): ?>
                <?php if ($Opag["estadoE"] == "pendente") {
                            $corE = "Pendente"; 
                        } else {
                            $corE = "Pago"; // Cinza (Pendente)
                        } ?>
                <div class="pagamento-item <?= $corE ?>">
                    <div class="card-body text-center">
                        <h4 class="card-title">Estágio</h4>
                        <span class="card-text"><?= $corE ?></p>
                    </div>
                </div>
            <?php endif; ?>
            <?php if ($aluno["id_classe"] != "4"): ?>
            <?php if ($Opag["estadoD"] == "pendente") {
                        $corD = "Pendente"; // Vermelho (Atrasado)
                    } else {
                        $corD = "Pago"; // Cinza (Pendente)
                    } ?>
            <div class="pagamento-item <?= $corD ?>">
                <div class="card-body text-center">
                    <h4 class="card-title">Declaração</h4>
                    <span class="card-text"><?= $corD ?></p>
                </div>
            </div>
               <?php endif; ?>
             <?php if ($aluno["id_classe"] == "4"): ?>
                <?php if ($Opag["estadoC"] == "pendente") {
                            $corC = "Pendente"; // Vermelho (Atrasado)
                        } else {
                            $corC = "Pago"; // Cinza (Pendente)
                        } ?>
                <div class="pagamento-item <?= $corC ?>">
                    <div class="card-body text-center">
                        <h4 class="card-title">Certificado</h4>
                        <span class="card-text"><?= $corC ?></p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        </div>
    </div>
 
    <div id="Erro" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background-color:rgba(0,0,0,0.4); z-index:9000000000000000000000000000000; color:#fff;">
        <div style=" position: relative; display: block; width: 40%; padding:10px; top: 50%;left: 50%; transform: translate(-50%,-50%); background-color:#ffffff; border-radius:10px;">
           <button onclick="voltrarPag()" class="icon-remove" style="padding:10px; position: absolute;top: 20px; left: 95%; transform: translate(-50%,-50%);background: transparent; font-size: 24px; color: #ff4d4d; border:none; border-radius:50%; cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
            <i class="fas fa-warning" style="position: relative; color: red; margin-top: 40px; font-size: 24px; display: block; left: 50%; transform: translateY(-50%);"></i>
            <p id="textErro" style="color: black; text-align: center;"></p>
        </div>
    </div>

<!-- Modal de Pagamento -->
    <div id="modalPagamento" class="modal">
        <div class="modal-content">
            <span class="close" onclick="fecharModalPagamento()"><i class="fa-solid fa-xmark"></i></span>
            <h2>Pagamento de Propina</h2>
            <form>
            <input type="hidden" id="aluno_id" value="<?= $aluno['id_aluno'] ?>">
            <section class="sale-form">
                <div class="form-group">
                    <label for="quantidade">Desconto:</label>
                    <input type="number" id="desconto" name="desconto" value="0" max="<?= $valor_propinaLiquido ?>" min="0">
                </div>
                <button id='addPag' class="btn" type="button"><i class="fas fa-plus"></i>Adicionar</button>
            </section>
             </form>

            <section class="cart" id="cart">
                <h3 style="color:#258eff; text-align: center;">Pagamentos</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Mês</th>
                            <th>Valor(Kz)</th>
                            <th>Multa(Kz)</th>
                            <th>Desconto(Kz)</th>
                            <th>Total(Kz)</th>
                        </tr>
                    </thead>
                    <tbody id="carrinho">
                        <!-- Itens do carrinho serão adicionados aqui dinamicamente -->
                    </tbody>
                </table>
            </section>
            <form action="../Config/processar_pagamento.php" method="post">
                <input type="hidden" id="pagamentoInp" name="dados">
                <input type="hidden" id="id_alunoInp" name="id_aluno">
                <input type="hidden" id="id_mesInp" name="id_mes">
               <button type="button" class="btn-confirmar" onclick="confirmarPagamento()">Confirmar</button>
               <button type="button" class="btn-cancelar" id="cancelar" onclick="removerIntem()">Cancelar</button>
            </form>
        </div>
    </div>

    <!-- Modal Opcão -->
<div id="modalOpcao" class="modal">
    <div class="modal-content">
        <span class="close" onclick="fecharModal('modalOpcao')"><i class="fa-solid fa-xmark"></i></span>
        <h2>Opções de Pagamento</h2>

        <button type="button" onclick="abrirModalPagamento()" class="btn-opcao" style="background-color: green;">
             Propina
        </button>
        <?php if ($aluno["id_classe"] != "4"): ?>
        <?php if ($Opag["estadoD"] != "pago"): ?>
        <button type="button" onclick="abrirModalDeclaracao()" class="btn-opcao" style="background-color: green;">
             Declaração
        </button>
        <?php endif; ?>
        <?php endif; ?>
        <?php if ($aluno["id_classe"] == "4"): ?>
        <?php if ($Opag["estadoC"] != "pago"): ?>
        <button type="button" onclick="abrirModalCertificado()" class="btn-opcao" style="background-color: green;">
            Certificado
        </button>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Modal Certificado -->
<div id="modalCertificado" class="modal">
    <div class="modal-content">
        <span class="close" onclick="fecharModal('modalCertificado')"><i class="fa-solid fa-xmark"></i></span>
        <h2>Pagamento de Certificado</h2>
        <form id="formAdicionar" method="GET" action="../Config/pagamentoCertificado.php" enctype="multipart/form-data">
            <input type="hidden" name="id_aluno" value="<?= $aluno['id_aluno'] ?>">
            <input type="hidden" name="valor_certificado" value="<?= $infor['valor_certificado'] ?>">
            <input type="hidden" name="certificado" value="certificado">
            <p>Valor de Certificado: <?= $infor['valor_certificado'] ?></p>
            <div class="form-div">
                <label>Modo Pagamento:</label>
                 <select name="modoPagamento" id="modoPagamentoR" required>
                   <option value="Dinheiro">Dinheiro</option>
                   <option selected value="Multicaixa">Multicaixa</option>
                </select>
            </div>
            <button type="submit" class="btn-confirmar" style="background-color: green; color: white">
                <i class="fas fa-save"></i> Pagar
            </button>
        </form>
    </div>
</div>   
<!-- Modal Declaracao -->
<div id="modalDeclaracao" class="modal">
    <div class="modal-content">
        <span class="close" onclick="fecharModal('modalDeclaracao')"><i class="fa-solid fa-xmark"></i></span>
        <h2>Pagamento de declaração</h2>
        <form id="formAdicionar" method="GET" action="../Config/pagamentoDeclaracao.php" enctype="multipart/form-data">
            <input type="hidden" name="id_aluno" value="<?= $aluno['id_aluno'] ?>">
            <input type="hidden" name="valor_declaracao" value="<?= $infor['valor_declaracao'] ?>">
            <input type="hidden" name="declaracao" value="declaracao">
            <p>Valor de declaração: <?= $infor['valor_declaracao'] ?></p>
            <div class="form-div">
                <label>Modo Pagamento:</label>
                 <select name="modoPagamento" id="modoPagamentoR" required>
                   <option value="Dinheiro">Dinheiro</option>
                   <option selected value="Multicaixa">Multicaixa</option>
                </select>
            </div>
            <button type="submit" class="btn-confirmar" style="background-color: green; color: white">
                <i class="fas fa-save"></i> Pagar
            </button>
        </form>
    </div>
</div>
<!-- ✅ MODAL EDITAR ALUNO -->
<div id="modalEditar" class="modal">
    <div class="modal-content">
        <span class="close" onclick="fecharModal('modalEditar')"><i class="fa-solid fa-xmark"></i></span>
        <h2><i class="fas fa-edit"></i> Editar Aluno</h2>
        
        <form id="formEditar" action="../Config/editar_aluno.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id_aluno" id="edit_id">
            <div class="form-div">
                <label>Foto (opcional):</label>
                <input type="file" name="foto" id="edit_foto">
            </div>
            <div class="form-div">
            <label><i class="fa-solid fa-user"></i> Nª BI:</label>
            <input type="text" minlength="1" maxlength="14" name="BI" id="edit_BI" required>
            </div>
            <div class="form-div">
            <label>Nome:</label>
            <input type="text" name="nome" id="edit_nome" required>
            </div>
            <div class="form-div">
            <label><i class="fa-solid fa-calendar"></i> Data de nascimento:</label>
            <input type="date" max="2012-01-01" min="1928-01-01" id="edit_data_nasc" name="data_nascimento" required>
            </div>
            <div class="form-div">
            <label>Morada:</label>
            <input type="text" name="morada" id="edit_morada" required>
            </div>
            <div class="form-div">
            <label>Número do Encarregado:</label>
            <input type="number" min="900000000" max="999999999"  name="numero_encarregado" id="edit_numero_encarregado" required>
            </div>
            <div class="form-div">
                <label for="id_fornecedor" class="form-label">Classe: </label>
                <select class="form-select" id="edit_classe" name="id_classe" required>
                    <option value="" disabled selected>Selecione uma classe</option>
                    <?php foreach ($classes as $classe): ?>
                        <option value="<?= $classe['id_classe'] ?>"><?= $classe['nome'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
                <div class="form-div">
                <label for="id_curso" class="form-label">Curso: </label>
                <select class="form-select" name="id_curso" id="edit_curso" required>
                    <option value="" disabled selected>Selecione um curso</option>
                    <?php foreach ($cursos as $curso): ?>
                        <option  value="<?= $curso['id_curso'] ?>"><?= $curso['curso'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-div">
            <label>Turma:</label>
              <select name="id_turma" id="edit_turma" required>
                  
              </select>
            </div>
            <button type="submit" class="btn-salvar" style="background-color: yellow;">
                <i class="fas fa-save"></i> Salvar Alterações
            </button>
        </form>
    </div>
</div>

    <script>
        let valor_proprinaBruto = <?= $aluno["Valor_Proprina"] ?> ?? 0;
        let valor_percentualBruto = <?= $aluno["Valor_percentual"] ?> ?? 0;
         var pagamentos = [];
         let meses_pendentes = <?= $meses_pendentes; ?>;
         let id_mes = 0;
         let conRepe = 0;
         let mesPagar;
         let total = 0;
         let valorProprina = 0;
         let multa = 0;
         let id_aluno = <?= $_GET['id']; ?>
        
         function voltarId_mes(){
            if(id_mes === 0){
                fetch(`../Config/buscar_mesesNP.php?id_aluno=${id_aluno}`)
                    .then(Response => Response.json())
                    .then(data => {
                    if(data.length === 0){
                        id_mes = 9;
                    }else{
                        data.forEach(mesP => {
                            id_mes = mesP.id_mes + 1;
                        });
                        console.log(data)
                    }
                    
                    }); 
            }
         }
         document.addEventListener("DOMContentLoaded", function(){
            if(id_mes === 0){
                fetch(`../Config/buscar_mesesNP.php?id_aluno=${id_aluno}`)
                    .then(Response => Response.json())
                    .then(data => {
                    if(data.length === 0){
                        id_mes = 9;
                    }else{
                        data.forEach(mesP => {
                            id_mes = mesP.id_mes + 1;
                        });
                    }
                    
                    }); 
            }
         });
function abrirModalPagamento() {
    document.getElementById("modalOpcao").style.display = "none";
    document.getElementById("modalPagamento").style.display = "flex";
}
function abrirModalCertificado(){
      document.getElementById("modalOpcao").style.display = "none";
       document.getElementById("modalCertificado").style.display = "flex";
}
function abrirModalDeclaracao(){
      document.getElementById("modalOpcao").style.display = "none";
       document.getElementById("modalDeclaracao").style.display = "flex";
}
function abrirModalOpcao(){
       document.getElementById("modalOpcao").style.display = "flex";
}
function fecharModal(nome) {
    document.getElementById(nome).style.display = "none";
}
function fecharModalPagamento() {
    document.getElementById("modalPagamento").style.display = "none";
}
    let indexP = -1;
    function actualizarCarrinho(){
        const tbody = document.getElementById('carrinho');
        const cancelar = document.getElementById('cancelar');
        tbody.innerHTML="";
        pagamentos.forEach((item, index) => {
        const tr = document.createElement('tr');
        tr.innerHTML=`<td>${item.mesPagar}</td><td>${item.valorProprina}</td><td>${item.multa}</td><td>${item.desconto}</td><td>${item.total}</td>`;
        tbody.appendChild(tr);
        document.getElementById('desconto').value = 0;
        ScrollTopLast();
     });
   }
   function ScrollTopLast(){
       let cart = document.getElementById("cart");
       cart.scrollTop = cart.scrollHeight;
   }
   function removerIntem(){
      pagamentos.splice(0, pagamentos.length);
      meses_pendentes = <?= $meses_pendentes; ?>;
      id_mes = 0;
      voltarId_mes();
      actualizarCarrinho();
   };
   document.getElementById('addPag').addEventListener('click', function(){

    valor_propinaLiquido = (valor_proprinaBruto*valor_percentualBruto)/100; 
    const desconto = document.getElementById('desconto').value ?? 0;   

    valorProprina = valor_propinaLiquido+valor_proprinaBruto;

     if(valorProprina < desconto || desconto < 0){
       document.getElementById("modalPagamento").style.zIndex="9";
       document.getElementById("Erro").style.display="block";
       document.getElementById("textErro").innerText="O desconto não pode ser muito elevado ao valor da propina.";
       desconto = 0;
       exit();
    }
    if(meses_pendentes >= 1){
       let dataMes =``;
       fetch(`../Config/buscar_mes.php?id=${id_mes}`)
            .then(Response => Response.json())
            .then(data => {
                data.forEach(mes =>{
                    mesPagar = mes.mes;
                    dataMes = mes.data ?? '0000-00-00';
                    let dataActual = ``;
                    dataActual = `<?php echo date("Y-m-d"); ?>`

                    if(dataActual > dataMes){
                        let multa_percentual = <?= $multa ?? 0 ?>;
                        let result_multa = 0;
                        result_multa = (valorProprina * multa_percentual)/100;
                        multa = result_multa;
                    }else{
                        multa = 0;
                    }

                    total = (valorProprina + multa) - desconto; 
                    pagamentos.push({mesPagar, valorProprina, multa, desconto, total});
                    actualizarCarrinho();
                });

            }); 
            meses_pendentes-=1;
    }else{
        document.getElementById("modalPagamento").style.zIndex="9";
        document.getElementById("Erro").style.display="block";
        document.getElementById("textErro").innerText="infelizmente ja nao pode adicionar mais pagamentos";
    }
    if(id_mes >= 12){
        id_mes = 1;
        conRepe += 1; 
    }else{
        id_mes += 1; 
    }
    if(id_mes >= 9 && conRepe === 1){
         conRepe = 2;
    }
    });

    function confirmarPagamento(){
        if(pagamentos.length === 0){
            document.getElementById("modalPagamento").style.zIndex="9";
            document.getElementById("Erro").style.display="block";
            document.getElementById("textErro").innerText="A tabela de pagamento está vazia";
        }else{
            document.getElementById('pagamentoInp').value = JSON.stringify(pagamentos);
            document.getElementById('id_alunoInp').value = id_aluno;
            document.getElementById('id_mesInp').value = id_mes - 1;
            event.target.form.submit();
           
        }
    }
    function voltrarPag(){
        document.getElementById("modalPagamento").style.zIndex="900000000000000000000000000";
        document.getElementById('Erro').style.display="none";}


        // Função para abrir o modal de edição
function abrirModalEditar() {
    // Obter o ID do aluno da URL
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id');
    
    // Preencher os campos do formulário com os dados do aluno
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_BI').value = "<?= $aluno['BI'] ?>";
    document.getElementById('edit_nome').value = "<?= $aluno['nome'] ?>";
    document.getElementById('edit_data_nasc').value = "<?= $aluno['data_nascimento'] ?>";
    document.getElementById('edit_morada').value = "<?= $aluno['morada'] ?>";
    document.getElementById('edit_numero_encarregado').value = "<?= $aluno['numero_encarregado'] ?>";
    
    // Definir a classe selecionada
    const classeSelect = document.getElementById('edit_classe');
    for (let i = 0; i < classeSelect.options.length; i++) {
        if (classeSelect.options[i].value === "<?= $aluno['id_classe'] ?>") {
            classeSelect.selectedIndex = i;
            break;
        }
    }
    
    // Definir o curso selecionado
    const cursoSelect = document.getElementById('edit_curso');
    for (let i = 0; i < cursoSelect.options.length; i++) {
        if (cursoSelect.options[i].value === "<?= $aluno['id_curso'] ?>") {
            cursoSelect.selectedIndex = i;
            break;
        }
    }
    
    // Carregar as turmas disponíveis
    carregarTurmas();
    
    // Exibir o modal
    document.getElementById('modalEditar').style.display = "flex";
}

// Função para carregar as turmas com base no curso selecionado
function carregarTurmas() {
    const cursoId = document.getElementById('edit_curso').value;
    const turmaSelect = document.getElementById('edit_turma');
    
    // Limpar as opções existentes
    turmaSelect.innerHTML = '<option value="" disabled selected>Carregando...</option>';
    
    // Buscar as turmas disponíveis para o curso
    fetch(`../Config/buscar_turmas.php?id_curso=${cursoId}`)
        .then(response => response.json())
        .then(data => {
            turmaSelect.innerHTML = '<option value="" disabled selected>Selecione uma turma</option>';
            
            data.turmas.forEach(turma => {
                const option = document.createElement('option');
                option.value = turma.id_turma;
                option.textContent = turma.nome;
                
                // Selecionar a turma atual do aluno
                if (turma.id_turma === "<?= $aluno['id_turma'] ?>") {
                    option.selected = true;
                }
                
                turmaSelect.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Erro ao carregar turmas:', error);
            turmaSelect.innerHTML = '<option value="" disabled selected>Erro ao carregar turmas</option>';
        });
}

// Adicionar evento de change ao select de curso para carregar as turmas
document.getElementById('edit_curso').addEventListener('change', carregarTurmas);

// Modificar o evento de clique no botão de editar para chamar a função de abrir o modal
document.querySelector('.btn-edit').addEventListener('click', function(e) {
    e.preventDefault();
    abrirModalEditar();
});
    </script>
	 <script src='../Scritps/Menu.js'></script>
</body>
</html>