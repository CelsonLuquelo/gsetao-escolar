<?php
session_start();
require '../Config/conexaoBD.php';


if (!isset($_GET['id_aluno'])) {
    die("Fatura não encontrada.");
}

$id_aluno = $_GET['id_aluno'] ?? 0;
$tipoEstagio = $_GET['tipoEstagio'] ?? null;
$valorEstagio = $_GET['valor_estagio'] ?? 0;
$modoPagamento = $_GET['modoPagamento'];
$activaDeclaracao = $_GET['declaracao'] ?? null;
$activaCertificado = $_GET['certificado'] ?? null;


$stmt = $pdo->prepare("SELECT * FROM informacoes_basicas");
$stmt->execute();
$infor = $stmt->fetch(PDO::FETCH_ASSOC);


$stmtAluno = $pdo->prepare("SELECT 
   a.*, cl.nome AS ClasseAluno, c.curso, t.turno, t.nome AS turma, t.sala
FROM alunos a
JOIN classe cl ON a.id_classe = cl.id_classe
JOIN cursos c ON a.id_curso = c.id_curso
JOIN turmas t ON a.id_turma = t.id_turma
WHERE a.id_aluno = $id_aluno
    ORDER BY a.id_aluno ASC");
$stmtAluno->execute();
$alunos = $stmtAluno->fetch(PDO::FETCH_ASSOC);

$totalgeral1 = 0; 
$totalgeral2 = 0; 

?>

<!DOCTYPE html>
<html>
<head>
    <title>Factura recibo</title>
    <style>
        body { font-family: 'Times New Roman', Times, serif; }
        .fatura { width: 95%; margin: auto; padding: 20px;}
       .fatura h5 { text-align: center; font-size: 16px;}
        .tabela { width: 100%; margin-top: 5px; border-collapse: collapse; border-top: 2px solid black;}
        .tabela th, .tabela td { border: 2px solid black; font-size: 13px; padding: 10px; text-align: center; }
        .tabela td{padding: 2px 10px;}
        .tabela th{padding: 2px 10px;}
        .btn-imprimir { display: block; position: fixed; border-radius: 9px; cursor: pointer;  box-shadow: 0px 0px 10px rgba(0, 0, 0, .5); padding: 10px; border: 1px solid #ddd;  width: 150px; left: 90%; top: 85%; transform: translate(-50%, -50%); text-align: center; }
        .ContInformacao{display: flex; width: 98%; padding: 2px 10px; margin-bottom: 20px; margin-top: 20px;}
        .ContInfAluno, .ContInfEscola{ display: block;  width: 100%; padding: auto;}
        .SubFim{text-align: center; margin-top: 30px;}
        .SubFim span{display: block; margin: 0 auto}
        .linha{display: block; border-top: 1px solid black; width: 25%; margin: 0 auto;}
        .ContInfAluno{width: 150%;}
        .ContInfAluno p, .ContInfEscola p{ margin: 0px; font-size: 16px;}
        .ContInfAluno strong, .ContInfEscola strong{margin-right: 7%;}
        .divisao{margin: 20px 0px; border: 1px dashed black;}
        @media print {
             body { margin: 0 !important; padding: 0 -200px !important;}
            .factura { padding: 10px !important; margin: a auto !important; position: relative; width: 96% !important; height: 100vh; box-shadow: none !important; border: none !important; }
            .btn-imprimir { display: none; }
            .ContInformacao{width: 97% !important;}
            .voltar{display: none;}
            table { width: 100%; font-size: 20px;  margin: 0 !important; }
        }
    </style>
</head>
<body>
    <button class="btn-imprimir" onclick="window.print()">Imprimir</button>
    <?php if(isset($activaDeclaracao)): ?>
    <a href="detalhes_aluno.php?id=<?= $alunos['id_aluno'] ?>" class="voltar">Voltar</a>
    <div class="fatura">
        <p style="text-align: center;">REPÚBLICA DE ANGOLA</p>
        <p style="text-align: center; margin-top: -10px;">MINISTÉRIO DA EDUCUDAÇÃO</p>
        <div style="display: flex; width: 100%; border: 1px solid black;">
            <div style="display: flex; width: 30%; padding: 10px; border: 1px solid black;">
               <img src="../arquivos/Logotipo/LOGO ICRA.jpg" style="margin: 0 auto; display: block;" width="70px" height="70px" class="logotipo" alt="">
            </div>
            <div style="display: flex; justify-content: center; align-items: center; width: 70%; border: 1px solid black;">
                <p style="text-align: center;">INSTITUTO DE CIÊNCIAS RELIGIOSAS DE ANGOLA</p>
            </div>
        </div>
        <h2 style="text-align: center;">Recibo de pagamento de declaração</h2>
        <br>
        <div class="ContInformacao">
            <div class="ContInfAluno">
                <p>Nome: <strong><?= $alunos['nome'] ?></strong> Data de nascimento: <strong><?= date("d/m/Y", strtotime($alunos['data_nascimento'])) ?></strong></p>
                <p>Idade: <strong><?= $alunos['idade'] ?></strong> Morada: <strong><?= $alunos['morada'] ?></strong></p>
                <p>BI: <strong><?= $alunos['BI'] ?></strong></p>
                 <p>Número do encarregado: <strong><?= $alunos['numero_encarregado'] ?></strong></p>
            </div>
            <div class="ContInfEscola">
                <p>Curso: <strong><?= $alunos['curso'] ?></strong></p>
                 <p>Turma: <strong><?= $alunos['turma'] ?></strong> Turno: <strong><?= $alunos['turno'] ?></strong></p>
                 <p>Classe: <strong><?= $alunos['ClasseAluno'] ?>ª</strong> Sala: <strong><?= $alunos['sala'] ?></strong></p>
                 <p>Data de Emissão: <strong><?= date("d/m/Y"); ?></strong></p>
            </div>
        </div>
            <br>
            <table class="tabela">
            <tr>
               <th colspan="4" style="font-size: 14px;"><strong>Pagamento de Declaração</strong></th>
            </tr> 
            <tr>
                <th>Descrição</th>
                <th>Modo Pagamento</th>
                <th>Valor (Kz)</th>
                <th>Total (Kz)</th>
            </tr>
            <tr>
                <td>Declaração</td>
                <td><?= $modoPagamento ?></td>
                <td><?= $infor['valor_declaracao'] ?></td>
                <td><?= $infor['valor_declaracao'] ?></td>
            </tr>
        </table>           
            <br>
        <h4 style="text-align: center;">Informações da Instituição</h4>
          <div class="ContInfAluno" style="margin: 20px; display: flex; width: 100%; text-align: center;">
            <div style="display: block; width: 100%; ">
                <p>Contactos: <strong><?= $infor['Contactos'] ?></strong></p>
                <p>NIF: <strong><?= $infor['NIF'] ?></strong></p>
                <p>Email: <strong><?= $infor['email'] ?></strong></p>
            </div>
            <div style="display: block; width: 100%;"> 
                <p>IBAN: <strong><?= $infor['IBAN'] ?></strong></p>
                <p>Data de pagamento: <strong><?= date("d-m-Y")?></strong></p>
            </div>
        </div>
        <br>
         <div class="SubFim">
            <span class="linha"></span>
            <span><strong><?= $_SESSION['nome'] ?></strong></span>
            <span>(funcionário de serviço)</span>
         </div>
    </div>
     <?php elseif(isset($activaCertificado)): ?>
        <a href="detalhes_aluno.php?id=<?= $alunos['id_aluno'] ?>" class="voltar">Voltar</a>
    <div class="fatura">
        <p style="text-align: center;">REPÚBLICA DE ANGOLA</p>
        <p style="text-align: center; margin-top: -10px;">MINISTÉRIO DA EDUCUDAÇÃO</p>
        <div style="display: flex; width: 100%; border: 1px solid black;">
            <div style="display: flex; width: 30%; padding: 10px; border: 1px solid black;">
               <img src="../arquivos/Logotipo/LOGO ICRA.jpg" style="margin: 0 auto; display: block;" width="70px" height="70px" class="logotipo" alt="">
            </div>
            <div style="display: flex; justify-content: center; align-items: center; width: 70%; border: 1px solid black;">
                <p style="text-align: center;">INSTITUTO DE CIÊNCIAS RELIGIOSAS DE ANGOLA</p>
            </div>
        </div>
        <h2 style="text-align: center;">Recibo de pagamento de certificado</h2>
        <br>
        <div class="ContInformacao">
            <div class="ContInfAluno">
                <p>Nome: <strong><?= $alunos['nome'] ?></strong> Data de nascimento: <strong><?= date("d/m/Y", strtotime($alunos['data_nascimento'])) ?></strong></p>
                <p>Idade: <strong><?= $alunos['idade'] ?></strong> Morada: <strong><?= $alunos['morada'] ?></strong></p>
                <p>BI: <strong><?= $alunos['BI'] ?></strong></p>
                 <p>Número do encarregado: <strong><?= $alunos['numero_encarregado'] ?></strong></p>
            </div>
            <div class="ContInfEscola">
                <p>Curso: <strong><?= $alunos['curso'] ?></strong></p>
                 <p>Turma: <strong><?= $alunos['turma'] ?></strong> Turno: <strong><?= $alunos['turno'] ?></strong></p>
                 <p>Classe: <strong><?= $alunos['ClasseAluno'] ?>ª</strong> Sala: <strong><?= $alunos['sala'] ?></strong></p>
                 <p>Data de Emissão: <strong><?= date("d/m/Y"); ?></strong></p>
            </div>
        </div>
            <br>
            <table class="tabela">
            <tr>
               <th style="font-size: 14px; " colspan="4"><strong>Pagamento de certificado</strong></th>
            </tr> 
            <tr>
                <th>Descrição</th>
                <th>Modo Pagamento</th>
                <th>Valor (Kz)</th>
                <th>Total (Kz)</th>
            </tr>
            <tr>
                <td>certificado</td>
                <td><?= $modoPagamento ?></td>
                <td><?= $infor['valor_certificado'] ?></td>
                <td><?= $infor['valor_certificado'] ?></td>
            </tr>
        </table>           
            <br>
        <h4 style="text-align: center;">Informações da Instituição</h4>
          <div class="ContInfAluno" style="margin: 20px; display: flex; width: 100%; text-align: center;">
            <div style="display: block; width: 100%; ">
                <p>Contactos: <strong><?= $infor['Contactos'] ?></strong></p>
                <p>NIF: <strong><?= $infor['NIF'] ?></strong></p>
                <p>Email: <strong><?= $infor['email'] ?></strong></p>
            </div>
            <div style="display: block; width: 100%;"> 
                <p>IBAN: <strong><?= $infor['IBAN'] ?></strong></p>
                <p>Data de pagamento: <strong><?= date("d-m-Y")?></strong></p>
            </div>
        </div>
        <br>
         <div class="SubFim">
            <span class="linha"></span>
            <span><strong><?= $_SESSION['nome'] ?></strong></span>
            <span>(funcionário de serviço)</span>
         </div>
    </div>
     <?php else:; ?>
          <a href="Alunos.php" class="voltar">Voltar</a>
    <div class="fatura">
        <p style="text-align: center;">REPÚBLICA DE ANGOLA</p>
        <p style="text-align: center; margin-top: -10px;">MINISTÉRIO DA EDUCUDAÇÃO</p>
        <div style="display: flex; width: 100%; border: 1px solid black;">
            <div style="display: flex; width: 30%; padding: 10px; border: 1px solid black;">
               <img src="../arquivos/Logotipo/LOGO ICRA.jpg" style="margin: 0 auto; display: block;" width="70px" height="70px" class="logotipo" alt="">
            </div>
            <div style="display: flex; justify-content: center; align-items: center; width: 70%; border: 1px solid black;">
                <p style="text-align: center;">INSTITUTO DE CIÊNCIAS RELIGIOSAS DE ANGOLA</p>
            </div>
        </div>
        <h2 style="text-align: center;">Matricula de Aluno</h2>
        <br>
        <div class="ContInformacao">
            <div class="ContInfAluno">
                <p>Nome: <strong><?= $alunos['nome'] ?></strong> Data de nascimento: <strong><?= date("d/m/Y", strtotime($alunos['data_nascimento'])) ?></strong></p>
                <p>Idade: <strong><?= $alunos['idade'] ?></strong> Morada: <strong><?= $alunos['morada'] ?></strong></p>
                <p>BI: <strong><?= $alunos['BI'] ?></strong></p>
                 <p>Número do encarregado: <strong><?= $alunos['numero_encarregado'] ?></strong></p>
            </div>
            <div class="ContInfEscola">
                <p>Curso: <strong><?= $alunos['curso'] ?></strong></p>
                 <p>Turma: <strong><?= $alunos['turma'] ?></strong> Turno: <strong><?= $alunos['turno'] ?></strong></p>
                 <p>Classe: <strong><?= $alunos['ClasseAluno'] ?>ª</strong> Sala: <strong><?= $alunos['sala'] ?></strong></p>
                 <p>Data de Emissão: <strong><?= date("d/m/Y"); ?></strong></p>
            </div>
        </div>
        <table class="tabela">
            <?php if(strlen($tipoEstagio) > 0): ?>
                <tr>
                  <th colspan="6" style="font-size: 14px;"><strong>Pagamento de Matricula</strong></th>
                </tr>          
            <?php endif; ?>
            <tr>
                <th>Descrição</th>
                <th>Modo Pagamento</th>
                <th>Matricula (Kz)</th>
                <th>Cartão (Kz)</th>
                <th>Uniforme (Kz)</th>
                <th>Total (Kz)</th>
            </tr>
            <tr>
                <td>Inscrição</td>
                <td><?= $modoPagamento ?></td>
                <td><?= $infor['valor_Matricula'] ?></td>
                <td><?= $infor['valor_cartao'] ?></td>
                <td><?= $infor['valor_uniforme'] ?></td>
                <td><?= $infor['valor_Matricula'] + $infor['valor_cartao'] + $infor['valor_uniforme'] ?></td>
            </tr>
        </table>
            <?php if(strlen($tipoEstagio) > 0): ?>
                <br>
            <table class="tabela">
            <tr>
               <th colspan="6" style="font-size: 14px;"><strong>Pagamento de Estágio</strong></th>
            </tr> 
            <tr>
                <th>Descrição</th>
                <th>Modo Pagamento</th>
                <th>tipo de Estágio</th>
                <th>Valor (Kz)</th>
                <th>Total (Kz)</th>
            </tr>
            <tr>
                <td>Estágio</td>
                <td><?= $modoPagamento ?></td>
                 <td><?= $tipoEstagio ?></td>
                <td><?= $valorEstagio ?></td>
                <td><?= $valorEstagio ?></td>
            </tr>
        </table>           
            <?php endif; ?>
            <br>
        <h4 style="text-align: center;">Informações da Instituição</h4>
          <div class="ContInfAluno" style="margin: 20px; display: flex; width: 100%; text-align: center;">
            <div style="display: block; width: 100%; ">
                <p>Contactos: <strong><?= $infor['Contactos'] ?></strong></p>
                <p>NIF: <strong><?= $infor['NIF'] ?></strong></p>
                <p>Email: <strong><?= $infor['email'] ?></strong></p>
            </div>
            <div style="display: block; width: 100%;"> 
                <p>IBAN: <strong><?= $infor['IBAN'] ?></strong></p>
                <p>Data de pagamento: <strong><?= date("d-m-Y")?></strong></p>
            </div>
        </div>
        <br>
         <div class="SubFim">
            <span class="linha"></span>
            <span><strong><?= $_SESSION['nome'] ?></strong></span>
            <span>(funcionário de serviço)</span>
         </div>
    </div>
     <?php endif; ?>
</body>
</html>