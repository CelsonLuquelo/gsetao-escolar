<?php
session_start();
include('../Config/conexaoBD.php');

// Verifica se o usuário está logado com permissões adequadas
if ($_SESSION['nivel_acesso'] === "secretario") {
    header("Location: inicio.php");
    $_SESSION['notification'] = "Não tens acesso a página de actualizações.";
    $_SESSION['estado'] = "erro";
    exit();
}

// Buscar cursos
$cursos = $conn->query("SELECT * FROM cursos");

// Consulta para listar classes (usado no cadastro e edição de turmas)
$stmt_classes = $pdo->prepare("SELECT id_classe, nome FROM classe");
$stmt_classes->execute();
$classes = $stmt_classes->fetchAll(PDO::FETCH_ASSOC);

// Filtro de curso selecionado
$cursoSelecionado = isset($_GET['curso']) ? $_GET['curso'] : "";

// Buscar turmas com filtro
$turmas = $conn->query("
    SELECT t.*, c.curso AS Curso, cl.nome AS Classe, cl.id_classe, t.limite_aluno
    FROM turmas t
    JOIN cursos c ON t.id_curso = c.id_curso
    JOIN classe cl ON t.id_classe = cl.id_classe
    " . ($cursoSelecionado ? " WHERE c.id_curso = '$cursoSelecionado' ORDER BY c.curso, t.nome ASC" : "ORDER BY c.curso, t.nome ASC") ."
");
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Gestão de Turmas</title>
    <link rel="stylesheet" href="../Bibiliotecas/Bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="../Bibiliotecas/Font-Awesome-6.x/css/all.min.css">
    <style type="text/css">
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #1c1c3c, #3b3b92);
            color: white;
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* ✅ Container Principal */
        .container {
            max-width: 95%;
            padding: 20px;
        }

        /* ✅ Botões de Ação */
        .aluno-acoes {
            display: flex;
            gap: 10px;
            justify-content: center;
            margin: 10px auto;
        }

        .aluno-acoes button {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 14px;
            border: none;
            cursor: pointer;
            transition: 0.3s;
            display: flex;
            align-items: center;
            gap: 5px;
            font-weight: bold;
        }

        .aluno-acoes button i {
            font-size: 16px;
        }

        .aluno-acoes button:hover {
            transform: scale(1.1);
        }

        thead {
            font-size: 14px;
        }

        td {
            font-size: 12px;
            color: white;
            padding: 0 5px; 
        }

        td, th {
            max-width: 0px;
            border: 1px solid #ddd;
            text-align: center;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            word-wrap: break-word;
        }

        table th {
            font-weight: bold;
            padding: 8px;
        }

        /* Cores diferentes para cada ação */
        .btn-editar { background: #ffc107; }
        .btn-editar:hover { background: #e0a800; }

        .btn-excluir { background: #dc3545; }
        .btn-excluir:hover { background: #c82333; }

        .searchTurma {
            width: 40%;
            font-size: 16px;
            border-radius: 8px;
            border: none;
            outline: none;
            display: block;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            backdrop-filter: blur(10px);
            transition: 0.3s;
        }

        .turma-card {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.05));
            backdrop-filter: blur(10px);
            box-shadow: 0px 4px 10px rgba(255, 255, 255, 0.2);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .aluno-card:hover {
            transform: scale(1.05);
            box-shadow: 0px 8px 20px rgba(255, 255, 255, 0.3);
        }

        .searchTurma label { background: rgba(0, 0, 0, 3); color: #fff; }
        .searchTurma select { background: rgba(0, 0, 0, 0); }
        
        .modal-content {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
        }

        /* ✅ Modais */
        .modal2 {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            z-index: 10000000000000000000000000000000;
            background: rgba(0, 0, 0, 0.7);
            justify-content: center;
            align-items: center;
            animation: fadeIn 0.3s;
        }

        .modal2::-webkit-scrollbar {
            width: 10px;
            height: 10px;
        }

        .modal2::-webkit-scrollbar-thumb {
            background-color: rgb(98, 98, 98);
            border-radius: 5px;
        }

        .modal-content2 {
            background: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 500px;
            text-align: center;
            backdrop-filter: blur(10px);
            position: relative;
        }

        .btn-salvar {
            border: none;
            margin-top: 10px;
            border-radius: 10px;
            padding: 10px;
        }

        .modal-content2 input, .modal-content2 select {
            padding: 10px;
            border-radius: 9px;
            border: none;
            width: 95%;
            margin-bottom: 10px;
        }

        .modal-content2 label {
            margin-left: 10px;
            display: block;
            text-align: left;
            margin-bottom: 5px;
        }

        .modal2 h2 {
            font-size: 20px;
            margin-bottom: 15px;
        }

        .close {
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 22px;
            cursor: pointer;
            transition: 0.3s;
        }

        .close:hover {
            color: red;
        }

        /* Destaque para a classe */
        .classe-badge {
            background: linear-gradient(135deg, #ff8c00, #ff2d00);
            color: white;
            padding: 3px 10px;
            border-radius: 15px;
            font-weight: bold;
            display: inline-block;
            margin-left: 10px;
        }

        .turma-header {
            display: flex;
            align-items: center;
        }

        /* ✅ Animações */
        @keyframes fadeIn {
            from { opacity: 0; transform: scale(0.9); }
            to { opacity: 1; transform: scale(1); }
        }

        /* Responsividade */
        @media (max-width: 768px) {
            .aluno-acoes {
                flex-direction: column;
            }
            .searchTurma {
                width: 90%;
            }
        }
    </style>
</head>
<body class="bg-light">
<?php require "Menu.php"; ?>
<div class="container py-5">
<div class="ContHora"><i class="fas fa-clock"></i><span style="font-size: 20px;" id="recebHora"></span></div>
        
        <div class="dashboard-header">
            <img src="../arquivos/Logotipo/LOGO ICRA.jpg" alt="Logo ICRA">
             <h1 class="fw-bold text-primary"><i class="fas fa-school me-2"></i> Gestão de Turmas</h1>
    </div>
    
    <button class="btn btn-success px-4 mb-3" data-bs-toggle="modal" data-bs-target="#modalTurma">
        <i class="fas fa-plus-circle me-2"></i> Adicionar Turma
    </button>

    <!-- Filtro de Cursos -->
    <form method="GET" class="mb-4 searchTurma">
        <div class="input-group">
            <label class="input-group-text"><i class="fas fa-graduation-cap"></i> Curso</label>
            <select class="form-select" name="curso" onchange="this.form.submit()">
                <option value="">Todos os cursos</option>
                <?php while ($c = $cursos->fetch_assoc()): ?>
                    <option value="<?= $c['id_curso'] ?>" <?= $cursoSelecionado == $c['id_curso'] ? 'selected' : '' ?>>
                        <?= $c['curso'] ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
    </form>

    <!-- Cards das Turmas -->
    <div class="row g-4">
        <?php while ($turma = $turmas->fetch_assoc()): ?>
            <div class="col-12">
                <div class="card turma-card shadow-sm border-start border-5 border-primary rounded-4" data-bs-toggle="collapse" data-bs-target="#alunos<?= $turma['id_turma'] ?>" style="cursor:pointer;">
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <div class="turma-header w-25">
                            <h4 class="text-primary m-0" style="font-size: 45px;"><i class="fas fa-users-class me-2"></i> <?= $turma['nome'] ?></h4>
                            <span class="classe-badge"><?= $turma['Classe'] ?>ª Classe</span>
                        </div>
                        <div class="w-75">
                            <div class="bg-secondary text-white rounded px-3 py-2 mb-2">
                                <i class="fas fa-book me-2"></i> Curso: <span style="font-size: 24px; color: #ff8c00;"><?= $turma['Curso'] ?></span> 
                                <div class="mt-1">
                                    <span class="badge bg-info mx-1"><i class="fas fa-clock me-1"></i> <?= $turma['turno'] ?></span>
                                    <span class="badge bg-warning text-dark mx-1"><i class="fas fa-door-open me-1"></i> Sala <?= $turma['sala'] ?></span>
                                </div>
                                <?php
                                    // Buscar total de alunos por turma
                                    $alunos = $conn->query("SELECT * FROM alunos WHERE id_turma = " . $turma['id_turma']);
                                    $totalAlunos = $alunos->num_rows;
                                    
                                    // Calcular percentual de ocupação
                                    $ocupacao = ($turma['limite_aluno'] > 0) ? ($totalAlunos / $turma['limite_aluno']) * 100 : 0;
                                    $barColor = ($ocupacao > 90) ? 'danger' : (($ocupacao > 70) ? 'warning' : 'success');
                                ?>
                                <div class="mt-2">
                                    <strong>Alunos:</strong> <?= $totalAlunos ?> / <?= $turma['limite_aluno'] ?>
                                    <div class="progress mt-1" style="height: 10px;">
                                        <div class="progress-bar bg-<?= $barColor ?>" role="progressbar" 
                                             style="width: <?= $ocupacao ?>%;" 
                                             aria-valuenow="<?= $ocupacao ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                            <!-- Alunos -->
                            <div id="alunos<?= $turma['id_turma'] ?>" class="collapse">
                                <table class="table table-bordered table-hover mt-2">
                                    <thead class="table-light">
                                        <tr>
                                            <th><i class="fas fa-user"></i> Nome</th>
                                            <th><i class="fas fa-id-card"></i> Matrícula</th>
                                            <th><i class="fas fa-hourglass-half"></i> Idade</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $alunos->data_seek(0); // Reset result pointer
                                        if ($alunos->num_rows > 0) {
                                            while ($aluno = $alunos->fetch_assoc()):
                                        ?>
                                        <tr>
                                            <td><?= $aluno['nome'] ?></td>
                                            <td><?= $aluno['matricula'] ?></td>
                                            <td><?= $aluno['idade'] ?></td>
                                        </tr>
                                        <?php 
                                            endwhile; 
                                        } else {
                                            echo '<tr><td colspan="3" class="text-center">Nenhum aluno cadastrado nesta turma</td></tr>';
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                   <div class="aluno-acoes">
                        <button class="btn-editar" onclick="EditarTurma(<?= $turma['id_turma'] ?>, <?= $turma['sala'] ?>, <?= $turma['limite_aluno'] ?>, '<?= $turma['turno'] ?>', '<?= $turma['Curso'] ?>', <?= $turma['id_classe'] ?>)">
                            <i class="fas fa-edit"></i> Editar
                        </button>
                        <button class="btn-excluir" onclick="abrirModalExcluir(<?= $turma['id_turma'] ?>)">
                            <i class="fa-solid fa-trash"></i> Excluir
                        </button>
                   </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<!-- Modal Excluir -->
<div id="modalExcluir" class="modal2">
    <div class="modal-content2">
        <span class="close" onclick="fecharModal('modalExcluir')"><i class="fa-solid fa-xmark"></i></span>
        <h2><i class="fa-solid fa-trash"></i> Excluir Turma</h2>
        <p>Tem certeza que deseja excluir esta Turma?</p>
        <p>Ao excluir esta turma também estará a excluir todos alunos associados a ela.</p>
        <form id="formExcluir" method="POST" action="../Config/excluir_turma.php">
            <input type="hidden" name="id" id="deleteId">
            <button type="submit" class="btn-salvar" style="background-color: red;"><i class="fa-solid fa-trash"></i> Sim, Excluir</button>
        </form>
    </div>
</div>

<!-- Modal de Adicionar Turma -->
<div class="modal fade" id="modalTurma" tabindex="-1" aria-labelledby="modalTurmaLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" action="../Config/add_turma.php" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-plus-circle me-2"></i>Nova Turma</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label"><i class="fas fa-clock me-2"></i> Turno:</label>
                        <select name="turno" class="form-select" required>
                            <option value="">Selecione</option>
                            <option value="Manhã">Manhã</option>
                            <option value="Tarde">Tarde</option>
                            <option value="Noite">Noite</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label"><i class="fas fa-door-open me-2"></i> Sala:</label>
                        <input type="number" min="1" class="form-control" name="sala" required>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label"><i class="fas fa-graduation-cap me-2"></i> Curso:</label>
                        <select name="curso_id" class="form-select" required>
                            <option value="">Selecione o curso</option>
                            <?php
                            $cursos->data_seek(0); // resetar cursos
                            while ($c = $cursos->fetch_assoc()):
                            ?>
                                <option value="<?= $c['id_curso'] ?>"><?= $c['curso'] ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label"><i class="fas fa-users me-2"></i> Limite de alunos:</label>
                        <input type="number" min="1" class="form-control" name="limite" required>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <label class="form-label"><i class="fas fa-layer-group me-2"></i> Classe:</label>
                        <select name="id_classe" class="form-select" required>
                            <option value="" disabled selected>Selecione uma classe</option>
                            <?php foreach ($classes as $classe): ?>
                                <option value="<?= $classe['id_classe'] ?>"><?= $classe['nome'] ?>ª</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save me-2"></i>Salvar Turma</button>
            </div>
        </form>
    </div>
</div>

<!-- ✅ MODAL EDITAR TURMA -->
<div id="modalEditar" class="modal2">
    <div class="modal-content2">
        <span class="close" onclick="fecharModal('modalEditar')"><i class="fa-solid fa-xmark"></i></span>
        <h2><i class="fas fa-edit"></i> Editar Turma</h2>
        
        <form id="formEditar" action="../Config/editar_turma.php" method="POST">
            <input type="hidden" name="id_turma" id="edit_id_turma">
            
            <div class="form-group">
                <label><i class="fas fa-graduation-cap me-2"></i> Curso:</label>
                <p id="curso" class="form-control-static" style="background: rgba(255,255,255,0.1); padding: 8px; border-radius: 5px;"></p>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-clock me-2"></i> Turno:</label>
                <p id="turno" class="form-control-static" style="background: rgba(255,255,255,0.1); padding: 8px; border-radius: 5px;"></p>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-door-open me-2"></i> Sala:</label>
                <input type="number" min="1" name="sala" id="sala" required>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-users me-2"></i> Limite de alunos:</label>
                <input type="number" min="1" name="limite" id="limite" required>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-layer-group me-2"></i> Classe:</label>
                <select name="id_classe" id="id_classe" class="form-select" required>
                    <?php 
                    $stmt_classes->execute();
                    $classes = $stmt_classes->fetchAll(PDO::FETCH_ASSOC);
                    foreach ($classes as $classe): 
                    ?>
                        <option value="<?= $classe['id_classe'] ?>"><?= $classe['nome'] ?>ª</option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <button type="submit" class="btn-salvar" style="background-color: #ffc107;">
                <i class="fas fa-save"></i> Salvar Alterações
            </button>
        </form>
    </div>
</div>

<script src="../Bibiliotecas/Bootstrap/bootstrap.bundle.min.js"></script>
<script type="text/javascript">
    let modal;
    let herancaAbrir;

    function abrirModal(id) {
        herancaAbrir = document.getElementById(id);
        modal = document.getElementById(id);
        modal.style.display = "flex";
        modal.classList.add("fade-in");
    }

    function abrirModalExcluir(alunoId) {
        document.getElementById('deleteId').value = alunoId;
        abrirModal('modalExcluir');
    }

    // Fechar Modal
    function fecharModal(id) {
        modal = document.getElementById(id);
        modal.classList.remove("fade-in");
        setTimeout(() => {
            modal.style.display = "none";
        }, 200);
    }

    function EditarTurma(id_turma, sala, limite, turno, curso, id_classe) {
        document.getElementById("edit_id_turma").value = id_turma;
        document.getElementById("sala").value = sala;
        document.getElementById("limite").value = limite;
        document.getElementById("turno").innerText = turno;
        document.getElementById("curso").innerText = curso;
        document.getElementById("id_classe").value = id_classe;
        
        abrirModal('modalEditar');
    }  

    // Fechar de outra forma
    window.addEventListener("click", function(e) {
        if(e.target === herancaAbrir) {
            herancaAbrir.classList.remove("fade-in");
            setTimeout(() => {
                herancaAbrir.style.display = "none";
            }, 200);
        }
    });
</script>
 <script src='../Scritps/Menu.js'></script>
</body>
</html>