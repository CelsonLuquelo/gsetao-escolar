<?php
session_start();
require '../Config/conexaoBD.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    die("ID do aluno não fornecido.");
}

$id = $_GET['id'];

// Busca os dados atuais do sistema
$sql = "SELECT * FROM informacoes_basicas WHERE id = 1";
$result = $conn->query($sql);
$infor = $result->fetch_assoc();

$queryOpag = $pdo->prepare("SELECT c.status AS estadoC, d.status AS estadoD, e.status AS estadoE FROM outros_pagamentos op 
    JOIN certificado c ON op.id_certificado = c.id_certificado 
    JOIN declaracao d ON op.id_declaracao = d.id_declaracao 
    JOIN estagio e ON op.id_estagio = e.id_estagio 
    JOIN alunos a ON op.id_aluno = a.id_aluno
    WHERE a.id_aluno = ?");
$queryOpag->execute([$id]);
$Opag = $queryOpag->fetch(PDO::FETCH_ASSOC);

// Buscar dados do aluno
$queryAluno = $pdo->prepare("SELECT a.*, t.nome As turma, c.valor_percentual AS Valor_percentual, c.nome AS NomeClasse, 
    cu.valor_proprina AS Valor_Proprina, cu.curso, a.data_nascimento, a.BI
    FROM alunos a 
    JOIN classe c ON a.id_classe = c.id_classe 
    JOIN cursos cu ON a.id_curso = cu.id_curso 
    JOIN turmas t ON a.id_turma = t.id_turma 
    WHERE a.id_aluno = ?
    ORDER BY a.created_at DESC");
$queryAluno->execute([$id]);
$aluno = $queryAluno->fetch(PDO::FETCH_ASSOC);

if (!$aluno) {
    die("Aluno não encontrado.");
}

// Calcular idade a partir da data de nascimento
$dataNascimento = new DateTime($aluno['data_nascimento']);
$hoje = new DateTime();
$idade = $dataNascimento->diff($hoje)->y;

// Buscar pagamentos do aluno
$queryPagamentos = $pdo->prepare("SELECT * FROM pagamentos WHERE id_aluno = ?");
$queryPagamentos->execute([$id]);
$pagamentos = $queryPagamentos->fetchAll(PDO::FETCH_ASSOC);

// Buscar meses
$queryMeses = $pdo->prepare("SELECT * FROM meses ORDER BY data ASC");
$queryMeses->execute();
$mesesP = $queryMeses->fetchAll(PDO::FETCH_ASSOC);

// Buscar multa percentual
$queryMulta = $pdo->prepare("SELECT multa_percentual FROM informacoes_basicas");
$queryMulta->execute();
$multa_percentual = $queryMulta->fetchAll(PDO::FETCH_ASSOC);
$multa = 0;
foreach($multa_percentual as $multa_per){
     $multa = $multa_per['multa_percentual'];
}

$dadosPagamentos = [];
foreach ($pagamentos as $p) {
    $dadosPagamentos[$p['mes']] = $p;
}

 //Buscar meses pagos 
 $stmtPagos = $pdo->prepare("SELECT CONCAT(ano, '-', mes) FROM pagamentos WHERE id_aluno = ? AND pagamentos.status = 'pago'");
 $stmtPagos->execute([$id]);
 $meses_p = $stmtPagos->fetchAll(PDO::FETCH_COLUMN);
 $meses_pagos = count($meses_p);

 $meses_pendentes = 12 - $meses_pagos; 
 
// Buscar meses
$sqlMeses = "SELECT * FROM meses ORDER BY data ASC";
$resultMeses = $conn->query($sqlMeses);
$meses = [];
while ($row = $resultMeses->fetch_assoc()) {
    $meses[] = $row;
}

$anoAtual = date("Y");

// Calcular o valor total da propina (inclui percentual de classe)
$valor_propinaLiquido = $aluno["Valor_Proprina"] + ($aluno["Valor_Proprina"] * $aluno["Valor_percentual"])/100; 




?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalhes do Aluno - <?= $aluno['nome'] ?></title>
    <link rel="icon" type="image/x-png" href="../arquivos/Logotipo/LOGO ICRA.jpg">
    <link rel="stylesheet" href="../Bibiliotecas/pace-1.2.4/themes/red/pace-theme-center-atom.css">
    <script src="../Bibiliotecas/pace-1.2.4/pace.min.js"></script>
    <link rel="stylesheet" href="../Bibiliotecas/Font-Awesome-6.x/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../Styles/detalhes_alunoT.css">
</head>
<body>
    <!-- Menu -->
    <?php require "Menu.php"; ?>
    
    <div class="container">
        <h1 class="page-title">Ficha do Aluno</h1>
        
        <div class="aluno-profile">
            <div class="profile-header">
                <div class="profile-image">
                    <img src="../arquivos/fotos_dos_alunos/<?= $aluno['foto'] ?>" alt="Foto de <?= $aluno['nome'] ?>">
                </div>
                <div class="profile-info">
                    <h2><?= $aluno['nome'] ?></h2>
                    <p class="student-id">ID: <?= $aluno['id_aluno'] ?></p>
                    <div class="status-badge <?= $meses_pendentes > 0 ? 'pending' : 'paid' ?>">
                        <?= $meses_pendentes > 0 ? 'Pendente' : 'Em dia' ?>
                    </div>
                </div>
            </div>
            
            <div class="profile-actions">
                <button id="efectuarPag" onclick="abrirModalOpcao()" class="btn-payment">
                    <i class="fas fa-money-bill-wave"></i> Efetuar Pagamento
                </button>
                <a href="Historico_factura.php?id=<?= $id ?>" class="btn-history">
                    <i class="fas fa-history"></i> Histórico de Faturas
                </a>
                <a href="editar_aluno.php?id=<?= $id ?>" class="btn-edit">
                    <i class="fas fa-user-edit"></i> Editar Dados
                </a>
            </div>

            <div class="profile-details">
                <div class="detail-section">
                    <h3><i class="fas fa-user"></i> Dados Pessoais</h3>
                    <div class="details-grid">
                        <div class="detail-item">
                            <span class="detail-label">Nome Completo:</span>
                            <span class="detail-value"><?= $aluno['nome'] ?></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Data de Nascimento:</span>
                            <span class="detail-value"><?= date('d/m/Y', strtotime($aluno['data_nascimento'])) ?></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Idade:</span>
                            <span class="detail-value"><?= $idade ?> anos</span>
                        </div>
						   <div class="detail-item">
                            <span class="detail-label">BI:</span>
                            <span class="detail-value"><?= $aluno['BI'] ?></span>
                        </div>
                    </div>
                </div>

                <div class="detail-section">
                    <h3><i class="fas fa-map-marker-alt"></i> Contato</h3>
                    <div class="details-grid">
                        <div class="detail-item">
                            <span class="detail-label">Endereço:</span>
                            <span class="detail-value"><?= $aluno['morada'] ?></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Telefone:</span>
                            <span class="detail-value"><?= $aluno['numero_encarregado'] ?></span>
                        </div>
                    </div>
                </div>

                <div class="detail-section">
                    <h3><i class="fas fa-graduation-cap"></i> Dados Académicos</h3>
                    <div class="details-grid">
                        <div class="detail-item">
                            <span class="detail-label">Curso:</span>
                            <span class="detail-value"><?= $aluno['curso'] ?></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Classe:</span>
                            <span class="detail-value"><?= $aluno['NomeClasse'] ?>ª</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Turma:</span>
                            <span class="detail-value"><?= $aluno['turma'] ?></span>
                        </div>
                    </div>
                </div>

                <div class="detail-section">
                    <h3><i class="fas fa-money-check-alt"></i> Informações Financeiras</h3>
                    <div class="details-grid financial-grid">
                        <div class="detail-item highlight">
                            <span class="detail-label">Valor da Própina:</span>
                            <span class="detail-value"><?= number_format($valor_propinaLiquido, 2, ',', '.') ?> Kz</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Pagamentos Feitos:</span>
                            <span class="detail-value"><?= $meses_pagos ?> meses</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Pagamentos Pendentes:</span>
                            <span class="detail-value"><?= $meses_pendentes ?> meses</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Taxa de Multa:</span>
                            <span class="detail-value"><?= $multa ?>%</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="payment-status">
            <h3><i class="fas fa-calendar-check"></i> Status de Pagamentos de Propina</h3>
            <div class="meses-container">
                <?php foreach ($meses as $mes) :
                $nomeMes = $mes['mes'];
                $dataMes = $mes['data'];

                // Verificar se o aluno pagou o mês atual
                $sqlPagamento = "SELECT * FROM pagamentos WHERE id_aluno = '$id' AND mes = '$nomeMes' AND ano = '$anoAtual' AND status = 'pago'";
                $resultPagamento = $conn->query($sqlPagamento);

                if ($resultPagamento->num_rows > 0) {
                    $cor = "pago"; // Verde (Pago)
                    $icon = "fa-check-circle";
                } else {
                    $dataMesTime = strtotime($dataMes);
                    $dataAtualTime = strtotime(date("Y-m-d"));

                    if ($dataMesTime < $dataAtualTime) {
                        $cor = "divida"; // Vermelho (Atrasado)
                        $icon = "fa-exclamation-circle";
                    } else {
                        $cor = "futuro"; // Cinza (Pendente)
                        $icon = "fa-clock";
                    }
                }
                ?>
                <div class="mes <?= $cor ?>">
                    <div class="card-body">
                        <i class="fas <?= $icon ?>"></i>
                        <h4 class="card-title"><?= $nomeMes ?></h4>
                        <span class="card-text"><?= date("d/m/Y", strtotime($dataMes)) ?></span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <h3><i class="fas fa-file-invoice"></i> Status de Outros Pagamentos</h3>
            <div class="outros-pagamentos">
                <?php if ($aluno["NomeClasse"] == "13ª"): ?>
                    <?php if ($Opag["estadoE"] == "pendente") {
                        $corE = "pendente"; 
                        $iconE = "fa-times-circle";
                    } else {
                        $corE = "pago";
                        $iconE = "fa-check-circle";
                    } ?>
                    <div class="pagamento-item <?= $corE ?>">
                        <i class="fas <?= $iconE ?>"></i>
                        <div class="pagamento-info">
                            <h4>Estágio</h4>
                            <span><?= ucfirst($corE) ?></span>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if ($aluno["NomeClasse"] != "13ª"): ?>
                    <?php if ($Opag["estadoD"] == "pendente") {
                        $corD = "pendente";
                        $iconD = "fa-times-circle";
                    } else {
                        $corD = "pago";
                        $iconD = "fa-check-circle";
                    } ?>
                    <div class="pagamento-item <?= $corD ?>">
                        <i class="fas <?= $iconD ?>"></i>
                        <div class="pagamento-info">
                            <h4>Declaração</h4>
                            <span><?= ucfirst($corD) ?></span>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if ($aluno["NomeClasse"] == "13ª"): ?>
                    <?php if ($Opag["estadoC"] == "pendente") {
                        $corC = "pendente";
                        $iconC = "fa-times-circle";
                    } else {
                        $corC = "pago";
                        $iconC = "fa-check-circle";
                    } ?>
                    <div class="pagamento-item <?= $corC ?>">
                        <i class="fas <?= $iconC ?>"></i>
                        <div class="pagamento-info">
                            <h4>Certificado</h4>
                            <span><?= ucfirst($corC) ?></span>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
 
    <!-- Modal de erro -->
    <div id="Erro" class="error-modal">
        <div class="error-content">
            <button onclick="fecharErro()" class="close-btn">
                <i class="fa-solid fa-xmark"></i>
            </button>
            <i class="fas fa-exclamation-triangle error-icon"></i>
            <p id="textErro" class="error-message"></p>
        </div>
    </div>

    <!-- Modal de Opções de Pagamento -->
    <div id="modalOpcao" class="modal">
        <div class="modal-content">
            <span class="close" onclick="fecharModal('modalOpcao')">
                <i class="fa-solid fa-xmark"></i>
            </span>
            <h2>Opções de Pagamento</h2>

            <div class="payment-options">
                <button type="button" onclick="abrirModalPagamento()" class="option-btn propina">
                    <i class="fas fa-money-bill"></i> Propina
                </button>
                
                <?php if ($aluno["NomeClasse"] != "13ª" && $Opag["estadoD"] != "pago"): ?>
                <button type="button" onclick="abrirModalDeclaracao()" class="option-btn declaracao">
                    <i class="fas fa-file-alt"></i> Declaração
                </button>
                <?php endif; ?>
                
                <?php if ($aluno["NomeClasse"] == "13ª" && $Opag["estadoC"] != "pago"): ?>
                <button type="button" onclick="abrirModalCertificado()" class="option-btn certificado">
                    <i class="fas fa-certificate"></i> Certificado
                </button>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Modal de Pagamento de Propina -->
    <div id="modalPagamento" class="modal">
        <div class="modal-content">
            <span class="close" onclick="fecharModalPagamento()">
                <i class="fa-solid fa-xmark"></i>
            </span>
            <h2>Pagamento de Propina</h2>
            
            <div class="payment-form">
                <input type="hidden" id="aluno_id" value="<?= $aluno['id_aluno'] ?>">
                <div class="form-group">
                    <label for="desconto">
                        <i class="fas fa-percent"></i> Desconto (Kz):
                    </label>
                    <input type="number" id="desconto" name="desconto" value="0" max="<?= $valor_propinaLiquido ?>" min="0">
                </div>
                <button id='addPag' class="add-btn">
                    <i class="fas fa-plus"></i> Adicionar Mês
                </button>
            </div>

            <div class="payment-table" id="cart">
                <h3><i class="fas fa-list"></i> Meses a Pagar</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Mês</th>
                            <th>Valor (Kz)</th>
                            <th>Multa (Kz)</th>
                            <th>Desconto (Kz)</th>
                            <th>Total (Kz)</th>
                        </tr>
                    </thead>
                    <tbody id="carrinho">
                        <!-- Itens do carrinho serão adicionados dinamicamente -->
                    </tbody>
                </table>
                
                <div class="payment-actions">
                    <button type="button" class="confirm-btn" onclick="confirmarPagamento()">
                        <i class="fas fa-check"></i> Confirmar
                    </button>
                    <button type="button" class="cancel-btn" id="cancelar" onclick="removerIntem()">
                        <i class="fas fa-times"></i> Cancelar
                    </button>
                </div>
                
                <form action="../Config/processar_pagamento.php" method="post" id="paymentForm">
                    <input type="hidden" id="pagamentoInp" name="dados">
                    <input type="hidden" id="id_alunoInp" name="id_aluno">
                    <input type="hidden" id="id_mesInp" name="id_mes">
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Certificado -->
    <div id="modalCertificado" class="modal">
        <div class="modal-content">
            <span class="close" onclick="fecharModal('modalCertificado')">
                <i class="fa-solid fa-xmark"></i>
            </span>
            <h2>Pagamento de Certificado</h2>
            <form id="formCertificado" method="GET" action="../Config/pagamentoCertificado.php">
                <input type="hidden" name="id_aluno" value="<?= $aluno['id_aluno'] ?>">
                <input type="hidden" name="valor_certificado" value="<?= $infor['valor_certificado'] ?>">
                <input type="hidden" name="certificado" value="certificado">
                
                <div class="cert-info">
                    <div class="info-item">
                        <span class="info-label">Valor do Certificado:</span>
                        <span class="info-value"><?= number_format($infor['valor_certificado'], 2, ',', '.') ?> Kz</span>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="modoPagamentoC">
                        <i class="fas fa-credit-card"></i> Modo de Pagamento:
                    </label>
                    <select name="modoPagamento" id="modoPagamentoC" required>
                        <option value="Dinheiro">Dinheiro</option>
                        <option selected value="Multicaixa">Multicaixa</option>
                    </select>
                </div>
                
                <button type="submit" class="pay-btn">
                    <i class="fas fa-check-circle"></i> Efetuar Pagamento
                </button>
            </form>
        </div>
    </div>

    <!-- Modal Declaração -->
    <div id="modalDeclaracao" class="modal">
        <div class="modal-content">
            <span class="close" onclick="fecharModal('modalDeclaracao')">
                <i class="fa-solid fa-xmark"></i>
            </span>
            <h2>Pagamento de Declaração</h2>
            <form id="formDeclaracao" method="GET" action="../Config/pagamentoDeclaracao.php">
                <input type="hidden" name="id_aluno" value="<?= $aluno['id_aluno'] ?>">
                <input type="hidden" name="valor_declaracao" value="<?= $infor['valor_declaracao'] ?>">
                <input type="hidden" name="declaracao" value="declaracao">
                
                <div class="cert-info">
                    <div class="info-item">
                        <span class="info-label">Valor da Declaração:</span>
                        <span class="info-value"><?= number_format($infor['valor_declaracao'], 2, ',', '.') ?> Kz</span>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="modoPagamentoD">
                        <i class="fas fa-credit-card"></i> Modo de Pagamento:
                    </label>
                    <select name="modoPagamento" id="modoPagamentoD" required>
                        <option value="Dinheiro">Dinheiro</option>
                        <option selected value="Multicaixa">Multicaixa</option>
                    </select>
                </div>
                
                <button type="submit" class="pay-btn">
                    <i class="fas fa-check-circle"></i> Efetuar Pagamento
                </button>
            </form>
        </div>
    </div>

    <script>
        // Variáveis globais
        let valor_proprinaBruto = <?= $aluno["Valor_Proprina"] ?? 0 ?>;
        let valor_percentualBruto = <?= $aluno["Valor_percentual"] ?? 0 ?>;
        let pagamentos = [];
        let meses_pendentes = <?= $meses_pendentes ?>;
        let id_mes = 0;
        let conRepe = 0;
        let mesPagar;
        let total = 0;
        let valorProprina = 0;
        let multa = 0;
        let id_aluno = <?= $_GET['id'] ?>;
        

    document.addEventListener("DOMContentLoaded", function(){
        buscarProximoMesPendente();
    });

     // Funções para buscar o próximo mês pendente
        function buscarProximoMesPendente() {
            if(id_mes === 0) {
                fetch(`../Config/buscar_mesesNP.php?id_aluno=${id_aluno}`)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Erro na resposta da rede');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if(data.length === 0) {
                            id_mes = 1; // Se não houver meses pendentes, começar do primeiro
                        } else {
                            // Pegar o último mês pendente e adicionar 1
                            let ultimoMes = data[data.length - 1];
                            id_mes = ultimoMes.id_mes + 1;
                            
                            // Se passar de 12, voltar para 1
                            if (id_mes > 12) {
                                id_mes = 1;
                            }
                        }
                    })
                    .catch(error => {
                        console.error('Erro ao buscar meses pendentes:', error);
                        mostrarErro('Erro ao buscar meses pendentes. Por favor, tente novamente.');
                    });
            }
        }

        // Funções de modal
        function abrirModalPagamento() {
            document.getElementById("modalOpcao").style.display = "none";
            document.getElementById("modalPagamento").style.display = "flex";
        }
        
        function abrirModalCertificado() {
            document.getElementById("modalOpcao").style.display = "none";
            document.getElementById("modalCertificado").style.display = "flex";
        }
        
        function abrirModalDeclaracao() {
            document.getElementById("modalOpcao").style.display = "none";
            document.getElementById("modalDeclaracao").style.display = "flex";
        }
        
        function abrirModalOpcao() {
            document.getElementById("modalOpcao").style.display = "flex";
        }
        
        function fecharModal(nome) {
            document.getElementById(nome).style.display = "none";
        }
        
        function fecharModalPagamento() {
            document.getElementById("modalPagamento").style.display = "none";
        }
        
        function fecharErro() {
            document.getElementById("Erro").style.display = "none";
        }
        
        function mostrarErro(mensagem) {
            document.getElementById("textErro").innerText = mensagem;
            document.getElementById("Erro").style.display = "block";
        }
        
        // Funções do carrinho de pagamentos
        function atualizarCarrinho() {
            const tbody = document.getElementById('carrinho');
            tbody.innerHTML = "";
            
            if (pagamentos.length === 0) {
                const tr = document.createElement('tr');
                tr.innerHTML = '<td colspan="5">Nenhum mês adicionado</td>';
                tbody.appendChild(tr);
                return;
            }
            
            let totalGeral = 0;
            
            pagamentos.forEach((item, index) => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${item.mesPagar}</td>
                    <td>${formatarValor(item.valorProprina)}</td>
                    <td>${formatarValor(item.multa)}</td>
                    <td>${formatarValor(item.desconto)}</td>
                    <td>${formatarValor(item.total)}</td>
                `;
                tbody.appendChild(tr);
                totalGeral += parseFloat(item.total);
            });
            
            // Adicionar linha de total geral
            const trTotal = document.createElement('tr');
            trTotal.className = "total-row";
            trTotal.innerHTML = `
                <td colspan="4">Total Geral</td>
                <td>${formatarValor(totalGeral)}</td>
            `;
            tbody.appendChild(trTotal);
            
            document.getElementById('desconto').value = 0;
            scrollToBottom();
        }
        
        function formatarValor(valor) {
            return parseFloat(valor).toLocaleString('pt-AO', { 
                minimumFractionDigits: 2, 
                maximumFractionDigits: 2 
            });
        }
        
        function scrollToBottom() {
            let cart = document.getElementById("cart");
            cart.scrollTop = cart.scrollHeight;
        }
        
        function removerIntem() {
        pagamentos.splice(0, pagamentos.length);
        meses_pendentes = <?= $meses_pendentes ?>;
        id_mes = 0;
        buscarProximoMesPendente();
        atualizarCarrinho();
    }
    
    // Adicionar pagamento
    document.getElementById('addPag').addEventListener('click', function() {
        // Calcular valor da propina
        let valor_propinaLiquido = valor_proprinaBruto + (valor_proprinaBruto * valor_percentualBruto) / 100;
        const desconto = parseFloat(document.getElementById('desconto').value) || 0;
        
        valorProprina = valor_propinaLiquido;
        
        // Validar desconto
        if (valorProprina < desconto || desconto < 0) {
            mostrarErro("O desconto não pode ser maior que o valor da propina ou negativo.");
            document.getElementById('desconto').value = 0;
            return;
        }
        
        // Verificar se ainda há meses pendentes para pagar
        if (meses_pendentes >= 1) {
            fetch(`../Config/buscar_mes.php?id=${id_mes}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Erro na resposta da rede');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.length > 0) {
                        const mes = data[0];
                        mesPagar = mes.mes;
                        const dataMes = mes.data || '0000-00-00';
                        const dataAtual = '<?php echo date("Y-m-d"); ?>';
                        
                        // Calcular multa se o pagamento estiver atrasado
                        if (dataAtual > dataMes) {
                            const multa_percentual = <?= $multa ?? 0 ?>;
                            multa = (valorProprina * multa_percentual) / 100;
                        } else {
                            multa = 0;
                        }
                        
                        // Calcular total
                        total = (valorProprina + multa) - desconto;
                        
                        // Adicionar ao array de pagamentos
                        pagamentos.push({
                            mesPagar, 
                            valorProprina, 
                            multa, 
                            desconto, 
                            total
                        });
                        
                        atualizarCarrinho();
                        meses_pendentes -= 1;
                        
                        // Atualizar id_mes para o próximo mês
                        if (id_mes >= 12) {
                            id_mes = 1;
                            conRepe += 1;
                        } else {
                            id_mes += 1;
                        }
                        
                        if (id_mes >= 9 && conRepe === 1) {
                            conRepe = 2;
                        }
                    }
                })
                .catch(error => {
                    console.error('Erro ao buscar informações do mês:', error);
                    mostrarErro('Erro ao buscar informações do mês. Por favor, tente novamente.');
                });
        } else {
            mostrarErro("Não há mais meses pendentes para adicionar ao pagamento.");
        }
    });
    
    function confirmarPagamento() {
        if (pagamentos.length === 0) {
            mostrarErro("A tabela de pagamento está vazia. Adicione pelo menos um mês para pagar.");
            return;
        }
        
        // Preparar dados para envio
        document.getElementById('pagamentoInp').value = JSON.stringify(pagamentos);
        document.getElementById('id_alunoInp').value = id_aluno;
        document.getElementById('id_mesInp').value = id_mes - 1;
        
        // Enviar formulário
        document.getElementById('paymentForm').submit();
    }
</script>
 <script src='../Scritps/Menu.js'></script>
</body>
</html>