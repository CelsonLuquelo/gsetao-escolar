<?php
session_start();
require '../Config/conexaoBD.php';

if (!isset($_GET['id'])) {
    die("Fatura não encontrada.");
}

$id_aluno = $_GET['id'] ?? 0;


$stmt = $pdo->prepare("SELECT * FROM informacoes_basicas");
$stmt->execute();
$infor = $stmt->fetch(PDO::FETCH_ASSOC);

$stmtAluno = $pdo->prepare("SELECT nome FROM alunos WHERE id_aluno = ?");
$stmtAluno->execute([$id_aluno]);
$Nome = $stmtAluno->fetch(PDO::FETCH_ASSOC);


$query = "SELECT 
    f.id_factura, a.nome, c.curso, cl.nome AS classeNome, a.numero_encarregado, a.matricula, t.nome As turma, p.mes, p.multa, p.data_created, p.desconto, p.total, p.valor
FROM facturas f
JOIN pagamentos p ON f.id_pagamento = p.id_pagamento
JOIN alunos a ON f.id_aluno = a.id_aluno
JOIN classe cl ON a.id_classe = cl.id_classe
JOIN cursos c ON a.id_curso = c.id_curso
JOIN turmas t ON a.id_turma = t.id_turma
WHERE f.id_aluno = $id_aluno
GROUP BY  f.id_factura, a.nome, a.numero_encarregado, c.curso, a.matricula, t.nome, p.mes, p.multa, p.desconto, p.total, p.valor
    ORDER BY f.id_pagamento ASC";
$result = mysqli_query($conn, $query);


?>
<!DOCTYPE html>
<html>
<head>
    <title>Factura recibo</title>
    <style>
        body { font-family: 'Times New Roman', Times, serif; }
        .fatura { width: 95%; margin: auto; padding: 20px; border: 1px solid #ddd;}
       .fatura h5 { text-align: center; font-size: 16px;}
        .tabela { width: 100%; margin-top: 5px; border-collapse: collapse; border-top: 2px solid black;}
        .tabela th, .tabela td { border: 2px solid black; font-size: 13px; padding: 10px; text-align: center; }
        .tabela td{padding: 2px 10px;}
        .tabela th{padding: 2px 10px;}
        .btn-imprimir { display: block; position: fixed; border-radius: 9px; cursor: pointer;  box-shadow: 0px 0px 10px rgba(0, 0, 0, .5); padding: 10px; border: 1px solid #ddd;  width: 150px; left: 90%; top: 85%; transform: translate(-50%, -50%); text-align: center; }
        .ContInformacao{display: flex; width: 98%; padding: 2px 10px; border: 1px solid black}
        .ContInfAluno, .ContInfEscola{ display: block;  width: 100%; padding: auto;}
        .SubFim{text-align: center; margin-top: 30px;}
        .linha{display: block; border-top: 1px solid black; width: 25%; margin: 0 auto;}
        .ContInfAluno p, .ContInfEscola p{ margin: 0px; font-size: 16px;}
        .divisao{margin: 20px 0px; border: 1px dashed black;}
        @media print {
             body { margin: 0 !important; padding: -30px -200px !important;}
            .factura { padding: 10px !important; margin: a auto !important; position: relative; width: 96% !important; height: 100vh; box-shadow: none !important; border: none !important; }
            .btn-imprimir { display: none; }
            .ContInformacao{width: 97% !important;}
            table { width: 100%; font-size: 20px;  margin: 0 !important; }
            .ImprimirEste{display: none;}
        }
    </style>
    </style>
</head>
<body>
<script>
    window.addEventListener("DOMContentLoaded",function(){
        var dados = [];
        dados[] = <?= $facturas?>;
       console.log(<?= $facturas?>);
       alert(<?= $facturas ?>)
    });
</script>
    <button class="btn-imprimir" onclick="window.print()">Imprimir</button>
     <h1 style="text-align: center;">Facturas (<?= $Nome['nome'] ?>)</h1>
    <?php while ($factura = mysqli_fetch_assoc($result)) {  $totalgeral = 0;  $totalgeral += $factura['total'];?>
    <div class="fatura">
        <a class="ImprimirEste" href="imprimir_uma_factura.php?id_factura=<?= $factura['id_factura']?>">Imprimir Este</a>
        <img src="../arquivos/Logotipo/LOGO ICRA.jpg" style="margin: 0 auto; display: block;" width="70px" height="70px" class="logotipo" alt="">
        <h5>INSTITUTO DE CIÊNCIAS RELIGIOSAS DE ANGOLA</h5>
        <div class="ContInformacao">
            <div class="ContInfAluno">

                 <p>Nome: <strong><?= $factura['nome'] ?></strong></p>
                 <p>Classe: <strong><?= $factura['classeNome'] ?>ª</strong> &nbsp;&nbsp;&nbsp;Turma: <strong><?= $factura['turma'] ?></strong></p>
                 <p>Curso: <strong><?= $factura['curso'] ?></strong></p>
                 <p>Matricula: <strong><?= $factura['matricula'] ?></strong></p>
                 <p>Numero de Encarregado: +244 <strong><?= $factura['numero_encarregado'] ?></strong></p>
    
            </div>
            <div class="ContInfEscola">
                <p>Contactos: <strong>244 <?= $infor['Contactos'] ?></strong></p>
                <p>NIF: <strong><?= $infor['NIF'] ?></strong></p>
                <p>IBAN: <strong><?= $infor['IBAN'] ?></strong></p>
                <p>Data de pagamento: <strong><?= date('d/m/Y', strtotime($factura['data_created']))?></strong></p>
            </div>
        </div>
        <table class="tabela">
            <tr>
                <th>Emolumento</th>
                <th>Mês</th>
                <th>Modo Pagamento</th>
                <th>Valor (Kz)</th>
                <th>Multa (Kz)</th>
                <th>Desconto (Kz)</th>
                <th>Total (Kz)</th>
            </tr>
            <tr>
                <td>Mensalidade</td>
                <td><?= $factura['mes'] ?></td>
                <td>Multicaixa</td>
                <td><?= $factura['valor'] ?></td>
                <td><?= $factura['multa'] ?></td>
                <td><?= $factura['desconto'] ?></td>
                <td><?= $factura['total'] ?></td>
            </tr>
            <tr>
                <td colspan="7">Total geral (Kz): <strong><?= $totalgeral ?></strong></td>
            </tr>
        </table>
         <div class="SubFim">
            <span class="linha"></span>
            <span><strong><?= $_SESSION['nome'] ?></strong><br>(funcionário de serviço)</span>
         </div>
    </div>
    <div class="divisao"></div>
    <?php } ?>
</body>
</html>
