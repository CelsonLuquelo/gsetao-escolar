<?php 
session_start();
require '../Config/conexaoBD.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}

// Buscar alunos por classe
$queryClasses = "SELECT c.nome AS classeAL, COUNT(a.id_aluno) AS total FROM alunos a 
                 JOIN classe c ON a.id_classe = c.id_classe 
                 GROUP BY c.id_classe
                 ORDER BY c.nome ASC";
$resultClasses = $conn->query($queryClasses);
$classes = [];
$quantidadeClasses = [];
while ($row = $resultClasses->fetch_assoc()) {
    $classes[] = $row['classeAL']."ª";
    $quantidadeClasses[] = $row['total'];
}

// Buscar alunos por curso
$queryCursos = "SELECT cu.curso AS cursoAL, COUNT(a.id_aluno) AS total FROM alunos a 
                JOIN cursos cu ON a.id_curso = cu.id_curso 
                GROUP BY cu.id_curso
                ORDER BY total DESC";
$resultCursos = $conn->query($queryCursos);
$cursosAl = [];
$quantidadeCursosA = [];
while ($row = $resultCursos->fetch_assoc()) {
    $cursosAl[] = $row['cursoAL'];
    $quantidadeCursosA[] = $row['total'];
}

// Buscar quantidade de pagamentos por mês
$queryPagamentos = "SELECT MONTH(data_created) AS mesPag, COUNT(id_pagamento) AS total 
                    FROM pagamentos 
                    WHERE YEAR(data_created) = YEAR(CURDATE()) 
                    GROUP BY MONTH(data_created)
                    ORDER BY mesPag ASC";
$resultPagamentos = $conn->query($queryPagamentos);

$meses = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
$mesesAbrev = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
$pagamentosMensais = array_fill(0, 12, 0);

while ($row = $resultPagamentos->fetch_assoc()) {
    $pagamentosMensais[$row['mesPag'] - 1] = $row['total'];
}

// Buscar a soma total de pagamentos por curso
$queryPagamentosPorCurso = "SELECT c.curso AS cursoAL, SUM(p.total) AS total_pagamentos 
    FROM pagamentos p
    JOIN alunos a ON p.id_aluno = a.id_aluno
    JOIN cursos c ON a.id_curso = c.id_curso
    GROUP BY c.id_curso
    ORDER BY total_pagamentos DESC";

$result = $conn->query($queryPagamentosPorCurso);

$cursos = [];
$pagamentos = [];

while ($row = $result->fetch_assoc()) {
    $cursos[] = $row['cursoAL'];
    $pagamentos[] = $row['total_pagamentos'];
}

// Buscar a quantidade de alunos por ano letivo
$queryCrescimento = "SELECT YEAR(created_at) AS ano_letivo, COUNT(id_aluno) AS total_alunos 
    FROM alunos 
    GROUP BY YEAR(created_at)
    ORDER BY ano_letivo ASC";

$result = $conn->query($queryCrescimento);

$anos = [];
$total_alunos = [];

while ($row = $result->fetch_assoc()) {
    $anos[] = $row['ano_letivo'];
    $total_alunos[] = $row['total_alunos'];
}

// Buscar pagamentos dos últimos 7 dias
$queryPagDiario = "SELECT DATE_FORMAT(data_created, '%d/%m') AS dia, SUM(total) AS total FROM pagamentos 
    WHERE DATE(data_created) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) 
    GROUP BY DATE(data_created) 
    ORDER BY data_created ASC";
$resultPagDiario = $conn->query($queryPagDiario);

$PagDia = [];
$PagTotal = [];
while ($row = $resultPagDiario->fetch_assoc()) {
    $PagDia[] = $row['dia'];
    $PagTotal[] = $row['total'];
}

// Função para gerar cores aleatórias
function gerarCoresAleatorias($quantidade) {
    $cores = [];
    for ($i = 0; $i < $quantidade; $i++) {
        // Gerar componentes RGB aleatórios
        $r = rand(50, 220);
        $g = rand(50, 220);
        $b = rand(50, 220);
        $cores[] = "rgba($r, $g, $b, 0.8)";
    }
    return $cores;
}

// Total de alunos
$queryTotalAlunos = "SELECT COUNT(*) AS total FROM alunos";
$resultTotalAlunos = $conn->query($queryTotalAlunos);
$totalAlunos = $resultTotalAlunos->fetch_assoc()['total'];

// Total de pagamentos (valor)
$queryTotalPagamentos = "SELECT SUM(total) AS total FROM pagamentos WHERE YEAR(data_created) = YEAR(CURDATE())";
$resultTotalPagamentos = $conn->query($queryTotalPagamentos);
$totalPagamentos = $resultTotalPagamentos->fetch_assoc()['total'];

// Total de pagamentos (quantidade)
$queryQtdPagamentos = "SELECT COUNT(*) AS total FROM pagamentos WHERE YEAR(data_created) = YEAR(CURDATE())";
$resultQtdPagamentos = $conn->query($queryQtdPagamentos);
$qtdPagamentos = $resultQtdPagamentos->fetch_assoc()['total'];

// Total de cursos
$queryTotalCursos = "SELECT COUNT(*) AS total FROM cursos";
$resultTotalCursos = $conn->query($queryTotalCursos);
$totalCursos = $resultTotalCursos->fetch_assoc()['total'];

function formatarValor($valor) {
    return number_format($valor, 2, ',', '.') . ' Kz';
}

// Gerar cores aleatórias para os gráficos
$qtdCores = max(count($classes), count($cursosAl), count($cursos), 12);
$coresAleatorias = gerarCoresAleatorias($qtdCores);
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema ICRA - Dashboard</title>
    <link rel="icon" type="image/x-png" href="../arquivos/Logotipo/LOGO ICRA.jpg">
    <link rel="stylesheet" href="../Bibiliotecas/pace-1.2.4/themes/red/pace-theme-center-atom.css">
    <script src="../Bibiliotecas/pace-1.2.4/pace.min.js"></script>
    <link rel="stylesheet" href="../Bibiliotecas/icomoon/style.css">
    <link rel="stylesheet" href="../Styles/inicio.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
   <link rel="stylesheet" href="../Styles/inicio.css">
</head>
<body>
    <!--Menu Interativo-->
    <?php require 'Menu.php'; ?>
  
    <!--Conteúdo Principal-->
    <div class="container">
        <div class="ContHora"><i class="fas fa-clock"></i><span style="font-size: 20px;" id="recebHora"></span></div>
        
        <div class="dashboard-header">
            <img src="../arquivos/Logotipo/LOGO ICRA.jpg" alt="Logo ICRA">
            <h1><i class="fas fa-chart-line"></i> Dashboard ICRA</h1>
        </div>
        
        <!-- Estatísticas Resumidas -->
        <div class="stats-cards">
            <div class="stat-card">
                <h3><i class="fas fa-user-graduate stat-icon"></i> Total de Alunos</h3>
                <div class="stat-value"><?php echo $totalAlunos; ?></div>
            </div>
            <div class="stat-card">
                <h3><i class="fas fa-money-bill-wave stat-icon"></i> Pagamentos Anuais</h3>
                <div class="stat-value"><?php echo formatarValor($totalPagamentos); ?></div>
            </div>
            <div class="stat-card">
                <h3><i class="fas fa-receipt stat-icon"></i> Qtd. Pagamentos</h3>
                <div class="stat-value"><?php echo $qtdPagamentos; ?></div>
            </div>
            <div class="stat-card">
                <h3><i class="fas fa-book stat-icon"></i> Total de Cursos</h3>
                <div class="stat-value"><?php echo $totalCursos; ?></div>
            </div>
        </div>
        
        <!-- Gráficos -->
        <div class="cards" id="cards">
            <div class="card">
                <h3><i class="fas fa-calendar-week"></i> Pagamentos dos Últimos 7 Dias</h3>
                <canvas id="pagamentosDiarios"></canvas>
            </div>

            <div class="card"> 
                <h3><i class="fas fa-layer-group"></i> Alunos por Classe</h3>
                <canvas id="graficoClasses"></canvas>
            </div>
            
            <div class="card">
                <h3><i class="fas fa-graduation-cap"></i> Alunos por Curso</h3>
                <canvas id="graficoCursos"></canvas>
            </div>
            
            <div class="card">
                <h3><i class="fas fa-chart-bar"></i> Pagamentos Mensais <?php echo date('Y'); ?></h3>
                <canvas id="graficoPagamentos"></canvas>
            </div>
            
            <div class="card">
                <h3><i class="fas fa-chart-pie"></i> Distribuição de Pagamentos por Curso</h3>
                <canvas id="graficoPagamentosCurso"></canvas>
            </div>
            
            <div class="card">
                <h3><i class="fas fa-chart-line"></i> Evolução do Número de Alunos</h3>
                <canvas id="graficoCrescimento"></canvas>
            </div>
        </div>
    </div>
  
    <script src='../Scritps/Menu.js'></script>
    <script>
        // Configurações comuns para todos os gráficos
        Chart.defaults.font.family = "'Segoe UI', 'Helvetica Neue', 'Helvetica', 'Arial', sans-serif";
        Chart.defaults.font.size = 12;
        Chart.defaults.color = '#ffffff';
        
        // Cores aleatórias para os gráficos
        const coresAleatorias = <?php echo json_encode($coresAleatorias); ?>;
        
        // Função para obter um gradiente para os gráficos de linha
        function getGradient(ctx, chartArea, corPrimaria) {
            const gradient = ctx.createLinearGradient(0, chartArea.bottom, 0, chartArea.top);
            gradient.addColorStop(0, corPrimaria.replace('0.8)', '0.1)'));
            gradient.addColorStop(1, corPrimaria);
            return gradient;
        }
        
        // Função para gerar cores aleatórias para os datasets
        function getRandomColors(count) {
            const colors = [];
            for (let i = 0; i < count; i++) {
                const index = Math.floor(Math.random() * coresAleatorias.length);
                colors.push(coresAleatorias[index]);
            }
            return colors;
        }
       
        // 1. Gráfico de Pagamentos Diários
        const ctxPagDiarios = document.getElementById('pagamentosDiarios').getContext('2d');
        const chartPagDiarios = new Chart(ctxPagDiarios, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($PagDia); ?>,
                datasets: [{
                    label: 'Valor (Kz)',
                    data: <?php echo json_encode($PagTotal); ?>,
                    borderColor: coresAleatorias[0],
                    backgroundColor: coresAleatorias[0].replace('0.8)', '0.2)'),
                    borderWidth: 3,
                    pointBackgroundColor: coresAleatorias[0],
                    pointRadius: 5,
                    pointHoverRadius: 7,
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: {
                            color: '#ffffff'
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        borderColor: '#ffffff',
                        borderWidth: 1,
                        displayColors: false,
                        callbacks: {
                            label: function(context) {
                                return formatCurrency(context.parsed.y) + ' Kz';
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#ffffff'
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#ffffff',
                            callback: function(value) {
                                return formatCurrency(value) + ' Kz';
                            }
                        }
                    }
                }
            }
        });
        
        // 2. Gráfico de Alunos por Classe
        const ctxClasses = document.getElementById('graficoClasses').getContext('2d');
        const classColors = getRandomColors(<?php echo count($classes); ?>);
        new Chart(ctxClasses, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($classes); ?>,
                datasets: [{
                    label: 'Número de Alunos',
                    data: <?php echo json_encode($quantidadeClasses); ?>,
                    backgroundColor: classColors,
                    borderColor: classColors.map(cor => cor.replace('0.8)', '1)')),
                    borderWidth: 1,
                    borderRadius: 5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        borderColor: '#ffffff',
                        borderWidth: 1
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#ffffff'
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#ffffff'
                        }
                    }
                }
            }
        });
        
        // 3. Gráfico de Alunos por Curso
        const ctxCursos = document.getElementById('graficoCursos').getContext('2d');
        const cursoColors = getRandomColors(<?php echo count($cursosAl); ?>);
        new Chart(ctxCursos, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($cursosAl); ?>,
                datasets: [{
                    label: 'Alunos',
                    data: <?php echo json_encode($quantidadeCursosA); ?>,
                    backgroundColor: cursoColors,
                    borderColor: cursoColors.map(cor => cor.replace('0.8)', '1)')),
                    borderWidth: 1,
                    borderRadius: 5
                }]
            },
            options: {
                indexAxis: 'y',  // Horizontal bar chart
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        borderColor: '#ffffff',
                        borderWidth: 1
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#ffffff'
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#ffffff'
                        }
                    }
                }
            }
        });
        
        // 4. Gráfico de Pagamentos Mensais
        const ctxPagamentos = document.getElementById('graficoPagamentos').getContext('2d');
        const mensalColors = getRandomColors(12);
        new Chart(ctxPagamentos, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($mesesAbrev); ?>,
                datasets: [{
                    label: 'Quantidade de Pagamentos',
                    data: <?php echo json_encode($pagamentosMensais); ?>,
                    backgroundColor: mensalColors,
                    borderColor: mensalColors.map(cor => cor.replace('0.8)', '1)')),
                    borderWidth: 1,
                    borderRadius: 5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        borderColor: '#ffffff',
                        borderWidth: 1
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#ffffff'
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#ffffff'
                        }
                    }
                }
            }
        });
        
        // 5. Gráfico de Pagamentos por Curso
        const ctxPagCursos = document.getElementById('graficoPagamentosCurso').getContext('2d');
        const pagCursoColors = getRandomColors(<?php echo count($cursos); ?>);
        new Chart(ctxPagCursos, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($cursos); ?>,
                datasets: [{
                    label: 'Total de Pagamentos',
                    data: <?php echo json_encode($pagamentos); ?>,
                    backgroundColor: pagCursoColors,
                    borderColor: '#ffffff',
                    borderWidth: 2,
                    hoverOffset: 15
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            color: '#ffffff',
                            font: {
                                size: 11
                            },
                            boxWidth: 15
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        borderColor: '#ffffff',
                        borderWidth: 1,
                        callbacks: {
                            label: function(context) {
                                return context.label + ': ' + formatCurrency(context.parsed) + ' Kz';
                            }
                        }
                    }
                }
            }
        });
        
        // 6. Gráfico de Crescimento por Ano
        const ctxCrescimento = document.getElementById('graficoCrescimento').getContext('2d');
        const crescimentoColor = getRandomColors(1)[0];
        const crescimentoBgColor = crescimentoColor.replace('0.8)', '0.2)');
        const chartCrescimento = new Chart(ctxCrescimento, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($anos); ?>,
                datasets: [{
                    label: 'Total de Alunos',
                    data: <?php echo json_encode($total_alunos); ?>,
                    borderColor: crescimentoColor,
                    backgroundColor: crescimentoBgColor,
                    borderWidth: 3,
                    pointBackgroundColor: crescimentoColor,
                    pointRadius: 6,
                    pointHoverRadius: 8,
                    tension: 0.3,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        borderColor: '#ffffff',
                        borderWidth: 1
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#ffffff'
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#ffffff'
                        }
                    }
                }
            }
        });
        
        // Função para formatar valores monetários
        function formatCurrency(value) {
            if (value >= 1000000) {
                return (value / 1000000).toFixed(1) + 'M';
            } else if (value >= 1000) {
                return (value / 1000).toFixed(1) + 'K';
            } else {
                return value.toFixed(0);
            }
        }
        
        // Adicionar animação aos gráficos ao entrar na área de visualização
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.2 });
        
        document.querySelectorAll('.card').forEach(card => {
            observer.observe(card);
        });


   	  
    </script>
</body>
</html>