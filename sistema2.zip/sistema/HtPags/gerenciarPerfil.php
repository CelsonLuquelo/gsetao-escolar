<?php 
session_start();
require '../Config/conexaoBD.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}


$id_usuario = $_SESSION['id_usuario'] ?? 4;

 // Buscar todos os usuários
 if(isset($_SESSION['id_usuario'])){
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id_usuario = :id_usuario");
    $stmt->execute([':id_usuario' => $id_usuario]);
    $usuariosS = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Perfil - Configurações</title>
    <link rel="stylesheet" href="../Config/notification.css">
    <link rel="icon" style="width: 100%; height:100%;" type="image/x-png" href="../arquivos/Logotipo/LOGO ICRA.jpg">
    <link rel="stylesheet" href="../Bibiliotecas/pace-1.2.4/themes/red/pace-theme-center-atom.css">
    <script src="../Bibiliotecas/pace-1.2.4/pace.min.js"></script>
    <link rel="stylesheet" href="../Bibiliotecas/Font-Awesome-6.x/css/all.min.css">
    <style>
       body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #1c1c3c, #3b3b92);
            color: white;
            text-align: center;
            min-height: 100vh;
        }
        .gerenciar{
            background-color: rgba(0, 0, 0,.2);
            padding: 10px 10px 10px 10px;
            text-align: center;
            border-radius: 10px;
            border-left: 4px solid rgb(0, 179, 255);
        }
        form{
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.05));
            backdrop-filter: blur(10px);
            border-radius: 15px;
            box-shadow: 0px 4px 10px rgba(255, 255, 255, 0.2);
            padding: 10px 40px 10px 20px;
            border-radius: 8px;
            width: 80%;
            margin: 0 auto;
            text-align: center;
            height: auto;
            display: block;
            position: relative;
            border-radius: 8px;

        }
        form h3{
            display: block;
            margin-bottom: 40px;
        }
        label {
            color: #007bff;
            display: block;
            margin-bottom: 5px;
        }

        form h3{
            text-align: center;
            font-weight: bold;
        }
        select{
            width: 100%;
            position: relative;
            margin-bottom: 5px;
            padding: 8px;
            color: #021f32;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input, 
        textarea {
            width:  95%;
            margin-bottom: 10px;
            padding: 10px;
            text-align: center;
            font-size: .9rem;
            color: #021f32;
            border: 1px solid #ccc;
            border-radius: 8px;
        }
        form button:hover{
            background-color: #007bff;
            color: #fff;
        }
        .btn-Plus{
            background-color: #3498db;
            color: #fff;
            display: block;
            padding: 10px;
            margin: 10px;
            width: 150px;
            margin: 20px auto;
            cursor: pointer;
            position: relative;
            filter: drop-shadow(0px 0px 4px #605DFF);
            border: 1px solid #083b5d;
            text-decoration: none;
            border-radius: 10px;
        }
        .grupForms{
            display: flex;
            justify-content: space-between;
        }
        .form-group{
            padding: 10px;
            display: block;
            width: 100%;
        }
        .SairAlter{
            position: absolute;
            display: block;
            left: 95%;
            top: 20px;
            transform: translate(-50%, -50%);
            font-size: 1.8rem;
            color: rgb(255, 0, 0);
            background: transparent;
            border: none;
            padding: 10px;
            border-radius: 50%;
            transition: .6s;
        }
       
        .SairAlter:hover{
            color: #ff5c5c;
            background: rgba(0, 0, 0,.1);
        }
        .fundo {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 100000;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }
        .fundo .ContExcluir{
            width: 50%;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            position: relative;
            border-radius: 8px;
            background-color: #ffffff;
            padding: 20px 10px 20px 10px;
        }
        .fundo p {
            text-align: center;
            display: block;
            color: black;
        }
        .fundo h3{
            text-align: center;
            color: #007bff;
        }
        .fundo .a{
            padding: 10px;
            border: 1px solid #ddd ;
            border-radius: 8px;
            display: block;
            margin: 0 auto;
            font-weight: 700;
            color: white;
            width: 100px;
            text-align: center;
            text-decoration: none;
            background: rgb(255, 42, 42);
        }
        .btn-deletar{
            background-color:rgb(219, 52, 52);
            color: #fff;
            display: block;
            padding: 10px;
            margin: 10px;
            width: 100px;
            top: 20px;
            left: 95%;
            transform: translate(-50%, -50%);
            cursor: pointer;
            position: relative;
            filter: drop-shadow(0px 0px 4px rgb(255, 115, 93));
            border: 1px solid rgb(93, 8, 29);
            text-decoration: none;
            border-radius: 10px;
            transition: .6s;
        }
        .btn-deletar:hover{
            background-color:#fafafa;
            color: rgb(219, 52, 52);
            font-weight: bold;
            display: block;
            padding: 10px;
            margin: 10px;
            width: 100px;
            left: 95%;
            transform: translate(-50%, -50%);
            cursor: pointer;
            position: relative;
            filter: drop-shadow(0px 0px 4px rgb(255, 115, 93));
            border: 4px solid rgb(219, 52, 52);
            border-radius: 10px;
        }
        
    </style>
</head>
<body>
<?php if (isset($_SESSION['notification'])): ?>
        <div class="notification <?php echo htmlspecialchars($_SESSION['estado']); ?>" id="notification"><?php echo htmlspecialchars($_SESSION['notification']); ?></div>
        <?php unset($_SESSION['notification']); ?>
<?php endif; ?>
<?php require 'Menu.php'; ?>
<div class="container">
<div class="ContHora"><i class="fas fa-clock"></i><span style="font-size: 20px;" id="recebHora"></span></div>
        
        <div class="dashboard-header">
            <img src="../arquivos/Logotipo/LOGO ICRA.jpg" alt="Logo ICRA">
            <h1 style="margin-top: -5px;">Gereciamento de perfil</h1>
        </div>
       
        <?php foreach ($usuariosS as $email): ?>
            <div id="fundoCadastro">
            <form action="../Config/actualizar_usuario.php" method="POST">
                <?php if($id_usuario): ?>
                    <input type="hidden" value="<?php echo htmlspecialchars($email['id_usuario']); ?>" name="id_usuario" id="id_usuario">
                <?php endif; ?>
                <button type="button" class="btn-deletar" onclick="window.location='../Config/excluirPerfil.php?id=<?php echo htmlspecialchars($email['id_usuario']) ?>'"> <i class="icon-warning" style=" font-size: 20px;"></i> Excluir</button>
                <div class="grupForms">
                <div class="form-group">
                <label for="nome">Nome:</label>
                <input type="text" id="nome" value="<?php echo htmlspecialchars($email['nome']); ?>" name="nome" required>
                </div>
                <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" value="<?php echo htmlspecialchars($email['email']); ?>" name="email" required>
                </div>
                </div>
                <div class="grupForms">
                <div class="form-group">
                <label for="senha">Senha:</label>
                <input type="password" id="senha" value="<?php echo htmlspecialchars($email['senha']); ?>" name="senha" required>
                </div>
                <div class="form-group">
                <label for="nivel_acesso">Nível de Acesso:</label>
                <select id="nivel_acesso" name="nivel_acesso" value="<?php echo htmlspecialchars($email['nivel_acesso']); ?>">
                    <option value="<?php echo htmlspecialchars($email['nivel_acesso']); ?>"><?php echo htmlspecialchars($email['nivel_acesso']); ?></option>
                </select>
                </div>
                </div>
                <button type="submit" class="btn-Plus">Actualizar</button>
                </form>
              </div>
            <?php endforeach; ?>
        </div>
		 <script src='../Scritps/Menu.js'></script>
        <script src="../Config/notification.js"></script>
</body>
</html>