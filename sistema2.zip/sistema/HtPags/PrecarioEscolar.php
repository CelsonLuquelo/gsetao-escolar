<?php
// Conexão com base de dados
include("../Config/conexaoBD.php");

// Obter valores básicos
$info = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM informacoes_basicas LIMIT 1"));

// Obter cursos e propinas por classe
$cursos = mysqli_query($conn, "SELECT c.curso, cl.nome as classe, cl.valor_percentual, c.valor_proprina 
                               FROM cursos c
                               JOIN classe cl ON 1=1 -- se cada curso tem o mesmo valor para todas as classes, senão mude isso
                               ORDER BY c.curso ASC, cl.nome ASC");
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Preçário Escolar</title>
  <link rel="stylesheet" href="style.css"> <!-- Estilo bonito -->
  <style>
    *{
      box-sizing: border-box;
    }
  body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #1c1c3c, #3b3b92);
    color: white;
    margin: 0;
    padding: 0;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

/* ✅ Container Principal */
.container {
    max-width: 95%;
    padding: 20px;
}

table {
    width: 98%;
    margin: 20px 0px;
    table-layout: auto;
    border-collapse: collapse;
    text-align: center;
}
h1{
    position: relative;
    margin: 30px auto;
    color: white;
    text-align: center;
}
thead {
    font-size: 18px;
    background-color: #e8f0fe;
    color: #0056b3;
}
tbody{
    font-size: 15px;
    color: white;
    background-color: rgba(255, 255, 255, 0.1);
}
td,th{
    max-width: 0px;
    padding: 5px 0px;
    border: 1px solid #ddd;
    text-align: center;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    word-wrap: break-word;
}
table th, table td {
    border: 1px solid #ddd;
    padding: 10px;
}
table th {
    background-color: #e8f0fe;
    color: #0056b3;
    font-weight: bold;
}
  </style>
</head>
<body>
<?php require "Menu.php"; ?>
<div class="container">
<div class="ContHora"><i class="fas fa-clock"></i><span style="font-size: 20px;" id="recebHora"></span></div>
        
        <div class="dashboard-header">
            <img src="../arquivos/Logotipo/LOGO ICRA.jpg" alt="Logo ICRA">
           <h1>📚 Gestão de Alunos</h1>
        </div>
        <h1 style="margin-top: -5px;">📘 Preçário Escolar</h1>
    </div>

  <table class="tabela">
    <tr><th colspan="2">💰 Taxas Fixas</th></tr>
    <tr><td>Valor de Matrícula</td><td><?= number_format($info['valor_Matricula'], 2) ?> AKZ</td></tr>
    <tr><td>Valor do Cartão Escolar</td><td><?= number_format($info['valor_cartao'], 2) ?> AKZ</td></tr>
    <tr><td>Valor do Uniforme</td><td><?= number_format($info['valor_uniforme'], 2) ?> AKZ</td></tr>
    <tr><td>Multa Percentual</td><td><?= $info['multa_percentual'] ?>%</td></tr>
  </table>

  <table class="tabela">
    <tr><th colspan="3">📚 Propinas por Curso e Classe</th></tr>
    <tr><th>Curso</th><th>Classe</th><th>Valor da Propina</th></tr>
    <?php while ($linha = mysqli_fetch_assoc($cursos)) { 

      $totalcurso = $linha['valor_proprina'] +($linha['valor_proprina']*$linha['valor_percentual'])/100; ?>
      <tr>
        <td><?= $linha['curso'] ?></td>
        <td><?= $linha['classe'] ?>ª</td>
        <td><?= number_format($totalcurso, 2) ?> AKZ</td>
      </tr>
    <?php } ?>
  </table>

  <table class="tabela">
    <tr><th colspan="2">📄 Outros Serviços</th></tr>
    <tr><td>Declaração</td><td><?= number_format($info['valor_declaracao'], 2) ?> AKZ</td></tr>
    <tr><td>Certificado</td><td><?= number_format($info['valor_certificado'], 2) ?> AKZ</td></tr>
    <tr><td>Estágio</td><td>Interno - <?= number_format($info['valor_estagio'], 2) ?> AKZ / Externo - 0,00 AKZ</td></tr>
  </table>
</div>
   <script src='../Scritps/Menu.js'></script>
</body>
</html>
