

<!-- Modal Adicionar -->
<div id="modalAdicionar" class="modal">
    <div class="modal-content">
        <span class="close" onclick="fecharModal('modalAdicionar')"><i class="fa-solid fa-xmark"></i></span>
        <h2><i class="fa-solid fa-user-plus"></i> Adicionar Aluno</h2>
        <form id="formAdicionar" method="POST" action="../Config/add_aluno.php">
            <input type="hidden" name="tipoEstagio" id="tipoEstagio">
            <input type="hidden" name="modoPagamento" id="modoPagamento">
            <input type="hidden" name="valorEstagio" id="valorEstagioR">
            <div class="form-div">
                <label><i class="fa-solid fa-image"></i> Foto (opcional):</label>
                <input type="file" name="foto" >
            </div>
            <div class="form-div">
            <label><i class="fa-solid fa-user"></i> Nª BI:</label>
            <input type="text" minlength="1" maxlength="14" name="BI" required>
            </div>
            <div class="form-div">
            <label><i class="fa-solid fa-user"></i> Nome:</label>
            <input type="text" name="nome" required>
            </div>
            <div class="form-div">
            <label><i class="fa-solid fa-calendar"></i> Data de nascimento:</label>
            <input type="date" max="2012-01-01" min="1928-01-01" name="data_nascimento" required>
            </div>
            <div class="form-div">
            <label><i class="fa-solid fa-house"></i> Morada:</label>
            <input type="text" name="morada" required>
            </div>
            <div class="form-div">
            <label><i class="fa-solid fa-phone"></i>Nº Encarregado:</label>
            <input type="number" name="numero_encarregado" max="999999999" min="900000000" required>
            </div>
            <div class="form-div">
                <label for="id_classe" class="form-label">Classe: </label>
                <select class="form-select" id="classe_select" name="id_classe" required>
                    <option value="" disabled selected>Selecione uma classe</option>
                    <?php foreach ($classes as $classe): ?>
                        <option value="<?= $classe['id_classe'] ?>"><?= $classe['nome'] ?>ª</option>
                    <?php endforeach; ?>
                </select>
            </div>
             <div class="form-div">
                <label for="id_curso" class="form-label">Curso: </label>
                <select class="form-select" id="curso_select" name="id_curso" required>
                    <option value="" disabled selected>Selecione um curso</option>
                    <?php foreach ($cursos as $curso): ?>
                        <option value="<?= $curso['id_curso'] ?>"><?= $curso['curso'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-div">
                 <label><i class="fa-solid fa-users"></i> Turma:</label>
                 <select name="id_turma" id="turma_select" required>

                </select>
            </div>
        
            <button type="button" onclick="AbrirOutroModal()" class="btn-salvar" style="background-color: green;"><i class="fa-solid fa-save"></i> Salvar</button>
        </form>
    </div>
</div>

 <!-- Modal De confirmação -->
        <div id="modalConfirmacao" class="modal">
            <div class="modal-content">
                <span class="close" onclick="fecharModal('modalConfirmacao')"><i class="fa-solid fa-xmark"></i></span>
                <h2><i class="fa-solid fa-trash"></i> Pagamento de Matricula</h2>
                <p>Valor de matricula: <strong><?= $infor['valor_Matricula'] ?></strong></p>
                <p>Valor do cartão escolar: <strong><?= $infor['valor_cartao'] ?></strong></p>
                <p>Valor do uniforme escolar: <strong><?= $infor['valor_uniforme'] ?></strong></p>
                <div class="form-div">
                    <label>Modo Pagamento:</label>
                     <select name="modoPagamento" id="modoPagamentoR" required>
                       <option value="Dinheiro">Dinheiro</option>
                       <option selected value="Multicaixa">Multicaixa</option>
                    </select>
                </div>
                    <button type="button" class="btn-salvar" onclick="VerificarEnviar()">Confirmar</button>
                    <button type="button" onclick="fecharModal('modalConfirmacao')" class="btn-salvar">Cancelar</button>
            </div>
    </div>


 <!-- Modal De Estagio -->
        <div id="modalEstagio" class="modal">
            <div class="modal-content">
                <span class="close" onclick="fecharModal('modalEstagio')"><i class="fa-solid fa-xmark"></i></span>
                <h2>Pagamento de Estágio</h2>
                <p>Valor de Estágio: <strong id="valorEstagio"><?= $infor['valor_estagio'] ?></strong> KZ</p>
                </p>
                <div class="form-div">
                    <label>Tipo de Estágio:</label>
                     <select name="tipoEstagio" id="tipoEstagioR" required>
                       <option selected value="Interno">Interno</option>
                       <option value="Externo">Externa</option>
                    </select>
                </div>
                    <button type="button" class="btn-salvar" onclick="EnviarDados()">finalizar</button>
                    <button type="button" onclick="fecharModal('modalEstagio')" class="btn-salvar">Cancelar</button>
            </div>
    </div>


<!-- Modal Editar -->

<!-- ✅ MODAL EDITAR ALUNO -->
<div id="modalEditar" class="modal">
    <div class="modal-content">
        <span class="close" onclick="fecharModal('modalEditar')"><i class="fa-solid fa-xmark"></i></span>
        <h2><i class="fas fa-edit"></i> Editar Aluno</h2>
        
        <form id="formEditar" action="../Config/editar_aluno.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id_aluno" id="edit_id">
            <div class="form-div">
                <label>Foto (opcional):</label>
                <input type="file" name="foto" id="edit_foto">
            </div>
            <div class="form-div">
            <label><i class="fa-solid fa-user"></i> Nª BI:</label>
            <input type="text" minlength="1" maxlength="14" name="BI" id="edit_BI" required>
            </div>
            <div class="form-div">
            <label>Nome:</label>
            <input type="text" name="nome" id="edit_nome" required>
            </div>
            <div class="form-div">
            <label><i class="fa-solid fa-calendar"></i> Data de nascimento:</label>
            <input type="date" max="2012-01-01" min="1928-01-01" id="edit_data_nasc" name="data_nascimento" required>
            </div>
            <div class="form-div">
            <label>Morada:</label>
            <input type="text" name="morada" id="edit_morada" required>
            </div>
            <div class="form-div">
            <label>Número do Encarregado:</label>
            <input type="number" min="900000000" max="999999999"  name="numero_encarregado" id="edit_numero_encarregado" required>
            </div>
            <div class="form-div">
                <label for="id_fornecedor" class="form-label">Classe: </label>
                <select class="form-select" id="edit_classe" name="id_classe" required>
                    <option value="" disabled selected>Selecione uma classe</option>
                    <?php foreach ($classes as $classe): ?>
                        <option value="<?= $classe['id_classe'] ?>"><?= $classe['nome'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
                <div class="form-div">
                <label for="id_curso" class="form-label">Curso: </label>
                <select class="form-select" name="id_curso" id="edit_curso" required>
                    <option value="" disabled selected>Selecione um curso</option>
                    <?php foreach ($cursos as $curso): ?>
                        <option  value="<?= $curso['id_curso'] ?>"><?= $curso['curso'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-div">
            <label>Turma:</label>
              <select name="id_turma" id="edit_turma" required>
                  
              </select>
            </div>
            <button type="submit" class="btn-salvar" style="background-color: yellow;">
                <i class="fas fa-save"></i> Salvar Alterações
            </button>
        </form>
    </div>
</div>


<!-- Modal Excluir -->
<div id="modalExcluir" class="modal">
    <div class="modal-content">
        <span class="close" onclick="fecharModal('modalExcluir')"><i class="fa-solid fa-xmark"></i></span>
        <h2><i class="fa-solid fa-trash"></i> Excluir Aluno</h2>
        <p>Tem certeza que deseja excluir este aluno?</p>
        <form id="formExcluir" method="POST" action="../Config/excluir_aluno.php">
            <input type="hidden" name="id" id="deleteId">
            <button type="submit" class="btn-salvar" style="background-color: red;"><i class="fa-solid fa-trash"></i> Sim, Excluir</button>
        </form>
    </div>
</div>

