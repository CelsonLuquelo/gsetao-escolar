<?php
session_start();
require '../Config/conexaoBD.php';


if (!isset($_GET['id_aluno'])) {
    die("Fatura não encontrada.");
}

$dados = json_decode($_GET['dados'], true);

$id_aluno = $_GET['id_aluno'] ?? 0;

$stmt = $pdo->prepare("SELECT * FROM informacoes_basicas");
$stmt->execute();
$infor = $stmt->fetch(PDO::FETCH_ASSOC);


$stmtAluno = $pdo->prepare("SELECT 
   a.*, cl.nome AS ClasseAluno, c.curso, t.nome AS turma
FROM alunos a
JOIN classe cl ON a.id_classe = cl.id_classe
JOIN cursos c ON a.id_curso = c.id_curso
JOIN turmas t ON a.id_turma = t.id_turma
WHERE a.id_aluno = $id_aluno
    ORDER BY a.id_aluno ASC");
$stmtAluno->execute();
$alunos = $stmtAluno->fetch(PDO::FETCH_ASSOC);

$totalgeral1 = 0; 
$totalgeral2 = 0; 

?>

<!DOCTYPE html>
<html>
<head>
    <title>Factura recibo</title>
    <style>
        body { font-family: 'Times New Roman', Times, serif; }
        .fatura { width: 95%; margin: auto; padding: 20px;}
       .fatura h5 { text-align: center; font-size: 16px;}
        .tabela { width: 100%; margin-top: 5px; border-collapse: collapse; border-top: 2px solid black;}
        .tabela th, .tabela td { border: 2px solid black; font-size: 13px; padding: 10px; text-align: center; }
        .tabela td{padding: 2px 10px;}
        .tabela th{padding: 2px 10px;}
        .btn-imprimir { display: block; position: fixed; border-radius: 9px; cursor: pointer;  box-shadow: 0px 0px 10px rgba(0, 0, 0, .5); padding: 10px; border: 1px solid #ddd;  width: 150px; left: 90%; top: 85%; transform: translate(-50%, -50%); text-align: center; }
        .ContInformacao{display: flex; width: 98%; padding: 2px 10px; border: 1px solid black}
        .ContInfAluno, .ContInfEscola{ display: block;  width: 100%; padding: auto;}
        .SubFim{text-align: center; margin-top: 30px;}
        .linha{display: block; border-top: 1px solid black; width: 25%; margin: 0 auto;}
        .ContInfAluno p, .ContInfEscola p{ margin: 0px; font-size: 16px;}
        .divisao{margin: 20px 0px; border: 1px dashed black;}
        @media print {
             body { margin: 0 !important; padding: 0 -200px !important;}
            .factura { padding: 10px !important; margin: a auto !important; position: relative; width: 96% !important; height: 100vh; box-shadow: none !important; border: none !important; }
            .btn-imprimir { display: none; }
            .ContInformacao{width: 97% !important;}
            table { width: 100%; font-size: 20px;  margin: 0 !important; }
        }
    </style>
</head>
<body>
<script>
    window.addEventListener("DOMContentLoaded",function(){
       let confirmacao = confirm("Deseja imprimir a factura?");
       if(confirmacao){
          window.print();
       }else{
          window.location ="detalhes_aluno.php?id=<?= $id_aluno ?>";
       }

    });
</script>
    <button class="btn-imprimir" onclick="window.print()">Imprimir</button>
    <div class="fatura">
        <img src="../arquivos/Logotipo/LOGO ICRA.jpg" style="margin: 0 auto; display: block;" width="70px" height="70px" class="logotipo" alt="">
        <h5>INSTITUTO DE CIÊNCIAS RELIGIOSAS DE ANGOLA</h5>
        <div class="ContInformacao">
            <div class="ContInfAluno">

                 <p>Nome: <strong><?= $alunos['nome'] ?></strong></p>
                 <p>Classe: <strong><?= $alunos['ClasseAluno'] ?>ª</strong> &nbsp;&nbsp;&nbsp;Turma: <strong><?= $alunos['turma'] ?></strong></p>
                 <p>Curso: <strong><?= $alunos['curso'] ?></strong></p>
                 <p>Matricula: <strong><?= $alunos['matricula'] ?></strong></p>
                 <p>Numero de Encarregado: <strong><?= $alunos['numero_encarregado'] ?></strong></p>
    
            </div>
            <div class="ContInfEscola">
                <p>Contactos: <strong><?= $infor['Contactos'] ?></strong></p>
                <p>NIF: <strong><?= $infor['NIF'] ?></strong></p>
                <p>IBAN: <strong><?= $infor['IBAN'] ?></strong></p>
                <p>Data de pagamento: <strong><?= date("d-m-Y")?></strong></p>
            </div>
        </div>
        <table class="tabela">
            <tr>
                <th>Emolumento</th>
                <th>Mês</th>
                <th>Modo Pagamento</th>
                <th>Valor (Kz)</th>
                <th>Multa (Kz)</th>
                <th>Desconto (Kz)</th>
                <th>Total (Kz)</th>
            </tr>
            <?php foreach ($dados as $dado) { ?>
            <tr>
                <td>Mensalidade</td>
                <td><?= $dado['mesPagar'] ?></td>
                <td>Multicaixa</td>
                <td><?= $dado['valorProprina'] ?></td>
                <td><?= $dado['multa'] ?></td>
                <td><?= $dado['desconto'] ?></td>
                <td><?= $dado['total'] ?></td>
            </tr>
            <?php $totalgeral1 += $dado['total']; } ?>
            <tr>
                <td colspan="7">Total geral (Kz): <strong><?= $totalgeral1 ?></strong></td>
            </tr>
        </table>
         <div class="SubFim">
            <span class="linha"></span>
            <span><strong><?= $_SESSION['nome'] ?></strong><br>(funcionário de serviço)</span>
         </div>
    </div>
    <div class="divisao"></div>
    <div class="fatura">
    <img src="../arquivos/Logotipo/LOGO ICRA.jpg" style="margin: 0 auto; display: block;" width="70px" height="70px" class="logotipo" alt="">
    <h5>INSTITUTO DE CIÊNCIAS RELIGIOSAS DE ANGOLA</h5>
        <div class="ContInformacao">
            <div class="ContInfAluno">
                 <p>Nome: <strong><?= $alunos['nome'] ?></strong></p>
                 <p>Classe: <strong><?= $alunos['ClasseAluno'] ?></strong> &nbsp;&nbsp;&nbsp;Turma: <strong><?= $alunos['turma'] ?></strong></p>
                 <p>Curso: <strong><?= $alunos['curso'] ?></strong></p>
                 <p>Matricula: <strong><?= $alunos['matricula'] ?></strong></p>
                 <p>Numero de Encarregado: <strong><?= $alunos['numero_encarregado'] ?></strong></p>
            </div>
            <div class="ContInfEscola">
                <p>Contactos: <strong><?= $infor['Contactos'] ?></strong></p>
                <p>NIF: <strong><?= $infor['NIF'] ?></strong></p>
                <p>IBAN: <strong><?= $infor['IBAN'] ?></strong></p>
                <p>Data de pagamento: <strong><?= date("d-m-Y")?></strong></p>
            </div>
        </div>
        <table class="tabela">
            <tr>
                <th>Emolumento</th>
                <th>Mês</th>
                <th>Modo Pagamento</th>
                <th>Valor (Kz)</th>
                <th>Multa (Kz)</th>
                <th>Desconto (Kz)</th>
                <th>Total (Kz)</th>
            </tr>
            <?php foreach ($dados as $dado) { ?>
            <tr>
                <td>Mensalidade</td>
                <td><?= $dado['mesPagar'] ?></td>
                <td>Multicaixa</td>
                <td><?= $dado['valorProprina'] ?></td>
                <td><?= $dado['multa'] ?></td>
                <td><?= $dado['desconto'] ?></td>
                <td><?= $dado['total'] ?></td>
            </tr>
            <?php $totalgeral2 += $dado['total']; } ?>
            <tr>
                <td colspan="7">Total geral (Kz): <strong><?= $totalgeral2 ?></strong></td>
            </tr>
        </table>
         <div class="SubFim">
            <span class="linha"></span>
            <span><strong><?= $_SESSION['nome'] ?></strong><br>(funcionário de serviço)</span>
         </div>
    </div>
</body>
</html>