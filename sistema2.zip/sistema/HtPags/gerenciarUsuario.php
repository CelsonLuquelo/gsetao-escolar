<?php
session_start();
require '../Config/conexaoBD.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}

// Verifica se o usuário está loga
if ($_SESSION['nivel_acesso'] === "secretario") {
    header("Location: inicio.php");
    $_SESSION['notification'] = "Não tens acesso a página de gereciamento de usuário.";
    $_SESSION['estado'] = "erro";
    exit();
}


// Processa formulário de cadastro ou edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';
    $senha = password_hash($_POST['senha'], PASSWORD_BCRYPT);
    $nivel_acesso = $_POST['nivel_acesso'] ?? 'secretario';



     // Verificar se o Usuario já existe no banco de dados
     $stmt_verifica = $pdo->prepare("SELECT id_usuario FROM usuarios WHERE email = :email");
     $stmt_verifica->bindParam(':email', $email);
     $stmt_verifica->execute();
     $usuario_existente = $stmt_verifica->fetch(PDO::FETCH_ASSOC);

if(!$usuario_existente){
try{
    if (isset($_POST['id_usuario']) && $_POST['id_usuario'] !== '') {
        // Atualizar usuário existente
        $id_usuario = $_POST['id_usuario'];
        $stmt = $pdo->prepare("UPDATE usuarios SET nome = :nome, email = :email, nivel_acesso = :nivel_acesso WHERE id_usuario = :id");
        $stmt->execute([':nome' => $nome, ':email' => $email, ':nivel_acesso' => $nivel_acesso, ':id' => $id_usuario]);
        $_SESSION['notification'] = "Usuário atualizado com sucesso!";
        $_SESSION['estado'] = "sucesso";
    } else {
        // Cadastrar novo usuário
        $stmt = $pdo->prepare("INSERT INTO usuarios (nome, email, senha, nivel_acesso) VALUES (:nome, :email, :senha, :nivel_acesso)");
        $stmt->execute([':nome' => $nome, ':email' => $email, ':senha' => $senha, ':nivel_acesso' => $nivel_acesso]);
        $_SESSION['notification'] = "Usuário cadastrado com sucesso!";
        $_SESSION['estado'] = "sucesso";
    }
    }catch(Exception $ex) {
        $_SESSION['notification'] = "Erro ao cadastrar usuario $nome";
        $_SESSION['estado'] = "erro";
    }
}else{
    $_SESSION['notification'] = "Usuario já existe.";
    $_SESSION['estado'] = "erro";
    header('location: ../Htpags/gerenciarUsuario.php');
}
    header("Location: gerenciarUsuario.php");
    exit();

}
// Excluir usuário
if (isset($_GET['delete'])) {
    $id_usuario = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM usuarios WHERE id_usuario = :id");
    $stmt->execute([':id' => $id_usuario]);
    $_SESSION['notification'] = "usuario excluído com sucesso!";
    $_SESSION['estado'] = "sucesso";
    header("Location: gerenciarUsuario.php");
    exit();
}

// Buscar todos os usuários
$idUsuario = $_SESSION['id_usuario'];
$stmt = $pdo->query("SELECT * FROM usuarios WHERE id_usuario > $idUsuario OR id_usuario < $idUsuario ORDER BY nome ASC");
    $funcionario = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios - Sistema Escolar</title>
    <link rel="icon" style="width: 100%; height:100%;" type="image/x-png" href="../arquivos/Logotipo/LOGO ICRA.jpg">
    <link rel="stylesheet" href="../Bibiliotecas/pace-1.2.4/themes/red/pace-theme-center-atom.css">
    <script src="../Bibiliotecas/pace-1.2.4/pace.min.js"></script>
    <link rel="stylesheet" href="../Styles/gerenciarUsuario.css">
    <link rel="stylesheet" href="../Bibiliotecas/icomoon/style.css">
</head>
<body>
        <!--Menu Interativo-->
        <?php require 'Menu.php'; ?>

       <div class="container">
<div class="ContHora"><i class="fas fa-clock"></i><span style="font-size: 20px;" id="recebHora"></span></div>
        
        <div class="dashboard-header">
            <img src="../arquivos/Logotipo/LOGO ICRA.jpg" alt="Logo ICRA">
            <h1 style="margin-top: -5px;">Gestão de Usuarios</h1>
        </div>
           
           <a class="btn-Plus" id="cadastrarUsuario"><i class="fa-solid fa-user-plus"></i> Adicionar Usuario</a>
        <table>
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Nível</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($funcionario as $email): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($email['nome']); ?></td>
                        <td><?php echo htmlspecialchars($email['email']); ?></td>
                        <td><?php echo htmlspecialchars($email['nivel_acesso']); ?></td>
                        <td>
                            <button class="button" onclick="editarUsuario(<?php echo htmlspecialchars(json_encode($email)); ?>)"><i class="fas fa-edit"></i></button>
                            <button class="aCan" onclick="ExcluirUsuario(<?php echo $email['id_usuario']; ?>)"><i class="fa-solid fa-trash"></i></button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div id="cadastrar">
           
        </div>
         <!--Exclusao de Fornecedor-->
         <div class="fundo" id="fundo">
                <div class="ContExcluir" id="ContExcluir">

                </div> 
        </div>
    </div>
	 <script src='../Scritps/Menu.js'></script>
    <script src="../Scritps/gerenciarUsuario.js"></script>
</body>
</html>