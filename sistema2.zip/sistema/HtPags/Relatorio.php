
<?php 
include '../Config/conexaoBD.php';

// Iniciar sessão e verificar login
session_start();
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit(); // Corrigido "saída()" para "exit()"
}

// Definir fuso horário para facilitar relatórios por data
date_default_timezone_set('Africa/Luanda');

// Funções auxiliares para formatação de valores
function formatMoney($value) {
    return number_format($value, 2, ',', '.') . ' Kz';
}

// CÁLCULOS FINANCEIROS
// ===========================================

// Multas acumuladas
$multa_acumulada = $pdo->query("SELECT COALESCE(SUM(multa), 0) FROM pagamentos")->fetchColumn();

// Faturamento recebido (real)
$faturamento_recebido = $pdo->query("SELECT COALESCE(SUM(total), 0) AS faturamento_recebido FROM pagamentos")->fetchColumn() ?? 1;

// Faturamento esperado
$faturamento_esperado = 0;
$sqlAlunos = "SELECT a.id_aluno, a.id_curso, a.id_classe FROM alunos a";
$stmtAlunos = $pdo->query($sqlAlunos);
$alunos = $stmtAlunos->fetchAll(PDO::FETCH_ASSOC);

foreach ($alunos as $aluno) {
    $id_curso = $aluno['id_curso'];
    $id_classe = $aluno['id_classe'];
    
    // Obter valor da propina
    $stmtPropina = $pdo->prepare("SELECT valor_proprina FROM cursos WHERE id_curso = ?");
    $stmtPropina->execute([$id_curso]);
    $valor_propina = $stmtPropina->fetchColumn() ?: 0;
    
    // Obter percentual da classe
    $stmtPercentual = $pdo->prepare("SELECT valor_percentual FROM classe WHERE id_classe = ?");
    $stmtPercentual->execute([$id_classe]);
    $valor_percentual = $stmtPercentual->fetchColumn() ?: 0;
    
    // Calcular propina com percentual
    $propina_mensal = $valor_propina + ($valor_propina * $valor_percentual) / 100;
    $faturamento_esperado += $propina_mensal;
}

// Quantidade total de alunos
$total_alunos = $pdo->query("SELECT COUNT(id_aluno) FROM alunos")->fetchColumn() ?? 0;

// Pagamento diário
$totalPagDiario = $pdo->query("SELECT COALESCE(SUM(total), 0) AS total FROM pagamentos WHERE DATE(data_created) = CURDATE()")->fetchColumn();

// Pagamento mensal (mês atual)
$diaActual = date('d');
$mesAtual = date('m');
$anoAtual = date('Y');
$totalPagMensal = $pdo->query("SELECT COALESCE(SUM(total), 0) AS total FROM pagamentos WHERE MONTH(data_created) = $mesAtual AND YEAR(data_created) = $anoAtual")->fetchColumn();

// Taxa de inadimplência
$taxa_inadimplencia = 0;
if ($faturamento_esperado > 0) {
    $taxa_inadimplencia = 100 - (($faturamento_recebido / ($faturamento_esperado * 12)) * 100);
    $taxa_inadimplencia = max(0, min(100, $taxa_inadimplencia)); // Garantir que fique entre 0% e 100%
}

// CONSULTAS PARA GRÁFICOS E TABELAS
// ===========================================

// Quantidade de alunos por curso
$cursos_query = $pdo->query("
    SELECT c.id_curso, c.curso AS cursoAL, COUNT(a.id_aluno) AS total 
    FROM cursos c 
    LEFT JOIN alunos a ON c.id_curso = a.id_curso 
    GROUP BY c.id_curso, c.curso
    ORDER BY total DESC
");
$cursos_data = $cursos_query->fetchAll(PDO::FETCH_ASSOC);

// Crescimento da escola ao longo dos anos
$crescimento_query = $pdo->query("
    SELECT YEAR(created_at) AS ano_letivo, COUNT(id_aluno) AS total_alunos 
    FROM alunos 
    GROUP BY YEAR(created_at) 
    ORDER BY ano_letivo ASC
");
$crescimento_data = $crescimento_query->fetchAll(PDO::FETCH_ASSOC);

// Relatório detalhado por curso - CORRIGIDO
$cursos_detalhes_query = $pdo->query("
    SELECT 
        c.id_curso,
        c.curso,
        COUNT(DISTINCT a.id_aluno) AS total_alunos,
        (SELECT COALESCE(SUM(p.total), 0) 
         FROM pagamentos p 
         JOIN alunos a2 ON a2.id_aluno = p.id_aluno 
         WHERE a2.id_curso = c.id_curso) AS faturamento_atual,
        (SELECT SUM((c.valor_proprina + (c.valor_proprina * cl.valor_percentual / 100)) * 12)
         FROM alunos a3
         JOIN classe cl ON cl.id_classe = a3.id_classe
         WHERE a3.id_curso = c.id_curso) AS faturamento_esperado_anual,
        (SELECT COALESCE(SUM(p.multa), 0) 
         FROM pagamentos p 
         JOIN alunos a4 ON a4.id_aluno = p.id_aluno 
         WHERE a4.id_curso = c.id_curso) AS multas_curso
    FROM cursos c
    LEFT JOIN alunos a ON c.id_curso = a.id_curso
    LEFT JOIN classe cl ON cl.id_classe = a.id_classe
    GROUP BY c.id_curso, c.curso
    ORDER BY total_alunos DESC
");
$cursos_detalhes = $cursos_detalhes_query->fetchAll(PDO::FETCH_ASSOC);

// Pagamentos por mês (últimos 12 meses)
$pagamentos_mensais_query = $pdo->query("
    SELECT 
        DATE_FORMAT(data_created, '%Y-%m') AS mes,
        SUM(total) AS valor_total
    FROM pagamentos
    WHERE data_created >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
    GROUP BY DATE_FORMAT(data_created, '%Y-%m')
    ORDER BY mes ASC
");
$pagamentos_mensais = $pagamentos_mensais_query->fetchAll(PDO::FETCH_ASSOC);

// Outros pagamentos
$PagamentoEstagio = $pdo->query("SELECT SUM(e.total_pago) As Valor_Estagio FROM alunos a JOIN outros_pagamentos o ON a.id_aluno = o.id_aluno JOIN estagio e ON o.id_estagio = e.id_estagio")->fetchColumn() ?? 0;

$PagamentoDeclaracao = $pdo->query("SELECT SUM(d.total_pago) As Valor_declaracao FROM alunos a JOIN outros_pagamentos o ON a.id_aluno = o.id_aluno JOIN declaracao d ON o.id_declaracao = d.id_declaracao")->fetchColumn() ?? 0;

$PagamentoCertificado = $pdo->query("SELECT SUM(c.total_pago) As Valor_certificado FROM alunos a JOIN outros_pagamentos o ON a.id_aluno = o.id_aluno JOIN certificado c ON o.id_certificado = c.id_certificado")->fetchColumn() ?? 0;

$PagamentoTTT = $pdo->query("SELECT (valor_Matricula+valor_uniforme+valor_cartao) As total_pago FROM informacoes_basicas WHERE id = 1")->fetchColumn();

$PagamentoTTT2 = $PagamentoTTT * $total_alunos;

$PagamentoTL1 = $pdo->query("SELECT SUM(c.total_pago) As Valor FROM alunos a 
JOIN outros_pagamentos o ON a.id_aluno = o.id_aluno 
JOIN certificado c ON o.id_certificado = c.id_certificado
WHERE DATE(c.created_at) = CURDATE()")->fetchColumn() ?? 0;

$PagamentoTL2 = $pdo->query("SELECT SUM(e.total_pago) As Valor FROM alunos a 
JOIN outros_pagamentos o ON a.id_aluno = o.id_aluno 
JOIN estagio e ON o.id_estagio = e.id_estagio
WHERE DATE(e.created_at) = CURDATE()")->fetchColumn() ?? 0;

$PagamentoTL3 = $pdo->query("SELECT SUM(d.total_pago) As Valor FROM alunos a 
JOIN outros_pagamentos o ON a.id_aluno = o.id_aluno 
JOIN declaracao d ON o.id_declaracao = d.id_declaracao
WHERE DATE(d.created_at) = CURDATE()")->fetchColumn() ?? 0;

$PagamentoTB1 = $pdo->query("SELECT SUM(e.total_pago) As Valor FROM alunos a 
JOIN outros_pagamentos o ON a.id_aluno = o.id_aluno 
JOIN estagio e ON o.id_estagio = e.id_estagio
WHERE MONTH(e.created_at) = $mesAtual AND YEAR(e.created_at) = $anoAtual")->fetchColumn() ?? 0;
$PagamentoTB2 = $pdo->query("SELECT SUM(c.total_pago) As Valor FROM alunos a 
JOIN outros_pagamentos o ON a.id_aluno = o.id_aluno 
JOIN certificado c ON o.id_certificado = c.id_certificado
WHERE MONTH(c.created_at) = $mesAtual AND YEAR(c.created_at) = $anoAtual")->fetchColumn() ?? 0;
$PagamentoTB3 = $pdo->query("SELECT SUM(d.total_pago) As Valor FROM alunos a 
JOIN outros_pagamentos o ON a.id_aluno = o.id_aluno 
JOIN declaracao d ON o.id_declaracao = d.id_declaracao
WHERE MONTH(d.created_at) = $mesAtual AND YEAR(d.created_at) = $anoAtual")->fetchColumn() ?? 0;

$PagamentoTB = $PagamentoTB1 + $PagamentoTB2 + $PagamentoTB3;

$totalPagMensal = $totalPagMensal+$PagamentoTB;
$PagamentoTL = $PagamentoTL1 + $PagamentoTL2 + $PagamentoTL3;


$totalPagDiario = $totalPagDiario + $PagamentoTL;
$faturamento_recebido1 = $faturamento_recebido + $PagamentoEstagio + $PagamentoDeclaracao + $PagamentoCertificado + $PagamentoTTT2;
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório Financeiro Escolar</title>
    <link rel="stylesheet" href="../Styles/Relatorio.css">
    <link rel="icon" type="image/x-png" href="../arquivos/Logotipo/LOGO ICRA.jpg">
    <link rel="stylesheet" href="../Bibiliotecas/pace-1.2.4/themes/red/pace-theme-center-atom.css">
    <script src="../Bibiliotecas/pace-1.2.4/pace.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="../Bibiliotecas/Font-Awesome-6.x/css/all.min.css">
    <style>
        :root {
            --primary-color: #005ec2;
            --secondary-color: #333;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --white: #fff;
            --light-gray: #f8f9fa;
            --border-color: #ddd;
        }
   
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            color: #333;
			
        }

        
        .ContHora {
            text-align: right;
            margin-bottom: 10px;
            font-size: 18px;
            color: var(--secondary-color);
        }
        
        .ContLogo {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .ContLogo h1 {
            color: var(--primary-color);
            margin-top: 15px;
            font-size: 28px;
        }
        
        .card-container {
            display: flex;
            flex-wrap: wrap;
			width: 95%;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .card {
            flex: 1 1 200px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border-bottom: 5px solid var(--primary-color);
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
        }
        
        .card h3 {
            margin-top: 0;
            color: var(--secondary-color);
            font-size: 18px;
        }
        
        .card p {
            font-size: 22px;
            font-weight: bold;
            margin: 10px 0 0;
            color: var(--primary-color);
        }
        
        .card.warning p {
            color: var(--warning-color);
        }
        
        .card.success p {
            color: var(--success-color);
        }
        
        .card.danger p {
            color: var(--danger-color);
        }
        
        .tabela {
            width: 98%;
            border-collapse: collapse;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        
        .tabela th, .tabela td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        
        .tabela th {
           background-color: blue;
            color: var(--white);
            font-weight: 600;
        }
        
        .tabela td{
            background-color: var(--light-gray);
        }
        
        .tabela tr:hover {
            background-color: rgba(0, 94, 194, 0.05);
        }
        
        .btn-lista {
            background: linear-gradient(135deg, var(--primary-color), #0046a3);
            color: white;
            padding: 12px 24px;
            display: inline-block;
            border-radius: 8px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            transition: 0.3s;
            font-weight: bold;
            margin: 15px 0 30px;
            box-shadow: 0 4px 10px rgba(0, 94, 194, 0.3);
            text-decoration: none;
        }
        
        .btn-lista:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(0, 94, 194, 0.4);
        }
        
        .btn-lista i {
            margin-right: 8px;
        }
        
        .ContCards {
            display: flex;
            flex-wrap: wrap;
            gap: 25px;
			width: 98%;
            margin-bottom: 50px;
        }
        
        .card1 {
            flex: 1 1 400px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            padding: 25px;
            text-align: center;
            transition: 0.3s;
            border-bottom: 5px solid var(--primary-color);
        }
        
        .card1 h3 {
            margin-top: 0;
            color: var(--secondary-color);
            margin-bottom: 20px;
        }
        
        .card1 canvas {
            width: 100% !important;
            height: 300px !important;
        }
        
        .filtro-periodo {
            display: flex;
            margin-bottom: 20px;
            gap: 10px;
        }
        
        .filtro-periodo select, .filtro-periodo button {
            padding: 8px 12px;
            border-radius: 4px;
            border: 1px solid var(--border-color);
        }
        
        .filtro-periodo button {
            background-color: var(--primary-color);
            color: white;
            border: none;
            cursor: pointer;
        }
        
        .resumo-indicadores {
            background-color: white;
            border-radius: 12px;
            padding: 20px;
			width: 95%;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        
        .resumo-indicadores h3 {
            margin-top: 0;
            color: var(--primary-color);
            border-bottom: 2px solid var(--primary-color);
            padding-bottom: 10px;
            margin-bottom: 15px;
        }
        
        .progresso-container {
            margin-bottom: 20px;
        }
        
        .progresso-titulo {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
        }
        
        .barra-progresso {
            height: 12px;
            background-color: #e9ecef;
            border-radius: 6px;
            overflow: hidden;
        }
        
        .barra-valor {
            height: 100%;
            background: linear-gradient(90deg, var(--primary-color), #0046a3);
            border-radius: 6px;
            transition: width 1s ease;
        }
        
        @media (max-width: 768px) {
            .card-container {
                flex-direction: column;
            }
            
            .card {
                margin-bottom: 15px;
            }
            
            .tabela {
                font-size: 14px;
            }
            
            .tabela th, .tabela td {
                padding: 8px;
            }
            
            .ContCards {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <?php require "Menu.php"; ?>
    
    <div class="container">
<div class="ContHora"><i class="fas fa-clock"></i><span style="font-size: 20px;" id="recebHora"></span></div>
        
        <div class="dashboard-header">
            <img src="../arquivos/Logotipo/LOGO ICRA.jpg" alt="Logo ICRA">
            <h1>Relatórios Financeiros da Escola</h1>
        </div>
           
        
        <!-- Filtro de período para relatórios -->
        <div class="filtro-periodo">
            <select id="periodoRelatorio">
                <option value="hoje">Hoje</option>
                <option value="semana">Esta semana</option>
                <option value="mes" selected>Este mês</option>
                <option value="ano">Este ano</option>
                <option value="todos">Todos</option>
            </select>
            <button onclick="filtrarPeriodo()"><i class="fas fa-filter"></i> Filtrar</button>
        </div>
        
        <!-- Cards de indicadores principais -->
        <div class="card-container">
            <?php if($_SESSION['nivel_acesso'] === "Administrador"): ?>
                <div class="card success">
                    <h3><i class="fas fa-money-bill-wave"></i> Faturamento Total</h3>
                    <p><?php echo formatMoney($faturamento_recebido1); ?></p>
                </div>
				 <div class="card success">
                    <h3><i class="fas fa-money-bill-wave"></i>Outros faturamento</h3>
                    <p><?php echo formatMoney($PagamentoCertificado+$PagamentoDeclaracao+$PagamentoEstagio+$PagamentoTTT2); ?></p>
                </div>
                <div class="card">
                    <h3><i class="fas fa-calendar-check"></i> Faturamento Esperado (Anual)</h3>
                    <p><?php echo formatMoney($faturamento_esperado * 12); ?></p>
                </div>
            <?php endif; ?>
            <div class="card warning">
                <h3><i class="fas fa-exclamation-triangle"></i> Multas Acumuladas</h3>
                <p><?php echo formatMoney($multa_acumulada); ?></p>
            </div>
            <div class="card">
                <h3><i class="fas fa-calendar-day"></i> Faturamento de Hoje</h3>
                <p><?php echo formatMoney($totalPagDiario); ?></p>
            </div>
            <div class="card">
                <h3><i class="fas fa-calendar-alt"></i> Faturamento Mensal</h3>
                <p><?php echo formatMoney($totalPagMensal); ?></p>
            </div>
            <div class="card danger">
                <h3><i class="fas fa-percentage"></i> Taxa de Inadimplência</h3>
                <p><?php echo number_format($taxa_inadimplencia, 1, ',', '.'); ?>%</p>
            </div>
        </div>
        
        <!-- Resumo de indicadores -->
        <div class="resumo-indicadores">
            <h3><i class="fas fa-chart-line"></i> Indicadores Financeiros</h3>
            
            <!-- Progresso do faturamento -->
            <div class="progresso-container">
                <div class="progresso-titulo">
                    <span>Progresso do Faturamento Anual</span>
                    <span><?php echo number_format(min(100, ($faturamento_recebido / ($faturamento_esperado*12)) * 100), 1, ',', '.') ?: 1; ?>%</span>
                </div>
                <div class="barra-progresso">
                    <div class="barra-valor" style="width: <?php echo min(100, ($faturamento_recebido / ($faturamento_esperado * 12)) * 100) ?: 1; ?>%"></div>
                </div>
            </div>
            
            <!-- Total de alunos -->
            <div class="progresso-container">
                <div class="progresso-titulo">
                    <span>Total de Alunos</span>
                    <span><?php echo $total_alunos; ?> alunos</span>
                </div>
                <div class="progresso-titulo">
                    <span>Média de Valor por Aluno</span>
                    <span><?php echo formatMoney($total_alunos > 0 ? $faturamento_recebido / $total_alunos : 0); ?></span>
                </div>
            </div>
        </div>
        
        <!-- Tabela de Relatório por Curso -->
        <h3><i class="fas fa-table"></i> Relatório Detalhado por Curso</h3>
        <table class="tabela">
            <tr>
                <th>Curso</th>
                <th>Alunos Matriculados</th>
                <th>Faturamento Atual</th>
                <th>Faturamento Esperado (Anual)</th>
                <th>Multas</th>
                <th>Percentual</th>
            </tr>
            <?php
            $cursos = [];
            $faturamentoAtual = [];
            $faturamentoEsperado = [];
            $total_alunos_cursos = [];
            
            foreach ($cursos_detalhes as $curso) {
                $cursos[] = $curso['curso'];
                $faturamentoAtual[] = $curso['faturamento_atual'] ?: 0;
                $faturamentoEsperado[] = $curso['faturamento_esperado_anual'] ?: 0;
                $total_alunos_cursos[] = $curso['total_alunos'];
                
                // Calcular percentual de realização
                $percentual = $curso['faturamento_esperado_anual'] > 0 ? 
                    ($curso['faturamento_atual'] / $curso['faturamento_esperado_anual']) * 100 : 0;
                
                // Definir classe de cor com base no percentual
                $percentualClass = '';
                if ($percentual < 50) {
                    $percentualClass = 'color: var(--danger-color);';
                } elseif ($percentual < 80) {
                    $percentualClass = 'color: var(--warning-color);';
                } else {
                    $percentualClass = 'color: var(--success-color);';
                }
                
                echo "<tr>
                    <td>{$curso['curso']}</td>
                    <td>{$curso['total_alunos']}</td>
                    <td>" . formatMoney($curso['faturamento_atual']) . "</td>
                    <td>" . formatMoney($curso['faturamento_esperado_anual']) . "</td>
                    <td>" . formatMoney($curso['multas_curso']) . "</td>
                    <td style='font-weight: bold; $percentualClass'>" . number_format(min(100 ,$percentual), 1, ',', '.') . "%</td>
                </tr>";
            }
            ?>
        </table>
        
        <button class="btn-lista" onclick="window.location='PrecarioEscolar.php'">
            <i class="fas fa-list"></i> Preçario Escolar
        </button>
        
        <!-- Gráficos -->
        <div class="ContCards">
            <div class="card1">
                <h3><i class="fas fa-user-graduate"></i> Quantidade de Alunos por Curso</h3>
                <canvas id="graficoCursos"></canvas>
            </div>
            <div class="card1">
                <h3><i class="fas fa-chart-line"></i> Crescimento da Escola</h3>
                <canvas id="graficoCrescimento"></canvas>
            </div>
        </div>
        
        <div class="ContCards">
            <div class="card1">
                <h3><i class="fas fa-money-bill-trend-up"></i> Comparativo: Faturamento Atual vs Esperado</h3>
                <canvas id="graficoComparativo"></canvas>
            </div>
            <div class="card1">
                <h3><i class="fas fa-calendar-check"></i> Evolução de Pagamentos (Últimos 12 meses)</h3>
                <canvas id="graficoEvolucao"></canvas>
            </div>
        </div>
    </div>
    
    <script>
        
        // Função para filtrar relatórios por período
        function filtrarPeriodo() {
            const periodo = document.getElementById('periodoRelatorio').value;
            // Aqui você pode implementar uma chamada AJAX para atualizar os dados
            alert('Filtrando por período: ' + periodo);
            // Recarregar a página com o parâmetro de filtro
            window.location.href = `?periodo=${periodo}`;
        }
        
        // Configurações comuns para os gráficos
        const configGraficos = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                }
            }
        };
        
        // Cores para gráficos
        const coresGraficos = [
            'rgba(54, 162, 235, 0.7)',
            'rgba(255, 99, 132, 0.7)',
            'rgba(255, 206, 86, 0.7)',
            'rgba(75, 192, 192, 0.7)',
            'rgba(153, 102, 255, 0.7)',
            'rgba(255, 159, 64, 0.7)',
            'rgba(201, 203, 207, 0.7)',
            'rgba(0, 162, 150, 0.7)',
            'rgba(255, 0, 150, 0.7)',
            'rgba(100, 120, 200, 0.7)'
        ];
        
        // 1. Gráfico de alunos por curso
        const ctxCursos = document.getElementById('graficoCursos').getContext('2d');
        const graficoCursos = new Chart(ctxCursos, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode(array_column($cursos_data, 'cursoAL')); ?>,
                datasets: [{
                    label: 'Alunos por Curso',
                    data: <?php echo json_encode(array_column($cursos_data, 'total')); ?>,
                    backgroundColor: coresGraficos,
                    borderWidth: 1
                }]
            },
            options: {
                ...configGraficos,
                plugins: {
                    ...configGraficos.plugins,
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                const value = context.raw;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentual = Math.round((value / total) * 100);
                                return `${label} ${value} alunos (${percentual}%)`;
                            }
                        }
                    }
                }
            }
        });
        
        // 2. Gráfico de crescimento da escola
        const ctxCrescimento = document.getElementById('graficoCrescimento').getContext('2d');
        const graficoCrescimento = new Chart(ctxCrescimento, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column($crescimento_data, 'ano_letivo')); ?>,
                datasets: [{
                    label: 'Alunos por Ano',
                    data: <?php echo json_encode(array_column($crescimento_data, 'total_alunos')); ?>,
                    fill: false,
                    borderColor: 'rgba(54, 162, 235, 1)',
                    backgroundColor: 'rgba(54, 162, 235, 0.5)',
                    tension: 0.3,
                    pointBackgroundColor: 'rgba(54, 162, 235, 1)',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: 'rgba(54, 162, 235, 1)',
                    pointRadius: 5,
                    pointHoverRadius: 7
                }]
            },
            options: {
                ...configGraficos,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Número de Alunos'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Ano Letivo'
                        }
                    }
                }
            }
        });
        
        // 3. Gráfico comparativo: Faturamento Atual vs Esperado
        const ctxComparativo = document.getElementById('graficoComparativo').getContext('2d');
        const graficoComparativo = new Chart(ctxComparativo, {
            type: 'bar',
            data: {
              labels: <?php echo json_encode($cursos); ?>,
                datasets: [
                    {
                        label: 'Faturamento Atual',
                        data: <?php echo json_encode($faturamentoAtual); ?>,
                        backgroundColor: 'rgba(54, 162, 235, 0.7)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Faturamento Esperado (Anual)',
                        data: <?php echo json_encode($faturamentoEsperado); ?>,
                        backgroundColor: 'rgba(255, 99, 132, 0.7)',
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                ...configGraficos,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Valor (Kz)'
                        },
                        ticks: {
                            callback: function(value) {
                                return value.toLocaleString('pt-AO') + ' Kz';
                            }
                        }
                    }
                }
            }
        });
        
        // 4. Gráfico de evolução de pagamentos mensais
        const ctxEvolucao = document.getElementById('graficoEvolucao').getContext('2d');
        const mesesData = <?php echo json_encode(array_column($pagamentos_mensais, 'mes')); ?>;
        const valoresData = <?php echo json_encode(array_column($pagamentos_mensais, 'valor_total')); ?>;
        
        // Formatar meses para exibição mais amigável
        const mesesFormatados = mesesData.map(mes => {
            const [ano, mesNum] = mes.split('-');
            const data = new Date(ano, mesNum - 1);
            return data.toLocaleDateString('pt-AO', { month: 'short', year: 'numeric' });
        });
        
        const graficoEvolucao = new Chart(ctxEvolucao, {
            type: 'line',
            data: {
                labels: mesesFormatados,
                datasets: [{
                    label: 'Pagamentos Mensais',
                    data: valoresData,
                    fill: true,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    tension: 0.2,
                    pointBackgroundColor: 'rgba(75, 192, 192, 1)',
                    pointBorderColor: '#fff',
                    pointRadius: 4
                }]
            },
            options: {
                ...configGraficos,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Valor (Kz)'
                        },
                        ticks: {
                            callback: function(value) {
                                return value.toLocaleString('pt-AO') + ' Kz';
                            }
                        }
                    }
                }
            }
        });
        
        // Relógio em tempo real
        function atualizarHora() {
            const agora = new Date();
            const hora = agora.getHours().toString().padStart(2, '0');
            const minuto = agora.getMinutes().toString().padStart(2, '0');
            const segundo = agora.getSeconds().toString().padStart(2, '0');
            const dia = agora.getDate().toString().padStart(2, '0');
            const mes = (agora.getMonth() + 1).toString().padStart(2, '0');
            const ano = agora.getFullYear();
            
            document.getElementById('recebHora').innerText = `${dia}/${mes}/${ano} - ${hora}:${minuto}:${segundo}`;
        }
        
        // Atualizar hora a cada segundo
        setInterval(atualizarHora, 1000);
        atualizarHora(); // Iniciar relógio imediatamente
    </script>
	 <script src='../Scritps/Menu.js'></script>
</body>
</html>