<?php
session_start();
include '../Config/conexaoBD.php';

// Verifica se o usuário está loga
if ($_SESSION['nivel_acesso'] === "secretario") {
    header("Location: inicio.php");
    $_SESSION['notification'] = "Não tens acesso a página de actualizações.";
    $_SESSION['estado'] = "erro";
    exit();
}

// Busca os dados atuais do sistema
$sql = "SELECT * FROM informacoes_basicas WHERE id = 1";
$result = $conn->query($sql);
$info = $result->fetch_assoc();

// Busca os ano lectivo
$sql1 = "SELECT * FROM anolectivo WHERE id = 1";
$result1 = $conn->query($sql1);
$info1 = $result1->fetch_assoc();

  // Busca as classes
  $sql_classes = "SELECT * FROM classe";
  $result_classes = $pdo->prepare($sql_classes);
  $result_classes->execute();
  $classese = $result_classes->fetchAll(PDO::FETCH_ASSOC);


  // Busca as curso
  $sql_cursos = "SELECT * FROM cursos";
  $result_cursos = $pdo->prepare($sql_cursos);
  $result_cursos->execute();
  $cursos = $result_cursos->fetchAll(PDO::FETCH_ASSOC);

  $anoAtual = date("Y");

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuração do Sistema</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #1c1c3c, #3b3b92);
            color: white !important;
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        h3, h5{
            text-align: center;
        }
        .form-actualizar{
            background: rgba(255, 255, 255, 0.2) !important;
            display: block ;
            margin-left: 50px;

        }
        .btn-actualizar{
            border: none;
            text-align: center;
            margin-top: 10px;
            background: green;
            border-radius: 10px;
            color: rgb(255, 255, 255);
            width: 200px;
            display: flex ;
            margin: 0 auto;
            padding: 10px;
        }
    </style>
        <link rel="icon" style="width: 100%; height:100%;" type="image/x-png" href="../arquivos/Logotipo/LOGO ICRA.jpg">
    <link rel="stylesheet" href="../Bibiliotecas/pace-1.2.4/themes/red/pace-theme-center-atom.css">
    <script src="../Bibiliotecas/pace-1.2.4/pace.min.js"></script>
    <link rel="stylesheet" href="../Bibiliotecas/Bootstrap/bootstrap.min.css">
</head>
<body>
    <?php require 'Menu.php'; ?>
    <div class="container mt-5">
    <div class="ContHora"><i class="fas fa-clock"></i><span style="font-size: 20px;" id="recebHora"></span></div>
        
        <div class="dashboard-header">
            <img src="../arquivos/Logotipo/LOGO ICRA.jpg" alt="Logo ICRA">
              <h1 style="margin-top: -5px;">Configurações do Sistema</h1>
        </div>
        
        <form action="../Config/actualizar_informacoes.php" method="POST" class="form-actualizar card p-4 shadow">
        <div style="display: flex; gap: 10px; ">
        <div style="display: flex; width: 100%; flex-wrap: wrap; gap: 10px;">
        <h5>Valores Percentuais das Classes(%)</h5>
            <?php foreach($classese as $classe){ ?>
                <div class="mb-3" style="display: block; margin-top: 10px;">
                    <label class="form-label"><?= $classe['nome'] ?>ª Classe:</label>
                    <input type="number" value='<?php echo htmlspecialchars($classe["valor_percentual"]); ?>' step="0.01" name="percentual[<?= $classe['id_classe'] ?>]" class="form-control" required>
                </div>

            <?php } ?>
            </div>
            <div style="display: flex; width: 100%; flex-wrap: wrap; gap: 10px;">
            <h5>Valores de Proprina de cada curso</h5>
            <?php foreach($cursos as $curso){ ?>
                <div class="mb-3" style="display: block;">
                    <label class="form-label"><?= $curso['curso'] ?>:</label>
                    <input type="number" value='<?php echo htmlspecialchars($curso["valor_proprina"]); ?>' step="0.01" name="valor_proprina[<?= $curso['id_curso'] ?>]" class="form-control" required>
                </div>
            <?php } ?>
            </div>
            </div>
            <h3>Informações Básicas</h3>
            <div class="mb-3">
                <label class="form-label">NIF:</label>
                <input type="text" name="nif" class="form-control" value="<?= $info['NIF'] ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">IBAN:</label>
                <input type="text" name="iban" class="form-control" value="<?= $info['IBAN'] ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Ano Letivo:</label>
                <div style="display: flex;">
                   <input type="number" min="<?= intval($anoAtual-1) ?>" id="anoLectivo" name="ano_lectivo" class="form-control" value="<?= $info1['ano'] ?>" required>
                   <span style="display: block; margin: 0 5px 0px -20px; position: relative; top: -7px; border-top: 4px solid white; width: 100px; transform: rotate(110deg);"></span>
                   <input type="number" min="<?= $anoAtual ?>" id="anoLectivoSeguinte" style="background-color: gainsboro;" name="ano_lectivo" class="form-control" disabled>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Telefone:</label>
                <input type="text" name="telefone" class="form-control" value="<?= $info['Contactos'] ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">E-mail:</label>
                <input type="email" name="email" class="form-control" value="<?= $info['email'] ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Multa Percentual:</label>
                <input type="number" max="100" min="0" step="0.01" name="multa_percentual" class="form-control" value="<?= $info['multa_percentual'] ?>" required>
            </div>
            <h3>Pagamentos de Matricula  e outros</h3>
            <div style="display: flex; gap: 10px; ">
            <div style="display: flex; width: 100%; flex-wrap: wrap; gap: 10px;">
            <div class="mb-3">
                <label class="form-label">Valor de Matricula:</label>
                <input type="number" min="0" name="valor_matricula" class="form-control" value="<?= $info['valor_Matricula'] ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Valor do uniforme escolar:</label>
                <input type="number" min="0" name="valor_uniforme" class="form-control" value="<?= $info['valor_uniforme'] ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Valor do cartão escolar:</label>
                <input type="number" min="0" name="valor_cartao" class="form-control" value="<?= $info['valor_cartao'] ?>" required>
            </div>
            </div>
            <div style="display: flex; width: 100%; flex-wrap: wrap; gap: 10px;">
              <div class="mb-3">
                <label class="form-label">Valor de estágio interno:</label>
                <input type="number" min="0" name="valor_estagio" class="form-control" value="<?= $info['valor_estagio'] ?>" required>
            </div>
              <div class="mb-3">
                <label class="form-label">Valor de Declaração:</label>
                <input type="number" min="0" name="valor_declaracao" class="form-control" value="<?= $info['valor_declaracao'] ?>" required>
            </div>
              <div class="mb-3">
                <label class="form-label">Valor de Certificado:</label>
                <input type="number" min="0" name="valor_certificado" class="form-control" value="<?= $info['valor_certificado'] ?>" required>
            </div>
            </div>
            </div>
             <button type="submit" class="btn-actualizar">Salvar Configuração</button>
        </form>
    </div>
	 <script src='../Scritps/Menu.js'></script>
    <script>
        let anoLectivoActual = document.getElementById('anoLectivo');
        anoLectivoActual.addEventListener('input', function(){
            let somaAno = 0;
            let valor = anoLectivoActual.value;
            somaAno = (valor - 0 ) + 1;
            document.getElementById('anoLectivoSeguinte').value = `${somaAno}`;
        });
        document.addEventListener("DOMContentLoaded", function(){
            let somaAno = 0;
            let valor = anoLectivoActual.value;
            somaAno = (valor - 0 ) + 1;
            document.getElementById('anoLectivoSeguinte').value = `${somaAno}`;
        });
    </script>
</body>
</html>
