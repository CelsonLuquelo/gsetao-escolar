<style>
    
/* Configuração padrão */
body {
    display: flex;
    margin: 0;
    overflow: auto;
    font-family: Arial, sans-serif;
}
body::-webkit-scrollbar {
    width: 10px;
    height: 10px;
}

body::-webkit-scrollbar-thumb {
    background-color: #007bff;
    border-radius: 5px;
}


/* Estilização do menu lateral */
#sidebar {
    width: 80px;
    height: 100vh;
    background: linear-gradient(135deg, #ff6600, #993300);
    transition: width 0.4s ease-in-out;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 10000000000;
    padding-top: 20px;
    overflow-y: auto;
    overflow-x: hidden;
    box-shadow: 4px 0 10px rgba(0, 0, 0, 0.3);
    border-right: 3px solid rgba(255, 255, 255, 0.2);
}
#sidebar::-webkit-scrollbar {
    width: 10px;
    height: 10px;
}

#sidebar::-webkit-scrollbar-thumb {
    background-color: #000;
    border-radius: 5px;
}
    .dashboard-header {
            text-align: center;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .dashboard-header img {
            height: 80px;
            width: 80px;
            border-radius: 50%;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            border: 3px solid #ffc107;
            margin-right: 20px;
        }
        
        .dashboard-header h1 {
            margin-top: 10px;
            color: #f8f9fa;
            font-size: 28px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }
		/* ✅ Título da Página */
h1 {
    text-align: center;
    font-size: 28px;
    background: linear-gradient(90deg, #ff8c00, #ff3b3b);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-weight: bold;
    margin-bottom: 5px;
}
/* Expande o menu ao passar o mouse */
#sidebar.not:hover {
    width: 240px;
}

/* Botão para alternar o menu */
#toggle-btn {
    background: none;
    border: none;
    color: white;
    font-size: 24px;
    margin-left: 20px;
    cursor: pointer;
    transition: transform 0.3s;
}

#toggle-btn:hover {
    transform: rotate(90deg);
}

/* Estilizando os itens do menu */
#sidebar ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

#sidebar ul li {
    padding: 8px 15px;
    transition: background 0.3s, transform 0.3s;
}

#sidebar ul li:hover {
    background: rgba(255, 255, 255, 0.2);
    transform: translateX(5px);
}

/* Ícones e textos do menu */
#sidebar ul li a {
    color: white;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 18px;
    padding: 10px;
    transition: color 0.3s;
}

/* Oculta os textos quando o menu está recolhido */
#sidebar ul li a span {
    display: none;
    opacity: 0;
    transition: opacity 0.3s;
}

/* Exibe os textos ao expandir */
#sidebar:hover ul li a span {
    display: inline;
    opacity: 1;
}
#sidebar:hover .spanTEXT{
    transition: .3s;
    visibility: visible;
}
#sidebar:hover .spanIMG{
    transition: .3s;
    visibility: hidden;
}
#sidebar .spanTEXT{
    transition: .3s;
    visibility: hidden;
}
#sidebar .spanIMG{
    transition: .3s;
    visibility: visible;
}

/* Efeito neon */
#sidebar ul li:hover a {
    text-shadow: 0 0 5px rgba(255, 204, 0, 0.8), 0 0 10px rgba(255, 204, 0, 0.5);
}

/* Estilização do conteúdo principal */
.container {
    margin-left: 100px;
    width: calc(100% - 100px);
    transition: margin-left 0.6s ease-in-out, width 0.6s ease-in-out;
}

/* Ajusta o conteúdo quando o menu está expandido */
#sidebar:hover ~ .container {
    margin-left: 290px;
    transition: .6s;
    width: calc(100% - 290px);
}
  .ContHora {
            background-color: rgba(255, 255, 255, .2);
            backdrop-filter: blur(5px);
            padding: 10px 15px;
            border-radius: 10px;
			color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            display: inline-flex;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .ContHora i {
            margin-right: 10px;
            color: #FFCE56;
        }

        
 /* ====== OVERLAY MOBILE ====== */
 .mobile-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    z-index: 500;
    opacity: 0;
    transition: opacity .6s ease-in;
}

.mobile-overlay.active {
    opacity: 1;
	  display: block;
}

  /* ====== CABEÇALHO MOBILE ====== */
  .mobile-header {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    height: 60px;
    background: linear-gradient(135deg, #ff6600, #993300);;
    z-index: 999;
    align-items: center;
    padding: 0 20px;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
}

.mobile-menu-toggle {
    background: none;
    border: none;
    color: white;
    font-size: 24px;
    cursor: pointer;
    transition: .5s ease;
}

.mobile-menu-toggle:hover {
    transform: scale(1.1);
    color: #ffc107;
}

.mobile-logo {
    display: flex;
    align-items: center;
    margin-left: auto;
}

.mobile-logo img {
    width: 35px;
    height: 35px;
    border-radius: 50%;
    border: 2px solid #ffc107;
}

.mobile-logo span {
    margin-left: 10px;
    font-weight: bold;
    font-size: 18px;
}

/* ====== BOTÃO TOGGLE DESKTOP ====== */
#toggle-btn {
    background: none;
    border: none;
    color: white;
    font-size: 20px;
    margin: 20px;
    cursor: pointer;
    transition:  0.5s ease;
    width: 30px;
    height: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
}

#toggle-btn:hover {
    transform: rotate(90deg);
    color:  #ffc107;
}
  /* Mobile */
  @media (max-width: 768px) {
    #sidebar {
        width: 0;
        transform: translateX(-100%);
        transition: all .6s ease;
    }

    #sidebar.mobile-open {
        width: 250px;
        transform: translateX(0);
    }

    .mobile-header {
        display: flex;
    }

   
    #sidebar.mobile-open ~ .container {
        margin-left: 0;
        width: 100%;
        margin-top: 60px;
        padding: 15px;
    }
    .container {
        margin-left: 0;
        width: 100%;
        margin-top: 60px;
        padding: 15px;
    }
    /* Exibe os textos ao expandir */
    #sidebar.mobile-open ul li a span {
        display: inline;
        opacity: 1;
    }
    #sidebar.mobile-open .spanTEXT{
        transition: .3s;
        visibility: visible;
    }
    #sidebar.mobile-open .spanIMG{
        transition: .3s;
        visibility: hidden;
    }
   
}

        /* ====== UTILIDADES ====== */
        .hidden { display: none !important; }
        .visible { display: block !important; }
        
        .text-center { text-align: center; }
        .text-left { text-align: left; }
        .text-right { text-align: right; }
        
        .mt-10 { margin-top: 10px; }
        .mt-20 { margin-top: 20px; }
        .mb-10 { margin-bottom: 10px; }
        .mb-20 { margin-bottom: 20px; }
        
        .p-10 { padding: 10px; }
        .p-20 { padding: 20px; }

        /* ====== ESTADOS DE LOADING ====== */
        .loading {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 200px;
        }

        .spinner {
            width: 40px;
            height: 40px;
            border: 4px solid rgba(255, 255, 255, 0.1);
            border-left: 4px solid var(--accent-color);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
       
</style>
<link rel="stylesheet" href="../Bibiliotecas/Font-Awesome-6.x/css/all.min.css">
<link rel="stylesheet" href="../Config/notification.css">
<?php if (isset($_SESSION['notification'])): ?>
    <div class="notification <?php echo htmlspecialchars($_SESSION['estado']); ?>" id="notification"><?php echo htmlspecialchars($_SESSION['notification']); ?></div>
    <?php unset($_SESSION['notification']); ?>
<?php endif; ?>

<script src='../Config/notification.js'></script>


 <!-- Cabeçalho Mobile -->
 <div class="mobile-header">
        <button class="mobile-menu-toggle" id="mobileMenuToggle">
            <i class="fas fa-bars"></i>
        </button>
        <div class="mobile-logo">
            <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8Y2lyY2xlIGN4PSI1MCIgY3k9IjUwIiByPSI0MCIgZmlsbD0iI2ZmNjYwMCIvPgogIDx0ZXh0IHg9IjUwIiB5PSI1NSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE4IiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0id2hpdGUiIHRleHQtYW5jaG9yPSJtaWRkbGUiPklDUkE8L3RleHQ+Cjwvc3ZnPgo=" alt="ICRA Logo">
            <span>ICRA</span>
        </div>
    </div>

    <!-- Overlay Mobile -->
    <div class="mobile-overlay" id="mobileOverlay"></div>

  <!-- Menu Lateral -->
  <div id="sidebar" class="not">
        <button id="toggle-btn">
            <i class="fas fa-bars" id="icon-botton"></i>
        </button>

    <ul>
        <li><a href="inicio.php"><i class="fas fa-home"></i><span>Início</span></a></li>
        <li><a href="Alunos.php"><i class="fas fa-user"></i><span>Alunos</span></a></li>
        <li><a href="pagamentos.php"><i class="fas fa-dollar-sign"></i><span>Pagamentos</span></a></li>
        <li><a href="Relatorio.php"><i class="fas fa-chart-line"></i><span>Relatórios</span></a></li>
        <li><a href="configuracoes.php"><i class="fas fa-cog"></i><span>Configurações</span></a></li>
        <li><a href="logout.php"><i class="fas fa-sign-out"></i><span>Sair</span></a></li>
    </ul>
    <p class="footer-bottom" style="position: relative; margin-top: 8vh; color: white; font-size: 10px; text-align: center;"><span class="spanIMG" style="display: block;"><img src="../arquivos/Logotipo/LOGO ICRA.jpg" alt="" style="border-radius: 50%; width: 30px; height: 30px; margin: 0 auto; display: block;">ICRA</span><span class="spanTEXT">&copy; 2025 ICRA. Todos os direitos reservados.</span></p>
</div>
