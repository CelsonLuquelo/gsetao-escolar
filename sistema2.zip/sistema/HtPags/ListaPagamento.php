<?php
session_start();
require '../Config/conexaoBD.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}



$search = isset($_GET['search']) ? $_GET['search'] : '';


// Paginação
$pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$limite = 10; // Número de registros por página
$offset = ($pagina - 1) * $limite;

// Conta o total de pagamentos
$total_pagamentos = $pdo->query("SELECT 
   COUNT(f.id_factura)
FROM  facturas f
JOIN pagamentos p ON f.id_pagamento = p.id_pagamento
JOIN alunos a ON p.id_aluno = a.id_aluno
JOIN cursos c ON a.id_curso = c.id_curso
JOIN classe cl ON a.id_classe = cl.id_classe
WHERE a.matricula LIKE '%$search%' 
   OR a.nome LIKE '%$search%'
   OR p.valor LIKE '%$search%'
   OR p.id_pagamento LIKE '%$search%' 
   OR f.id_factura LIKE '%$search%'
    OR p.mes LIKE '%$search%' 
   OR p.total LIKE '%$search%' 
    OR p.desconto LIKE '%$search%' 
    OR p.multa LIKE '%$search%' 
     OR c.curso LIKE '%$search%' 
      OR cl.nome LIKE '%$search%' 
       OR p.data_created LIKE '%$search%' ")->fetchColumn();

// Consulta para obter pagamentos com filtro de pesquisa
$query = "SELECT 
    p.id_pagamento,
    f.id_factura,
    a.nome,
    p.valor,
    a.matricula,
    c.curso,
    cl.nome AS classeNome,
    p.data_created,
    p.mes,
    p.total,
    p.desconto,
    p.multa
FROM  facturas f
JOIN pagamentos p ON f.id_pagamento = p.id_pagamento
JOIN alunos a ON p.id_aluno = a.id_aluno
JOIN cursos c ON a.id_curso = c.id_curso
JOIN classe cl ON a.id_classe = cl.id_classe
WHERE a.matricula LIKE '%$search%' 
   OR a.nome LIKE '%$search%'
   OR p.valor LIKE '%$search%'
   OR p.id_pagamento LIKE '%$search%' 
   OR f.id_factura LIKE '%$search%'
   OR p.total LIKE '%$search%' 
    OR p.desconto LIKE '%$search%' 
   OR p.mes LIKE '%$search%' 
    OR p.multa LIKE '%$search%' 
     OR c.curso LIKE '%$search%' 
      OR cl.nome LIKE '%$search%' 
       OR p.data_created LIKE '%$search%' 
    ORDER BY p.id_pagamento ASC 
    LIMIT $limite OFFSET $offset";

$result = mysqli_query($conn, $query);
$total_pagamentos = $search == '' ? $total_pagamentos  : $total_pagamentos;
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listagem dos Pagamentos</title>
    <link rel="icon" style="width: 100%; height:100%;" type="image/x-png" href="../arquivos/Logotipo/LOGO ICRA.jpg">
    <link rel="stylesheet" href="../Bibiliotecas/pace-1.2.4/themes/red/pace-theme-center-atom.css">
    <script src="../Bibiliotecas/pace-1.2.4/pace.min.js"></script>
    <link rel="stylesheet" href="../Styles/StyleInderf.css">
</head>
<body>
        
    <!--Menu Interativo-->
    <?php require 'Menu.php'; ?>
    <div class="container">
    <header>
        <h1>Listagem de pagamentos</h1>
    </header>
    <!-- Barra de Pesquisa -->
    <section>
        <form action="">
            <input type="text" name="search" placeholder="Pesquisar..." value="<?= htmlspecialchars($search); ?>">
            <button type="submit">Buscar</button>
        </form>
    </section>

    <!-- Tabela de pagamentos -->
    <section class="lista-pagamento">
        <table>
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Mês</th>
                    <th>Curso</th>
                    <th>Classe</th>
                    <th>Valor proprina</th>
                    <th>Multa</th>
                    <th>Desconto</th>
                    <th>Total</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
            <?php if (isset($result)): ?>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?= $row['nome']; ?></td>
                        <td><?= $row['mes']; ?></td>
                        <td><?= $row['curso']; ?></td>
                        <td><?= $row['classeNome']; ?></td>
                        <td><?= number_format($row['valor'], 2, ',', '.'); ?></td>
                        <td><?= number_format($row['multa'], 2, ',', '.'); ?></td>
                        <td><?= number_format($row['desconto'], 2, ',', '.'); ?></td>
                        <td><?= number_format($row['total'], 2, ',', '.'); ?></td>
                        <td>
                           <button style="background: transparent; border: none;" onclick="window.location='imprimir_uma_factura.php?id_factura=<?= $row['id_factura']; ?>'"><i class="fas fa-info-circle" style="color: blue; font-size: 20px;"></i></button>
                        </td>
                    </tr>
                <?php } ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8">Nenhum pagamento registrado.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

         <!-- Paginação -->
         <div class="pagination">
            <?php for ($i = 1; $i <= ceil($total_pagamentos / $limite); $i++): ?>
                <a href="ListaPagamento.php?pagina=<?php echo $i; ?>&search=<?php echo $search ? $search : ''; ?>" 
                   class="<?php echo $i == $pagina ? 'active' : ''; ?>">
                   <?php echo $i; ?>
                </a>
          <?php endfor; ?>
        </div>
    </section>
    <div id="excluir">
        <div class="fundo">
           <div class="ContExcluir" id="ContExcluir">

           </div> 
        </div>
    </div>
    </div>
    </main>
    <script src="../Config/mensagens.js"></script>
    <script src="../scripts/Menu.js"></script>
    <script>
        const excluir = document.getElementById("excluir");
        function sairAlter(){
           detalhar.classList.remove('active');
           excluir.classList.remove('active');
        }
        function ExcluirVenda(id){
              document.getElementById("excluir").classList.toggle('active');
             if( document.getElementById("excluir").classList.contains('active')){
                document.getElementById("ContExcluir").innerHTML=`
                  <button class="SairAlter icon-remove" onclick="sairAlter()"></button>
                <h3>Confirmação</h3>
                <p>Tens certeza que queres excluir este registro</p>
                <a href='../Config/excluir_venda.php?id_venda=${id}'>Excluir</a>`;
             }else{
                document.getElementById("ContExcluir").innerHTML=''; 
             }
        }

          // Fechar o modal ao clicar fora
       window.addEventListener('click', (event) => {
            if (event.target === document.getElementById("fundoCadastro")) {
                detalhar.classList.remove("active");
            }
            if(event.target === document.getElementById("fundo")) {
                excluir.classList.remove("active");
            }
        });
    </script>
	 <script src='../Scritps/Menu.js'></script>
</body>
</html>
