
<?php
session_start();


session_destroy();

?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Gestão Escolar</title>
    <link rel="icon" style="width: 100%; height:100%;" type="image/x-png" href="../arquivos/Logotipo/LOGO ICRA.jpg">
    <link rel="stylesheet" href="../Bibiliotecas/pace-1.2.4/themes/red/pace-theme-center-atom.css">
    <script src="../Bibiliotecas/pace-1.2.4/pace.min.js"></script>
    <!-- Estilos -->
    <style>

/* Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Arial", sans-serif;
}

/* Fundo animado */
body {
    display: flex;
    overflow: hidden;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
}

/* Container */
.login-container {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
}

/* Box de Login */
.login-box {
    background: rgba(255, 255, 255, 0.1);
    padding: 30px;
    border-radius: 10px;
    backdrop-filter: blur(10px);
    text-align: center;
    width: 320px;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.5);
    border: 1px solid rgba(255, 255, 255, 0.2);
}

/* Título */
h2 {
    color: white;
    font-size: 24px;
    margin-bottom: 20px;
}

/* Inputs */
.input-group {
    position: relative;
    margin-bottom: 20px;
}

.input-group i {
    position: absolute;
    left: 10px;
    top: 50%;
    transform: translateY(-50%);
    color: white;
}

.input-group input {
    width: 100%;
    padding: 10px 40px;
    border: none;
    border-radius: 5px;
    background: rgba(255, 255, 255, 0.2);
    color: white;
    outline: none;
    transition: 0.3s;
}

.input-group input:focus {
    background: rgba(255, 255, 255, 0.3);
}

/* Botão */
.btn {
    width: 100%;
    padding: 10px;
    border: none;
    border-radius: 5px;
    background: #ffcc00;
    color: #302b63;
    font-size: 16px;
    cursor: pointer;
    transition: 0.3s;
}

.btn:hover {
    background: #ffd633;
}
/* Esqueceu a senha */
.forgot {
    display: block;
    margin-top: 10px;
    color: white;
    text-decoration: none;
    transition: 0.3s;
}

.forgot:hover {
    color: #ffcc99;
}
/* 🔔 Notificação dinâmica */
.notification {
    position: fixed;
    top: -50px;
    left: 50%;
    z-index: 9000000000000000;
    transform: translateX(-50%);
    background: #00ff80;
    color: white;
    padding: 10px 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
    transition: all 3s ease-in-out;
    opacity: 0;
    font-weight: bold;
    text-align: center;
    min-width: 200px;
}
.notification.erro {
    background: red;
    color: white;
}
    </style>
    
    <!-- Ícones FontAwesome -->
    <link rel="stylesheet" href="../Bibiliotecas/Font-Awesome-6.x/css/all.min.css">
    
    <!-- Biblioteca AOS -->
    <link rel="stylesheet" href="../Bibiliotecas/aos-master (1)/aos-master/dist/aos.css">
</head>
<body>
    <?php if (isset($_SESSION['notification'])): ?>
        <div class="notification <?php echo htmlspecialchars($_SESSION['estado']); ?>" id="notification"><?php echo htmlspecialchars($_SESSION['notification']); ?></div>
        <?php unset($_SESSION['notification']); ?>
    <?php endif; ?>
   
    <div class="login-container">
        <div class="login-box" data-aos="fade-up">
            <h2>Bem-vindo ICRA</h2>
            <form action="../Config/processar_login.php" method="POST">
                <div class="input-group">
                    <i class="fa fa-user"></i>
                    <input type="text" name="email" placeholder="Usuário ou E-mail" required>
                </div>
                <div class="input-group">
                    <i class="fa fa-lock"></i>
                    <input type="password" name="senha" placeholder="Senha" required>
                </div>
                <br>
                <button type="submit" class="btn">Entrar</button>
                <br>
            </form>
        </div>
    </div>

    <!-- Scripts -->
    <script src="../Bibiliotecas/aos-master (1)/aos-master/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 1000,
            easing: "ease-in-out",
        });

       //Exibir Mensagem
        document.addEventListener('DOMContentLoaded',function(){
        const mensagem = document.getElementById("notification");
        mensagem.style.top="50%";
        mensagem.style.opacity="1";
            setInterval(function(){
                mensagem.style.position="absolute";
                mensagem.style.top="-100px";
                mensagem.style.opacity="0";
        },10000);
        });
    </script>
</body>
</html>