<?php
session_start();
require '../Config/conexaoBD.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurações - Gestão Escolar</title>
    <link rel="icon" style="width: 100%; height:100%;" type="image/x-png" href="../arquivos/Logotipo/LOGO ICRA.jpg">
    <link rel="stylesheet" href="../Bibiliotecas/pace-1.2.4/themes/red/pace-theme-center-atom.css">
    <script src="../Bibiliotecas/pace-1.2.4/pace.min.js"></script>
    <link rel="stylesheet" href="../Styles/configuracoes.css">
</head>
<body>
    
    <!--Menu Interativo-->
    <?php require 'Menu.php'; ?>
  
   <!--Conteúdo Principal-->
    <div class="container">
<div class="ContHora"><i class="fas fa-clock"></i><span style="font-size: 20px;" id="recebHora"></span></div>
        
        <div class="dashboard-header">
            <img src="../arquivos/Logotipo/LOGO ICRA.jpg" alt="Logo ICRA">
             <h1 style="margin-top: -5px;">Configurações</h1>
        </div> 

        <div class="cards">
        <a href="gerenciarPerfil.php" class="card">
        <i class="fas fa-user"></i>
        <h3>Gerenciar Perfil</h3>
        </a>
        <?php if($_SESSION['nivel_acesso'] === "Administrador"): ?>
        <a href="gerenciarUsuario.php" class="card">
        <i class="fas fa-users"></i>
        <h3>Gerenciar usuários</h3>
        </a>
        <?php endif; ?>
        <?php if($_SESSION['nivel_acesso'] === "Administrador"): ?>
        <a href="actualizar_informacoes.php" class="card">
            <i class="fas fa-repeat"></i>
        <h3>Actualizar Informações</h3>
        </a>
        <?php endif; ?>
    </div>
    </div>
	 <script src='../Scritps/Menu.js'></script>
</body>
</html>