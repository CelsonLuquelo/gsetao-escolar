<?php 
session_start();
require '../Config/conexaoBD.php';
 

// Verifica se o usuário está logado
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}


// Buscar alunos por classe
$queryClasses = "SELECT c.nome AS classeAL, COUNT(a.id_aluno) AS total FROM alunos a 
                 JOIN classe c ON a.id_classe = c.id_classe 
                 GROUP BY c.id_classe";
$resultClasses = $conn->query($queryClasses);
$classes = [];
$quantidadeClasses = [];
while ($row = $resultClasses->fetch_assoc()) {
    $classes[] = $row['classeAL']."ª";
    $quantidadeClasses[] = $row['total'];
}

// Buscar alunos por curso
$queryCursos = "SELECT cu.curso AS cursoAL, COUNT(a.id_aluno) AS total FROM alunos a 
                JOIN cursos cu ON a.id_curso = cu.id_curso 
                GROUP BY cu.id_curso";
$resultCursos = $conn->query($queryCursos);
$cursosAl = [];
$quantidadeCursosA = [];
while ($row = $resultCursos->fetch_assoc()) {
    $cursosAl[] = $row['cursoAL'];
    $quantidadeCursosA[] = $row['total'];
}


// Buscar quantidade de pagamentos por mês
$queryPagamentos = "SELECT MONTH(data_created) AS mesPag, COUNT(id_pagamento) AS total 
                    FROM pagamentos 
                    WHERE YEAR(data_created) = YEAR(CURDATE()) 
                    GROUP BY MONTH(data_created)";
$resultPagamentos = $conn->query($queryPagamentos);

$meses = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
$pagamentosMensais = array_fill(0, 12, 0);

while ($row = $resultPagamentos->fetch_assoc()) {
    $pagamentosMensais[$row['mesPag'] - 1] = $row['total'];
}


// Buscar a soma total de pagamentos por curso
$queryPagamentosPorCurso = "SELECT c.curso AS cursoAL, SUM(p.total) AS total_pagamentos 
    FROM pagamentos p
    JOIN alunos a ON p.id_aluno = a.id_aluno
    JOIN cursos c ON a.id_curso = c.id_curso
    GROUP BY c.id_curso
    ORDER BY total_pagamentos DESC";

$result = $conn->query($queryPagamentosPorCurso);

$cursos = [];
$pagamentos = [];

while ($row = $result->fetch_assoc()) {
    $cursos[] = $row['cursoAL'];
    $pagamentos[] = $row['total_pagamentos'];
}



// Buscar a quantidade de alunos por ano letivo
$queryCrescimento = "SELECT YEAR(created_at) AS ano_letivo, COUNT(id_aluno) AS total_alunos 
    FROM alunos 
    GROUP BY YEAR(created_at)
    ORDER BY ano_letivo ASC";

$result = $conn->query($queryCrescimento);

$anos = [];
$total_alunos = [];

while ($row = $result->fetch_assoc()) {
    $anos[] = $row['ano_letivo'];
    $total_alunos[] = $row['total_alunos'];
}



$queryPagDiario = "SELECT DATE(data_created) AS dia, SUM(total) AS total FROM pagamentos 
    WHERE DATE(data_created) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) GROUP BY DATE(data_created) ORDER BY dia ASC 
";
$resultPagDiario = $conn->query($queryPagDiario);

$PagDia = [];
$PagTotal = [];
while ($row = $resultPagDiario->fetch_assoc()) {
    $PagDia[] = $row['dia'];
    $PagTotal[] = $row['total'];
}


// Total de alunos
$queryTotalAlunos = "SELECT COUNT(*) AS total FROM alunos";
$resultTotalAlunos = $conn->query($queryTotalAlunos);
$totalAlunos = $resultTotalAlunos->fetch_assoc()['total'];

// Total de pagamentos (valor)
$queryTotalPagamentos = "SELECT SUM(total) AS total FROM pagamentos WHERE YEAR(data_created) = YEAR(CURDATE())";
$resultTotalPagamentos = $conn->query($queryTotalPagamentos);
$totalPagamentos = $resultTotalPagamentos->fetch_assoc()['total'];

// Total de pagamentos (quantidade)
$queryQtdPagamentos = "SELECT COUNT(*) AS total FROM pagamentos WHERE YEAR(data_created) = YEAR(CURDATE())";
$resultQtdPagamentos = $conn->query($queryQtdPagamentos);
$qtdPagamentos = $resultQtdPagamentos->fetch_assoc()['total'];

// Total de cursos
$queryTotalCursos = "SELECT COUNT(*) AS total FROM cursos";
$resultTotalCursos = $conn->query($queryTotalCursos);
$totalCursos = $resultTotalCursos->fetch_assoc()['total'];

function formatarValor($valor) {
    if ($valor >= 1000000) {
        return number_format($valor / 1000000, 1) . 'M Kz';
    } elseif ($valor >= 1000) {
        return number_format($valor / 1000, 1) . 'K Kz';
    } else {
        return number_format($valor, 0) . ' Kz';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema - Inicio</title>
    <link rel="icon" style="width: 100%; height:100%;" type="image/x-png" href="../arquivos/Logotipo/LOGO ICRA.jpg">
    <link rel="stylesheet" href="../Bibiliotecas/pace-1.2.4/themes/red/pace-theme-center-atom.css">
    <script src="../Bibiliotecas/pace-1.2.4/pace.min.js"></script>
    <link rel="stylesheet" href="../../assents/icomoon/style.css">
    <link rel="stylesheet" href="../Styles/inicio.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <!--Menu Interativo-->
    <?php require 'Menu.php'; ?>
	
  
   <!--Conteúdo Principal-->
    <div class="container">
	 <!-- Estatísticas Resumidas -->
        <div class="stats-cards">
            <div class="stat-card">
                <h3>Total de Alunos</h3>
                <div class="stat-value"><?php echo $totalAlunos; ?></div>
            </div>
            <div class="stat-card">
                <h3>Pagamentos Anuais</h3>
                <div class="stat-value"><?php echo formatarValor($totalPagamentos); ?></div>
            </div>
            <div class="stat-card">
                <h3>Qtd. Pagamentos</h3>
                <div class="stat-value"><?php echo $qtdPagamentos; ?></div>
            </div>
            <div class="stat-card">
                <h3>Total de Cursos</h3>
                <div class="stat-value"><?php echo $totalCursos; ?></div>
            </div>
        </div>
        <div class="ContHora"><span style="font-size: 20px;" id="recebHora"></span></div>
        <div style="margin-top: 10px;">
           <img src="../arquivos/Logotipo/LOGO ICRA.jpg" alt="" style="height: 80px; width: 80px; border-radius: 50%; margin: 0 auto; display: block;">
           <h1 style="margin-top: -5px;">Dashboard (ICRA)</h1>
        </div>
        <div class="cards" id="cards">
        <div class="card">
        <h3>Pagamentos diario</h3>
        <canvas id="VendaDiaria"></canvas>
      </div>

      <div class="card"> 
       <h3>Quantidade de Alunos por Classe</h3>
        <canvas id="graficoClasses"></canvas>
      </div>
      <div class="card">
        <h3>Quantidade de Alunos por Curso</h3>
         <canvas id="graficoCursos"></canvas>
      </div>
      <div class="card">
      <h3>Pagamentos Realizados por Mês</h3>
        <canvas id="graficoPagamentos"></canvas>
      </div>
      <div class="card">
       <h3>Comparação de Pagamentos por Curso</h3>
        <canvas id="graficoPagamentosCurs"></canvas>
      </div>
      <div class="card">
        <h3>Crescimento da Escola por Ano Letivo</h3>
        <canvas id="graficoCrescimento"></canvas>
      </div>
    </div>
    </div>
	 <script src='../Scritps/Menu.js'></script>
  <script>
    const ctxVendasDi = document.getElementById('VendaDiaria').getContext('2d');
     new Chart(ctxVendasDi, {
      type: 'line',
      data: {
        labels: <?php echo json_encode($PagDia); ?>,
        datasets: [{
          label: 'Pagamentos Diarios (Kz)',
          data: <?php echo json_encode($PagTotal); ?>,
                backgroundColor:[ 'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'],
                borderColor: 'rgb(26, 27, 27)',
                borderWidth: 2,
                fill: true,
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: true },
            },
        }
    });
   const ctxClasses = document.getElementById('graficoClasses').getContext('2d');
        new Chart(ctxClasses, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($classes); ?>,
                datasets: [{
                    label: 'Alunos por Classe',
                    data: <?php echo json_encode($quantidadeClasses); ?>,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'hsla(30, 100.00%, 62.50%, 0.20)',
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: true },

            },
        }
    });
  const ctxCursos = document.getElementById('graficoCursos').getContext('2d');
        new Chart(ctxCursos, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($cursosAl); ?>,
                datasets: [{
                    label: 'Alunos por Curso',
                    data: <?php echo json_encode($quantidadeCursosA); ?>,
                backgroundColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(153, 102, 255, 0.2)',
                    'hsla(30, 100.00%, 62.50%, 0.20)',
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)',
                    'rgba(75, 255, 192, 1)',
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: true },
               
            },
        }
    });
    const ctxPagCurs = document.getElementById('graficoPagamentosCurs').getContext('2d');
        new Chart(ctxPagCurs, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($cursos); ?>,
                datasets: [{
                    label: 'Total de Pagamentos',
                    data: <?php echo json_encode($pagamentos); ?>,
                    backgroundColor: [
                    'rgba(255, 99, 132, 0.6)',
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(255, 206, 86, 0.6)',
                    'rgba(75, 192, 192, 0.6)'
                ],
                    borderColor: '#ffc107',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
 const ctxPagamentos = document.getElementById('graficoPagamentos').getContext('2d');
        new Chart(ctxPagamentos, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($meses); ?>,
                datasets: [{
                    label: 'Pagamentos por Mês',
                    data: <?php echo json_encode($pagamentosMensais); ?>,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.6)',
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(255, 206, 86, 0.6)',
                    'rgba(75, 192, 192, 0.6)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: true },
               
            },
        }
    });
  
   const ctx = document.getElementById('graficoCrescimento').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($anos); ?>,
                datasets: [{
                    label: 'Total de Alunos',
                    data: <?php echo json_encode($total_alunos); ?>,
                    borderColor: '#ffc107',
                    backgroundColor: [
                    'rgba(255, 99, 132, 0.6)',
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(255, 206, 86, 0.6)',
                    'rgba(75, 192, 192, 0.6)'
                ],
                    borderWidth: 2,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

  </script>
</body>
</html>