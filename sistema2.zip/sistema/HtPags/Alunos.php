<?php
session_start();
require '../Config/conexaoBD.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}


    $stmt = $pdo->prepare("SELECT * FROM informacoes_basicas");
    $stmt->execute();
    $infor = $stmt->fetch(PDO::FETCH_ASSOC);


    // Busca os ano lectivo
    $sql1 = "SELECT * FROM anolectivo WHERE id = 1";
    $result1 = $conn->query($sql1);
    $info1 = $result1->fetch_assoc();

    $anoHoje = intval($info1['ano']);
    $anoHojeM = $anoHoje+1;

    //Buscar alunos pelos deste ano lectivo
    $query = "SELECT a.*, t.nome AS turma, c.nome AS NomeClasse, cu.curso AS NomeCurso FROM alunos a 
    INNER JOIN classe c ON a.id_classe = c.id_classe 
    INNER JOIN cursos cu ON a.id_curso = cu.id_curso
    INNER JOIN turmas t ON a.id_turma = t.id_turma 
    WHERE a.ano = $anoHoje OR a.ano = $anoHojeM
    ORDER BY created_at DESC";
    $result = $conn->query($query);


    // Consulta para listar classes (usado no cadastro de alunos)
    $stmt_classes = $pdo->prepare("SELECT id_classe, nome FROM classe");
    $stmt_classes->execute();
    $classes = $stmt_classes->fetchAll(PDO::FETCH_ASSOC);

     // Consulta para listar cursos (usado no cadastro de cursos)
     $stmt_cursos = $pdo->prepare("SELECT id_curso, curso FROM cursos");
     $stmt_cursos->execute();
     $cursos = $stmt_cursos->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alunos - Gestão Escolar</title>
    <link rel="icon" style="width: 100%; height:100%;" type="image/x-png" href="../arquivos/Logotipo/LOGO ICRA.jpg">
    <link rel="stylesheet" href="../Bibiliotecas/pace-1.2.4/themes/red/pace-theme-center-atom.css">
    <script src="../Bibiliotecas/pace-1.2.4/pace.min.js"></script>
    <link rel="stylesheet" href="../Bibiliotecas/Font-Awesome-6.x/css/all.min.css">
     <link rel="stylesheet" href="../Styles/Alunos.css">
</head>
<body>
    
    <!--Menu Interativo-->
    <?php require 'Menu.php'; ?>
  
    <!--Conteúdo Principal-->
    <div class="container">
        <div class="ContHora"><i class="fas fa-clock"></i><span style="font-size: 20px;" id="recebHora"></span></div>
        
        <div class="dashboard-header">
            <img src="../arquivos/Logotipo/LOGO ICRA.jpg" alt="Logo ICRA">
           <h1>📚 Gestão de Alunos</h1>
        </div>
    
    <div class="ContSearch">
        <!-- Campo de Pesquisa -->
        <input type="text" id="searchAluno" placeholder="&#xf002; Pesquisar aluno..." onkeyup="filtrarAlunos()" class="fa">
    </div>
    <div style="display: flex; flex-wrap: wrap;">
        <!-- Botão para Adicionar Novo Aluno -->
        <button class="btn-adicionar" onclick="abrirModal('modalAdicionar')">
            <i class="fa-solid fa-user-plus"></i> Matricular
        </button>
        <button style="background: rgb(0, 204, 255); margin-left: 20px;" class="btn-adicionar" onclick="document.getElementById('Erro').style.display='block';">
        <i class="fas fa-repeat"></i> Actualizar todos Alunos
        </button>
        <?php if($_SESSION['nivel_acesso'] === "Administrador"): ?>
        <button class="btn-curso" style="position: relative; margin-left: 20px;" onclick="window.location ='Cursos.php';">
         Cursos <i class="fa-solid fa-user-plus"></i>
        </button>
         <button onclick="window.location ='Turmas.php';" class="btn-turma" style="background: rgb(0, 0, 255); margin-left: 20px;">
         Turmas <i class="fa-solid fa-users"></i>
        </button>
    <?php endif; ?>
    </div>

    <div class="lista-alunos">
        <?php if($result->num_rows==0): ?>
            <h3>Nenhum aluno cadastrado neste ano lectivo(<?= $anoHoje ?>/<?= $anoHojeM ?>)</h3>
        <?php else:?>
        <?php
        while ($aluno = $result->fetch_assoc()) {
        ?>
            <div class="aluno-card" data-nome="<?= strtolower($aluno['nome']) ?>">
                <img src="../arquivos/fotos_dos_alunos/<?= $aluno['foto'] ?>" alt="Foto do Aluno"><span style='text-align: right; display: block; position: relative;'><strong><?= $aluno['matricula'] ?></strong></span>
                <div class="aluno-info">
                    <h2><i class="fa-solid fa-user"></i> <?= $aluno['nome'] ?> (<?= $aluno['idade'] ?> anos)</h2>
                    <p><i class="fa-solid fa-house"></i> <strong>Morada:</strong> <?= $aluno['morada'] ?></p>
                    <p><i class="fa-solid fa-phone"></i> <strong>Encarregado:</strong> <?= $aluno['numero_encarregado'] ?></p>
                    <p><i class="fa-solid fa-book"></i> <strong>Curso: </strong> <?= $aluno['NomeCurso'] ?></p>
                    <p><i class="fa-solid fa-book"></i> <strong>Classe: </strong> <?= $aluno['NomeClasse'] ?>ª</p>
                    <p><i class="fa-solid fa-users"></i> <strong>Turma:</strong> <?= $aluno['turma'] ?></p>
                </div>
                <div class="aluno-acoes">
                    <button class="btn-editar" onclick="EditarAluno(<?= $aluno['id_aluno']; ?>)">
                        <i class="fas fa-edit"></i> Editar
                    </button>
                    <?php if($_SESSION['nivel_acesso'] === "Administrador"): ?>
                    <button class="btn-excluir" onclick="abrirModalExcluir(<?= $aluno['id_aluno']; ?>)">
                        <i class="fa-solid fa-trash"></i> Excluir
                    </button>
                    <?php endif; ?>
                    <button class="btn-pagamento" onclick="window.location='detalhes_aluno.php?id=<?= $aluno['id_aluno'] ?>'">
                        <i class="fa-solid fa-money-bill-wave"></i> Pagamento
                    </button>
                </div>
            </div>
        <?php } ?>
        <?php endif; ?>
    </div>
	<div id="Erro2" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background-color:rgba(0,0,0,0.4); z-index:9000000000000000000000000000000; color:#fff;">
        <div class="model3">
           <button onclick="document.getElementById('Erro2').style.display='none'" class="icon-remove" style="padding:10px; margin-bottom: 20px; position: absolute;top: 20px; left: 95%; transform: translate(-50%,-50%);background: transparent; font-size: 24px; color: #ff4d4d; border:none; border-radius:50%; cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
            <p style="color: black; text-align: center;">Está turma não pode receber mais estudantes, devido ao limite de estudantes em cada turma.</p>
            <div style="display: flex;">
                <button style="background: grey; padding: 10px; border: 1px solid #ddd; border-radius: 9px; margin: 0 auto; display: block;" onclick="document.getElementById('Erro2').style.display='none'">OK</button>
            </div>
        </div>
    </div>
    <div id="Erro" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background-color:rgba(0,0,0,0.4); z-index:9000000000000000000000000000000; color:#fff;">
        <div class="model3">
           <button onclick="voltrarPag()" class="icon-remove" style="padding:10px; margin-bottom: 20px; position: absolute;top: 20px; left: 95%; transform: translate(-50%,-50%);background: transparent; font-size: 24px; color: #ff4d4d; border:none; border-radius:50%; cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
            <p style="color: black; text-align: center;">Ao actualiazar o todos alunos, os alunos cadastrados no ano lectivo passado seram actualizados para este ano.</p>
            <div style="display: flex;">
                <button style="background: green; padding: 10px; border: 1px solid #ddd; border-radius: 9px; margin: 0 auto; display: block;" onclick="window.location='../Config/actualizarAlunos.php'">Confirmar</button>
                <button style="background: red; padding: 10px; border: 1px solid #ddd; border-radius: 9px; margin: 0 auto; display: block;" onclick="document.getElementById('Erro').style.display='none';">Cancelar</button>
            </div>
        </div>
    </div>

    <!-- Modais -->
   <?php include 'modais.php'; ?>
 <script src='../Scritps/Menu.js'></script>
<script>
      const nome = document.getElementById('edit_nome');
       const BI = document.getElementById('edit_BI');
       const data_nasc = document.getElementById('edit_data_nasc');
       const morada = document.getElementById('edit_morada');
       const NEncar = document.getElementById('edit_numero_encarregado');
       const id_classe = document.getElementById('edit_classe');
       const foto = document.getElementById('edit_foto');
       const id_curso = document.getElementById('edit_curso');

    let modal;
    let herancaAbrir;

function abrirModal(id, alunoId) {
    herancaAbrir =  document.getElementById(id);
    modal = document.getElementById(id);
    modal.style.display = "flex";
    modal.classList.add("fade-in");
    document.getElementById('modalConfirmacao').style.display='none';
}

function abrirModalExcluir(alunoId){
    herancaAbrir = document.getElementById('modalExcluir');
    document.getElementById('deleteId').value = alunoId;
    abrirModal('modalExcluir');
}

function VerificarEnviar() {
    const turma_id = document.getElementById('turma_select').value;
    const formAdicionar = document.getElementById("formAdicionar");
    const classe = document.getElementById("classe_select").value;
    
    VerificarLimite(turma_id, function() {
        if (classe == 4) {
            // Para alunos da 4ª classe, mostrar opções de estágio
            document.getElementById('modalConfirmacao').style.display = 'none';
            document.getElementById('modalEstagio').style.display = 'flex';
        } else {
            document.getElementById("modoPagamento").value = document.getElementById("modoPagamentoR").value;
            document.getElementById("tipoEstagio").value = null;
            formAdicionar.submit();
        }
    });
}
document.getElementById("tipoEstagioR").addEventListener("click", function(){
    if(document.getElementById("tipoEstagioR").value == "Interno"){
        document.getElementById("valorEstagio").innerText = <?= $infor['valor_estagio'] ?>;
    }else{
        document.getElementById("valorEstagio").innerText = 0;
    }
     
});
function EnviarDados() {
    const turma_id = document.getElementById('turma_select').value;
    const formAdicionar = document.getElementById("formAdicionar");
    
    VerificarLimite(turma_id, function() {
        document.getElementById("tipoEstagio").value = document.getElementById("tipoEstagioR").value;
        if (document.getElementById("tipoEstagio").value == "Interno") {
            document.getElementById("valorEstagioR").value = document.getElementById("valorEstagio").innerText;
        } else {
            document.getElementById("valorEstagio").value = 0;
        }
        document.getElementById("modoPagamento").value = document.getElementById("modoPagamentoR").value;
        formAdicionar.submit();
    });
}
// Agora, vamos modificar as funções que usam VerificarLimite:
function AbrirOutroModal() {
    const formAdicionar = document.getElementById("formAdicionar");
    const turma_id = document.getElementById('turma_select').value;
    
    if (!turma_id) {
        alert("Por favor, selecione uma turma antes de continuar.");
        return;
    }
    
    if (formAdicionar.checkValidity()) {
        // Verificar limite de turma antes de abrir modal de confirmação
        VerificarLimite(turma_id, function() {
            document.getElementById('modalConfirmacao').style.zIndex = "999999999999999999999999999999999";
            document.getElementById('modalConfirmacao').style.display = 'flex';
        });
    } else {
        formAdicionar.reportValidity(); // Mostra os erros automaticamente
    }
}

function EditarAluno(id_aluno) {
    // Definir globalmente a variável do aluno sendo editado
    window.aluno_id = id_aluno;
    
    fetch(`../Config/buscar_aluno.php?id_aluno=${id_aluno}`)
        .then(Response => Response.json())
        .then(data => {
            if (!data || !data.aluno) {
                console.error("Dados do aluno não encontrados");
                return;
            }
            
            const turmaSelect = document.getElementById('edit_turma');
            const classeSelect = document.getElementById('edit_classe');
            const cursoSelect = document.getElementById('edit_curso');
            
            document.getElementById('edit_id').value = id_aluno;
            document.getElementById('edit_nome').value = data.aluno.nome;
            document.getElementById('edit_morada').value = data.aluno.morada;
            document.getElementById('edit_data_nasc').value = data.aluno.data_nascimento;
            document.getElementById('edit_numero_encarregado').value = data.aluno.numero_encarregado;
            document.getElementById('edit_BI').value = data.aluno.BI;
            
            // Limpar os selects antes de preencher
            classeSelect.innerHTML = "";
            cursoSelect.innerHTML = "";
            
            // Preencher classes
            data.classes.forEach(classe => {
                const option = document.createElement("option");
                option.value = classe.id_classe;
                option.textContent = classe.nome + "ª";
                if (classe.id_classe == data.aluno.id_classe) {
                    option.selected = true;
                }
                classeSelect.appendChild(option);
            });
            
            // Preencher cursos
            data.cursos.forEach(curso => {
                const option = document.createElement("option");
                option.value = curso.id_curso;
                option.textContent = curso.curso;
                if (curso.id_curso == data.aluno.id_curso) {
                    option.selected = true;
                }
                cursoSelect.appendChild(option);
            });
            
            // Carregar turmas com base no curso e classe selecionados
            carregarTurmas(data.aluno.id_curso, data.aluno.id_classe, turmaSelect, id_aluno);
        })
        .catch((erro) => {
            console.error('Erro ao buscar dados do aluno:', erro);
        });
        
    document.getElementById('modalEditar').style.display = "flex";
    herancaAbrir = document.getElementById('modalEditar');
}

// Função auxiliar para carregar turmas (para ser usada em EditarAluno)
function carregarTurmas(cursoId, classeId, selectElement, alunoId = null) {
    if (!cursoId || !classeId) return;
    
    fetch(`../Config/buscar_turma.php?id_curso=${cursoId}&id_classe=${classeId}${alunoId ? '&aluno_id='+alunoId : ''}`)
        .then(response => response.json())
        .then(data => {
            selectElement.innerHTML = "<option value=''>-- Selecione a Turma --</option>";
            
            data.turmas.forEach(tur => {
                const option = document.createElement("option");
                option.value = tur.id_turma;
                
                // Verifica se o aluno já está na turma (para edição)
                const estaNaTurma = alunoId && tur.alunos_ids && tur.alunos_ids.includes(parseInt(alunoId));
                const turmaCheia = tur.total_alunos >= tur.limite_aluno && !estaNaTurma;
                
                if (turmaCheia) {
                    option.disabled = true;
                    option.textContent = `${tur.nome} (${tur.total_alunos}/${tur.limite_aluno}) - CHEIA`;
                } else {
                    option.textContent = `${tur.nome} (${tur.total_alunos}/${tur.limite_aluno})`;
                }
                
                if (estaNaTurma || (data.aluno && tur.id_turma == data.aluno.id_turma)) {
                    option.selected = true;
                }
                
                selectElement.appendChild(option);
            });
        })
        .catch((erro) => {
            console.error('Erro ao carregar turmas:', erro);
            selectElement.innerHTML = "<option value=''>Erro ao carregar turmas</option>";
        });
}

// Função melhorada para verificar limites de turma
function VerificarLimite(id_turma, callback, alunoId = null) {
    if (!id_turma) {
        console.error("ID da turma não fornecido");
        return;
    }
    
    let url = `../Config/analisarLimite.php?id_turma=${id_turma}`;
    if (alunoId) {
        url += `&aluno_id=${alunoId}`;
    }
    
    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.turma_cheia === true) {
                document.getElementById('Erro2').style.display = 'block';
                if (modal) {
                    modal.style.display = "none";
                }
                return false;
            } else {
                if (callback && typeof callback === 'function') {
                    callback();
                }
                return true;
            }
        })
        .catch(error => {
            console.error("Erro ao verificar limite de alunos:", error);
            return false;
        });
}	
// Fechar Modal
function fecharModal(id) {
    modal = document.getElementById(id);
    modal.classList.remove("fade-in");
    setTimeout(() => {
        modal.style.display = "none";
    }, 200);
}

window.addEventListener("click", function(e){
    
});
// Fechar de outra forma
window.addEventListener("click", function(e){
    if(e.target === herancaAbrir){
        herancaAbrir.classList.remove("fade-in");
        setTimeout(() => {
            herancaAbrir.style.display = "none";
        }, 200);
    }
});

// Filtrar Alunos com Animação
function filtrarAlunos() {
    let input = document.getElementById('searchAluno').value.toLowerCase();
    let alunos = document.querySelectorAll('.aluno-card');

    alunos.forEach(aluno => {
        let nome = aluno.getAttribute('data-nome').toLowerCase();
        aluno.style.display = nome.includes(input) ? "block" : "none";
    });
}
function voltrarPag(){
    document.getElementById('Erro').style.display="none";
}

// Primeira correção: Melhorar a lógica para carregar turmas com base na classe e curso
document.addEventListener("DOMContentLoaded", function() {
    // Função para carregar turmas com base no curso e classe selecionados
    function carregarTurmas(cursoId, classeId, selectElement, alunoId = null) {
        if (!cursoId || !classeId) return;
        
        fetch(`../Config/buscar_turma.php?id_curso=${cursoId}&id_classe=${classeId}${alunoId ? '&aluno_id='+alunoId : ''}`)
            .then(response => response.json())
            .then(data => {
                selectElement.innerHTML = "<option value=''>-- Selecione a Turma --</option>";
                
                if (!data.turmas || data.turmas.length === 0) {
                    const option = document.createElement("option");
                    option.disabled = true;
                    option.textContent = "Nenhuma turma disponível para esta combinação";
                    selectElement.appendChild(option);
                    return;
                }

                data.turmas.forEach(tur => {
                    const option = document.createElement("option");
                    option.value = tur.id_turma;
                    
                    // Verifica se o aluno já está na turma (para edição)
                    const estaNaTurma = alunoId && tur.alunos_ids && tur.alunos_ids.includes(parseInt(alunoId));
                    const turmaCheia = tur.total_alunos >= tur.limite_aluno && !estaNaTurma;
                    
                    if (turmaCheia) {
                        option.disabled = true;
                        option.textContent = `${tur.nome} (${tur.total_alunos}/${tur.limite_aluno}) - CHEIA`;
                    } else {
                        option.textContent = `${tur.nome} (${tur.total_alunos}/${tur.limite_aluno})`;
                    }
                    
                    if (estaNaTurma) {
                        option.selected = true;
                    }
                    
                    selectElement.appendChild(option);
                });
            })
            .catch((erro) => {
                console.error('Erro ao buscar turmas:', erro);
                selectElement.innerHTML = "<option value=''>Erro ao carregar turmas</option>";
            });
    }
    
    // Para o formulário de adicionar aluno
    const cursoSelect = document.getElementById("curso_select");
    const classeSelect = document.getElementById("classe_select");
    const turmaSelect = document.getElementById("turma_select");
    
    if (cursoSelect && classeSelect && turmaSelect) {
        // Evento quando muda o curso
        cursoSelect.addEventListener("change", function() {
            if (classeSelect.value) {
                carregarTurmas(this.value, classeSelect.value, turmaSelect);
            }
        });
        
        // Evento quando muda a classe
        classeSelect.addEventListener("change", function() {
            if (cursoSelect.value) {
                carregarTurmas(cursoSelect.value, this.value, turmaSelect);
            }
        });
    }
    
    // Para o formulário de editar aluno
    const editCursoSelect = document.getElementById("edit_curso");
    const editClasseSelect = document.getElementById("edit_classe");
    const editTurmaSelect = document.getElementById("edit_turma");
    
    if (editCursoSelect && editClasseSelect && editTurmaSelect) {
        // Evento quando muda o curso na edição
        editCursoSelect.addEventListener("change", function() {
            if (editClasseSelect.value) {
                const alunoId = document.getElementById("edit_id").value;
                carregarTurmas(this.value, editClasseSelect.value, editTurmaSelect, alunoId);
            }
        });
        
        // Evento quando muda a classe na edição
        editClasseSelect.addEventListener("change", function() {
            if (editCursoSelect.value) {
                const alunoId = document.getElementById("edit_id").value;
                carregarTurmas(editCursoSelect.value, this.value, editTurmaSelect, alunoId);
            }
        });
    }
});
</script>
</div>
</body>
</html>