<?php
session_start();
require '../Config/conexaoBD.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}

// Verifica se o usuário está loga
if ($_SESSION['nivel_acesso'] === "secretario") {
    header("Location: inicio.php");
    $_SESSION['notification'] = "Não tens acesso a página de actualizações.";
    $_SESSION['estado'] = "erro";
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alunos - Gestão Escolar</title>
    <link rel="stylesheet" href="../Styles/Cursos.css">
    <link rel="icon" style="width: 100%; height:100%;" type="image/x-png" href="../arquivos/Logotipo/LOGO ICRA.jpg">
    <link rel="stylesheet" href="../Bibiliotecas/pace-1.2.4/themes/red/pace-theme-center-atom.css">
    <script src="../Bibiliotecas/pace-1.2.4/pace.min.js"></script>
    <link rel="stylesheet" href="../Bibiliotecas/Font-Awesome-6.x/css/all.min.css">
</head>
<body>
    
<?php
include 'Menu.php'; 
?>

<div class="container">
<div class="ContHora"><i class="fas fa-clock"></i><span style="font-size: 20px;" id="recebHora"></span></div>
        
        <div class="dashboard-header">
            <img src="../arquivos/Logotipo/LOGO ICRA.jpg" alt="Logo ICRA">
            <h1 style="margin-top: -5px;">📚 Gestão de Cursos</h1>
        </div> 


    <!-- Botão para Adicionar Novo Curso -->
    <button class="btn-adicionar" onclick="abrirModal('modalAdicionar')">
        <i class="fa-solid fa-user-plus"></i>Adicionar Curso
    </button>

    <div class="lista-alunos">
        <?php
        $sql = "SELECT * FROM cursos ORDER BY id_curso ASC";
        $result = $conn->query($sql);

        while ($curso = $result->fetch_assoc()) {
        ?>
            <div class="aluno-card" data-nome="<?= strtolower($curso['curso']) ?>">
                <div class="aluno-info">
                <h2><i class="fa-solid fa-user"></i> <?= $curso['curso'] ?> </h2>
                    <p><i class="fas fa-dollar-sign"></i> <strong>Valor de Proprina:</strong> <?= $curso['valor_proprina'] ?></p>
                </div>
                <div class="aluno-acoes">
                    <button class="btn-editar" 
                        onclick="abrirModalEditar(
                            '<?= $curso['id_curso']; ?>',
                            '<?= $curso['curso']; ?>',
                            '<?= $curso['valor_proprina']; ?>',
                        )">
                        <i class="fas fa-edit"></i> Editar
                    </button>
                    <button class="btn-excluir" onclick="abrirModalExcluir('<?= $curso['id_curso'] ?>')">
                        <i class="fa-solid fa-trash"></i> Excluir
                    </button>
                </div>
            </div>
        <?php } ?>
    </div>
    <!-- Modais -->
   
<!-- Modal Adicionar -->
<div id="modalAdicionar" class="modal">
    <div class="modal-content">
        <span class="close" onclick="fecharModal('modalAdicionar')"><i class="fa-solid fa-xmark"></i></span>
        <h2><i class="fa-solid fa-user-plus"></i> Adicionar Aluno</h2>
        <form id="formAdicionar" method="POST" action="../Config/add_curso.php" enctype="multipart/form-data">
            <input type="hidden" name="id" >
            <div class="form-div">
            <label>Nome do Curso:</label>
            <input type="text" name="curso" required>
            </div>
            <div class="form-div">
            <label>Valor de Proprina:</label>
            <input type="number" name="ValorProprina" required>
            </div>
            <button type="submit" class="btn-salvar" style="background-color: green;">
                <i class="fas fa-save"></i> Salvar Alterações
            </button>
        </form>
    </div>
</div>

<!-- Modal Editar -->

<!-- ✅ MODAL EDITAR ALUNO -->
<div id="modalEditar" class="modal">
    <div class="modal-content">
        <span class="close" onclick="fecharModal('modalEditar')"><i class="fa-solid fa-xmark"></i></span>
        <h2><i class="fas fa-edit"></i> Editar Aluno</h2>
        
        <form id="formEditar" action="../Config/editar_curso.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id_curso" id="edit_id">
            <div class="form-div">
            <label>Nome do Curso:</label>
            <input type="text" name="curso" id="edit_curso" required>
            </div>
            <div class="form-div">
            <label>Valor de Proprina:</label>
            <input type="number" name="ValorProprina" id="edit_valorProprina" required>
            </div>
            <button type="submit" class="btn-salvar" style="background-color: yellow;">
                <i class="fas fa-save"></i> Salvar Alterações
            </button>
        </form>
    </div>
</div>


<!-- Modal Excluir -->
<div id="modalExcluir" class="modal">
    <div class="modal-content">
        <span class="close" onclick="fecharModal('modalExcluir')"><i class="fa-solid fa-xmark"></i></span>
        <h2><i class="fa-solid fa-trash"></i> Excluir Curso</h2>
        <p>Tem certeza que deseja excluir este curso?</p>
        <p>Porque excluindo o curso também excluíras tudos os alunos relacionado a este curso</p>
        <form id="formExcluir" method="POST" action="../Config/excluir_curso.php">
            <input type="hidden" name="id" id="deleteId">
            <button type="submit" class="btn-salvar" style="background-color: red;"><i class="fa-solid fa-trash"></i> Sim, Excluir</button>
        </form>
    </div>
</div>



<script>
    let herancaAbrir;
    function abrirModal(id, cursoId) {
        herancaAbrir = id;
        let modal = document.getElementById(id);
        modal.style.display = "flex";
        modal.classList.add("fade-in");

}

function abrirModalExcluir(cursoId){
    herancaAbrir = 'modalExcluir';
    document.getElementById('deleteId').value = cursoId;
    abrirModal('modalExcluir');
}

function abrirModalEditar(id_curso, curso, valorProprina) {
    herancaAbrir = 'modalEditar';
    document.getElementById("edit_id").value = id_curso;
    document.getElementById("edit_curso").value = curso;
    document.getElementById("edit_valorProprina").value = valorProprina;
    abrirModal('modalEditar');
}
// Fechar Modal
function fecharModal(id) {
    let modal = document.getElementById(id);
    modal.classList.remove("fade-in");
    setTimeout(() => {
        modal.style.display = "none";
    }, 200);
}
</script>
 <script src='../Scritps/Menu.js'></script>
</div>
</body>
</html>