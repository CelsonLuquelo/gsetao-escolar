<?php
session_start();
require '../Config/conexaoBD.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}

// Busca os ano lectivo
$sql1 = "SELECT * FROM anolectivo WHERE id = 1";
$result1 = $conn->query($sql1);
$info1 = $result1->fetch_assoc();

$anoHoje = intval($info1['ano']);
$anoHojeM = $anoHoje+1;

// Buscar alunos e verificar se têm dívida
$sql = "SELECT a.*, 
        (SELECT COUNT(*) FROM pagamentos p WHERE p.id_aluno = a.id_aluno AND p.total = 0) as dividas
        FROM alunos a
       WHERE a.ano = $anoHoje OR a.ano = $anoHojeM";
$result = $conn->query($sql);

// Buscar meses
$sqlMeses = "SELECT * FROM meses ORDER BY data ASC";
$resultMeses = $conn->query($sqlMeses);
$meses = [];
while ($row = $resultMeses->fetch_assoc()) {
    $meses[] = $row;
}

$anoAtual = date("Y");
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagamento de Propina</title>
    <link rel="icon" style="width: 100%; height:100%;" type="image/x-png" href="../arquivos/Logotipo/LOGO ICRA.jpg">
    <link rel="stylesheet" href="../Bibiliotecas/pace-1.2.4/themes/red/pace-theme-center-atom.css">
    <script src="../Bibiliotecas/pace-1.2.4/pace.min.js"></script>
    <link rel="stylesheet" href="../Bibiliotecas/Font-Awesome-6.x/css/all.min.css"> <!-- Ícones FontAwesome -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #1c1c3c, #3b3b92);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            margin-top: 10px;
            width: 95%;
            max-width: 1200px;
            padding: 20px;
            border-radius: 10px;
        }
        
        .subContainer {
            margin-top: 50px;
        } 

        /* Header e Logo */
        .ContLogo {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .ContLogo img {
            height: 80px;
            width: 80px;
            border-radius: 50%;
            margin: 0 auto;
            display: block;
            border: 3px solid #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s;
        }
        
        .ContLogo img:hover {
            transform: scale(1.05);
        }
        
        .ContLogo h1 {
            color: #fff;
            font-size: 28px;
            margin-top: 15px;
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5);
        }

        /* Campo de pesquisa */
        .search-box {
            width: 100%;
            max-width: 500px;
            display: flex;
            align-items: center;
            background: #fff;
            padding: 12px 15px;
            border-radius: 12px;
            border: 1px solid #e0e0e0;
            margin: 0 auto 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .search-box:focus-within {
            box-shadow: 0 6px 12px rgba(0, 123, 255, 0.15);
            transform: translateY(-2px);
        }

        .search-box #pesquisa {
            width: 100%;
            border: none;
            outline: none;
            padding: 5px;
            font-size: 16px;
            color: #333;
        }

        .search-box i {
            color: #007bff;
            font-size: 18px;
            margin-right: 5px;
        }

        /* Container dos alunos */
        .alunos-container {
            display: flex;
            flex-direction: column;
            gap: 15px;
            max-width: 900px;
            margin: 0 auto;
        }

        /* Cartão do aluno */
        .aluno-card {
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #fff;
            padding: 15px 20px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: all 0.4s;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }

        .aluno-card::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(90deg, #007bff, #00c6ff);
            transform: scaleX(0);
            transform-origin: left;
            transition: transform 0.4s ease;
        }

        .aluno-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.15);
        }

        .aluno-card:hover::after {
            transform: scaleX(1);
        }

        /* Caso o aluno tenha dívida */
        .aluno-card.com-divida {
            border-left: 5px solid #ff3547;
            background: linear-gradient(to right, rgba(255, 53, 71, 0.1), rgba(255, 255, 255, 1) 15%);
        }

        /* Informações do aluno */
        .aluno-info {
            display: flex;
            align-items: center;
            gap: 15px;
            flex: 1;
        }
        
        .aluno-info img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #007bff;
            box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16);
            transition: all 0.3s;
        }
        
        .aluno-card:hover .aluno-info img {
            transform: scale(1.1);
        }

        .aluno-info h3 {
            font-size: 18px;
            margin-bottom: 8px;
            color: #333;
        }

        .aluno-details {
            display: flex;
            flex-wrap: wrap;
            gap: 8px 15px;
        }

        /* Status indicators */
        .status-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .span-status {
            font-size: 12px;
            font-weight: 500;
            padding: 4px 10px;
            border-radius: 20px;
            display: flex;
            align-items: center;
            gap: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .status-pago {
            background-color: #e6f7e9;
            color: #28a745;
            border: 1px solid #c3e6cb;
        }

        .status-pendente {
            background-color: #f8f9fa;
            color: #6c757d;
            border: 1px solid #e2e3e5;
        }

        .status-atraso {
            background-color: #ffebee;
            color: #dc3545;
            border: 1px solid #f5c6cb;
        }

        /* Ícone de seta */
        .icon {
            font-size: 22px;
            color: #007bff;
            transition: transform 0.3s;
        }
        
        .aluno-card:hover .icon {
            transform: translateX(5px);
        }

        /* Botão lista */
        .btn-lista {
            background: linear-gradient(135deg, #3b82f6, #1e40af);
            color: white;
            padding: 12px 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            max-width: 240px;
            margin: 0 auto 30px;
            border-radius: 10px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            transition: all 0.3s;
            font-weight: 600;
            box-shadow: 0 4px 10px rgba(59, 130, 246, 0.4);
        }

        .btn-lista:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(59, 130, 246, 0.5);
        }
        
        .btn-lista:active {
            transform: translateY(1px);
        }

        /* Mensagem de nenhum aluno encontrado */
        #infor {
            color: white;
            text-align: center;
            margin: 20px 0;
            font-size: 18px;
            padding: 15px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            backdrop-filter: blur(5px);
        }

        /* Responsividade */
        @media (max-width: 768px) {
            .container {
                width: 100%;
                padding: 15px;
            }
            
            .aluno-card {
                flex-direction: column;
                text-align: center;
                padding: 20px 15px;
            }
            
            .aluno-info {
                flex-direction: column;
                width: 100%;
            }
            
            .status-container {
                justify-content: center;
                margin-top: 10px;
            }
            
            .icon {
                margin-top: 15px;
                transform: rotate(90deg);
            }
            
            .aluno-card:hover .icon {
                transform: rotate(90deg) translateX(5px);
            }
            
            .search-box {
                max-width: 100%;
            }
        }
        
        @media (max-width: 480px) {
            .span-status {
                font-size: 11px;
                padding: 3px 8px;
            }
            
            .aluno-info h3 {
                font-size: 16px;
            }
            
            .ContLogo h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
<?php include "Menu.php"; ?>
<div class="container">
<div class="ContHora"><i class="fas fa-clock"></i><span style="font-size: 20px;" id="recebHora"></span></div>
        
        <div class="dashboard-header">
            <img src="../arquivos/Logotipo/LOGO ICRA.jpg" alt="Logo ICRA">
              <h1>Gestão de Pagamentos</h1>
        </div>
        
        
        <!-- Botão para ir à lista pagamentos -->
        <button class="btn-lista" onclick="window.location='ListaPagamento.php'">
            <i class="fas fa-list"></i> Lista de Pagamentos
        </button>
        
        <div class="search-box">
            <i class="fas fa-search"></i>
            <input type="text" id="pesquisa" placeholder="Pesquise pelo nome ou nº de matrícula" onkeyup="filtrarAlunos()">
        </div>

        <div class="alunos-container">
            <?php if ($result->num_rows > 0): ?> 
                <?php while ($aluno = $result->fetch_assoc()):  
                    $aluno_id = $aluno['id_aluno'];
                    $total_Pago = 0;
                    $total_Pendente = 0;
                    $total_Atraso = 0;
                    
                    foreach ($meses as $mes) {
                        $nomeMes = $mes['mes'];
                        $dataMes = $mes['data'];

                        // Verificar se o aluno pagou o mês atual
                        $sqlPagamento = "SELECT * FROM pagamentos WHERE id_aluno = $aluno_id AND mes = '$nomeMes' AND ano = '$anoAtual' AND status = 'pago'";
                        $resultPagamento = $conn->query($sqlPagamento);

                        if ($resultPagamento->num_rows > 0) {
                            $total_Pago += 1; // Verde (Pago)
                        } else {
                            $dataMesTime = strtotime($dataMes);
                            $dataAtualTime = strtotime(date("Y-m-d"));

                            if ($dataMesTime < $dataAtualTime) {
                                $total_Atraso += 1; // Vermelho (Atrasado)
                            } else {
                                $total_Pendente += 1; // Cinza (Pendente)
                            }
                        }
                    }
                ?>
                <div class="aluno-card <?= $aluno['dividas'] > 0 ? 'com-divida' : '' ?>" onclick="window.location='detalhes_aluno.php?id=<?= $aluno['id_aluno'] ?>'">
                    <div class="aluno-info">
                        <img src="../arquivos/fotos_dos_alunos/<?= $aluno['foto'] ?>" alt="Foto do Aluno">
                        <div>
                            <h3><?= $aluno['nome'] ?></h3>
                            <input type="hidden" value="<?= $aluno['matricula'] ?>">
                            <div class="status-container">
                                <span class="span-status status-pago">
                                    <i class="fas fa-check-circle"></i> Pagos: <?= $total_Pago ?>
                                </span> 
                                <span class="span-status status-pendente">
                                    <i class="fas fa-clock"></i> Pendentes: <?= $total_Pendente ?>
                                </span>
                                <span class="span-status status-atraso">
                                    <i class="fas fa-exclamation-circle"></i> Atraso: <?= $total_Atraso ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="icon">
                        <i class="fas fa-chevron-right"></i>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <h3 id="infor" style="display: block;">Nenhum pagamento efetuado</h3>
            <?php endif; ?>
            <h3 style="display: none;" id="infor">Nenhum aluno encontrado</h3>
        </div>
    </div>
</div>

<script src='../Scritps/Menu.js'></script>
<script>
function filtrarAlunos() {
    let input = document.getElementById("pesquisa").value.toUpperCase();
    let alunos = document.getElementsByClassName("aluno-card");
    let encontrado = false;

    for (let i = 0; i < alunos.length; i++) {
        let nome = alunos[i].getElementsByTagName("h3")[0].innerText;
        let matricula = alunos[i].getElementsByTagName("input")[0].value;
        
        if (nome.toUpperCase().includes(input) || matricula.toUpperCase().includes(input)) {
            alunos[i].style.display = "";
            encontrado = true;
        } else {
            alunos[i].style.display = "none";
        }
    }
    
    document.getElementById("infor").style.display = encontrado ? "none" : "block";
}

// Adicionar animação de entrada para os cartões
document.addEventListener('DOMContentLoaded', function() {
    const cards = document.querySelectorAll('.aluno-card');
    cards.forEach((card, index) => {
        setTimeout(() => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'all 0.5s ease';
            
            setTimeout(() => {
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, 50);
        }, index * 100);
    });
});
</script>

</body>
</html>