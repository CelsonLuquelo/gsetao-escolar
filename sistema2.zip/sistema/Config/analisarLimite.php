<?php
// Config/analisarLimite.php
session_start();
require 'conexaoBD.php';

header('Content-Type: application/json');

$id_turma = isset($_GET['id_turma']) ? intval($_GET['id_turma']) : 0;
$aluno_id = isset($_GET['aluno_id']) ? intval($_GET['aluno_id']) : null;

if ($id_turma <= 0) {
    echo json_encode(['erro' => 'ID da turma não fornecido', 'turma_cheia' => false]);
    exit;
}

try {
    // Busca o limite da turma
    $stmt_turma = $pdo->prepare("SELECT limite_aluno FROM turmas WHERE id_turma = ?");
    $stmt_turma->execute([$id_turma]);
    $turma = $stmt_turma->fetch(PDO::FETCH_ASSOC);

    if (!$turma) {
        echo json_encode(['erro' => 'Turma não encontrada', 'turma_cheia' => false]);
        exit;
    }

    // Conta alunos na turma
    $sql_count = "SELECT COUNT(*) as total FROM alunos WHERE id_turma = ?";
    $params = [$id_turma];
    
    // Se estamos editando um aluno, não contamos ele mesmo no total
    if ($aluno_id) {
        $sql_count .= " AND id_aluno != ?";
        $params[] = $aluno_id;
    }
    
    $stmt_count = $pdo->prepare($sql_count);
    $stmt_count->execute($params);
    $resultado = $stmt_count->fetch(PDO::FETCH_ASSOC);
    
    $total_alunos = $resultado['total'];
    $turma_cheia = $total_alunos >= $turma['limite_aluno'];

    echo json_encode([
        'limite' => $turma['limite_aluno'],
        'total_atual' => $total_alunos,
        'turma_cheia' => $turma_cheia
    ]);
} catch (PDOException $e) {
    echo json_encode(['erro' => 'Erro ao verificar limite: ' . $e->getMessage(), 'turma_cheia' => false]);
}
?>