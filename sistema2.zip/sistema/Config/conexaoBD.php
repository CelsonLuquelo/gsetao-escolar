<?php

// Configurações do banco de dados
$host = 'sql107.infinityfree.com';
$dbname = 'if0_39136604_gestao_escolar';
$username = 'if0_39136604';
$password = 'dadivada';

// Conexão com o banco
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}


    $conn = new mysqli($host, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Falha na conexão: " . $conn->connect_error);
    }
?>
