<?php
// Config/buscar_turma.php
session_start();
require 'conexaoBD.php';

header('Content-Type: application/json');

$id_curso = isset($_GET['id_curso']) ? intval($_GET['id_curso']) : 0;
$id_classe = isset($_GET['id_classe']) ? intval($_GET['id_classe']) : 0;
$aluno_id = isset($_GET['aluno_id']) ? intval($_GET['aluno_id']) : null;

if ($id_curso <= 0 || $id_classe <= 0) {
    echo json_encode(['erro' => 'Parâmetros inválidos', 'turmas' => []]);
    exit;
}

try {
    // Buscar todas as turmas disponíveis para o curso e classe
    $sql = "SELECT t.*, 
            (SELECT COUNT(*) FROM alunos a WHERE a.id_turma = t.id_turma) as total_alunos,
            (SELECT GROUP_CONCAT(a.id_aluno) FROM alunos a WHERE a.id_turma = t.id_turma) as alunos_ids
            FROM turmas t 
            WHERE t.id_curso = ? AND t.id_classe = ?";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id_curso, $id_classe]);
    $turmas = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Processa os IDs de alunos para converter em um array
    foreach ($turmas as &$turma) {
        if ($turma['alunos_ids']) {
            $turma['alunos_ids'] = array_map('intval', explode(',', $turma['alunos_ids']));
        } else {
            $turma['alunos_ids'] = [];
        }
    }

    echo json_encode(['turmas' => $turmas]);
} catch (PDOException $e) {
    echo json_encode(['erro' => 'Erro ao buscar turmas: ' . $e->getMessage(), 'turmas' => []]);
}
?>