<?php
session_start();
include 'conexaoBD.php';

if (isset($_POST['id'])) {
    $id = $_POST['id'];

    try{
     
        $sql = "DELETE FROM cursos WHERE id_curso = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([":id"=>$id]);

        $_SESSION['notification'] = "Curso excluido com sucesso.";
        $_SESSION['estado'] = "sucesso";
        header("Location: ../HtPags/Cursos.php");
        
    }catch(Exception $ex){
        $_SESSION['notification'] = "Erro ao excluir Curso.". $Exception;
        $_SESSION['estado'] = "erro";
        echo "Erro: " .$ex;
        header("Location: ../HtPags/Cursos.php");        
    } 

}
?>