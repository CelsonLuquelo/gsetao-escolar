<?php
session_start();
header('Content-Type: application/json');


require 'conexaoBD.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

  
    $dados = isset($_POST['dados']) ? json_decode($_POST["dados"], true) : [];
    $id_aluno = $_POST['id_aluno'];
    $id_mes = $_POST['id_mes'];

try {
    if (empty($dados)) {
        $_SESSION['notification'] = "Tabela de pagamento está vazia.";
        $_SESSION['estado'] = "erro";
        header('location: ../HtPags/detalhes_aluno.php');
        exit;
    }
    // Busca os dados atuais do sistema
    $sql = "SELECT ano FROM anolectivo WHERE id = 1";
    $result = $conn->prepare($sql);
    $result->execute();
    $Meses = $result->get_result();
    $anolectivoArray=$Meses->fetch_assoc();

    $anoActual = date("Y-m-d");
    $anolectivo = $anolectivoArray["ano"];
    
     // Insere os itens do carrinho
     $stmt = $conn->prepare("INSERT INTO pagamentos (id_aluno, mes, ano, valor, multa, desconto, total, status, id_mes)
                                VALUES (?, ?, ?, ?, ?, ?, ?, 'pago', ?)");
     foreach ($dados as $item) {
         $stmt->bind_param("isiiiiii", $id_aluno, $item['mesPagar'], $anoActual, $item['valorProprina'], $item['multa'], $item['desconto'], $item['total'], $id_mes);
         $stmt->execute();
         $id_pagamento = $stmt->insert_id;

         $stmtFactura = $conn->prepare("INSERT INTO facturas (id_aluno, id_pagamento, ano)
         VALUES (?, ?, $anolectivo)");
         $stmtFactura->bind_param("ii", $id_aluno, $id_pagamento);
         $stmtFactura->execute();

     }
     $dados_json = urlencode(json_encode($dados));
     $_SESSION['notification'] = "Aluno pago com sucesso.";
     $_SESSION['estado'] = "sucesso";
     header("location: ../HtPags/imprimir_factura.php?dados=$dados_json&id_aluno=$id_aluno");

} catch (Exception $e) {
    $_SESSION['notification'] = "Erro ao pagar proprina do aluno.". $e;
    $_SESSION['estado'] = "erro";
    header("location: ../HtPags/detalhes_aluno.php?id=$id_aluno");
    exit;
  
}
}else{
    echo 'Os dados nao foram enviados';
}
?>
