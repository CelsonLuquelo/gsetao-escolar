<?php
session_start();
include('conexaoBD.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_turma = $_POST['id_turma'];
    $sala = $_POST['sala'];
    $limite = $_POST['limite'];
    $turno = $_POST['turno'];
    $id_classe = $_POST['id_classe'];
    
    try {
        // Atualizar informações da turma
        $stmt = $pdo->prepare("UPDATE turmas SET sala = ?, limite_aluno = ?, turno = ?, id_classe = ? WHERE id_turma = ?");
        $stmt->execute([$sala, $limite, $turno, $id_classe, $id_turma]);
        
        $_SESSION['notification'] = "Turma atualizada com sucesso!";
        $_SESSION['estado'] = "sucesso";
    } catch (PDOException $e) {
        $_SESSION['notification'] = "Erro ao atualizar turma: " . $e->getMessage();
        $_SESSION['estado'] = "erro";
    }
    
    header("Location: ../Htpags/turmas.php");
    exit();
}
?>