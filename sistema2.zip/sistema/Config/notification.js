 //Exibir Mensagem
 document.addEventListener('DOMContentLoaded',function(){
    const mensagem = document.getElementById("notification");

    mensagem.style.top="35%";
    mensagem.style.opacity="1";
        setInterval(function(){
            mensagem.style.position="absolute";
            mensagem.style.top="-100px";
            mensagem.style.opacity="0";
    },10000);
    });