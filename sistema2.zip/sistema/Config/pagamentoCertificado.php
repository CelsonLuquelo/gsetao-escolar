<?php
session_start();
include 'conexaoBD.php';


  $id_aluno = $_GET['id_aluno'] ?? 0;

if ($_SERVER["REQUEST_METHOD"] == "GET") {
try{
    $modoPagamento = $_GET['modoPagamento'];
    $activaCertificado = $_GET['certificado'] ?? null;

    $stmt = $pdo->prepare("SELECT * FROM informacoes_basicas");
    $stmt->execute();
    $infor = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt2 = $pdo->prepare("SELECT id_certificado FROM outros_pagamentos WHERE id_aluno = $id_aluno");
    $stmt2->execute();
    $infor2 = $stmt2->fetch(PDO::FETCH_ASSOC);

    $Id_certificado = $infor2['id_certificado'];
    $valor_certificado = $infor['valor_certificado'];

    $stmt3 = $pdo->prepare("UPDATE certificado SET certificado.status = :estado, total_pago = :total WHERE id_certificado = :id");
    $stmt3->execute([':estado' => 'pago', ':total' => $valor_certificado, ':id' => $Id_certificado]);


        $_SESSION['notification'] = "Certificado paga com sucesso.";
        $_SESSION['estado'] = "sucesso";
          header("Location: ../HtPags/imprimir_recibo.php?modoPagamento=$modoPagamento&certificado=$activaCertificado&id_aluno=$id_aluno");
    }catch(Exception $ex){
        $_SESSION['notification'] = "Erro ao fazer o pagamento de certificado: ". $ex;
        $_SESSION['estado'] = "erro";
        header("Location: ../HtPags/detalhes_aluno.php?id=$id_aluno");
        exit();
    }
}
?>
