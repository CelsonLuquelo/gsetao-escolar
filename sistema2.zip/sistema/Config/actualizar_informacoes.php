
<?php
session_start();
include 'conexaoBD.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

try{
    $nif = trim($_POST['nif']);
    $iban = trim($_POST['iban']);
    $ano_lectivo = intval($_POST['ano_lectivo']);
    $telefone = trim($_POST['telefone']);
    $email = trim($_POST['email']);
    $valor_matricula = floatval($_POST['valor_matricula']);
    $valor_cartao = floatval($_POST['valor_cartao']);
    $valor_uniforme = floatval($_POST['valor_uniforme']);
    $multa_percentual = floatval($_POST['multa_percentual']);
    $valor_estagio = floatval($_POST['valor_estagio']);
    $valor_declaracao = floatval($_POST['valor_declaracao']);
    $valor_certificado = floatval($_POST['valor_certificado']);

    // Atualiza informações básicas
    $sql = "UPDATE informacoes_basicas SET NIF = ?, IBAN = ?, contactos = ?, email = ?, multa_percentual = ?, valor_Matricula = ?, valor_cartao = ?, valor_uniforme = ?, valor_estagio = ?, valor_declaracao = ?, valor_certificado = ? WHERE id = 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssdiiiiii", $nif, $iban, $telefone, $email, $multa_percentual, $valor_matricula, $valor_cartao, $valor_uniforme, $valor_estagio, $valor_declaracao, $valor_certificado);
    $stmt->execute();

    // Atualiza ano lectivo
    $sql1 = "UPDATE anolectivo SET ano = ? WHERE id = 1";
    $stmt1 = $conn->prepare($sql1);
    $stmt1->bind_param("i", $ano_lectivo);
    $stmt1->execute();

    // Atualiza os valores percentuais das classes
    foreach ($_POST['percentual'] as $id => $percentual) {
        $sql = "UPDATE classe SET valor_percentual = ? WHERE id_classe = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $percentual, $id);
        $stmt->execute();
    }

    // Atualiza os valores percentuais das classes
    foreach ($_POST['valor_proprina'] as $id_curso => $curso) {
        $sql = "UPDATE cursos SET valor_proprina = ? WHERE id_curso = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $curso, $id_curso);
        $stmt->execute();
    }

    // Atualiza os meses do novo ano letivo
    $meses = [
        'Janeiro' => '01-01',
        'Fevereiro' => '02-01',
        'Março' => '03-01',
        'Abril' => '04-01',
        'Maio' => '05-01',
        'Junho' => '06-01',
        'Julho' => '07-01',
        'Agosto' => '08-01',
        'Setembro' => '09-01',
        'Outubro' => '10-01',
        'Novembro' => '11-01',
        'Dezembro' => '12-01'
    ];

    foreach ($meses as $nome => $data) {
        $sqlM = "SELECT id FROM meses WHERE mes = ?";
        $stmtM = $conn->prepare($sqlM);
        $stmtM->bind_param("s", $nome);
        $stmtM->execute();
        $stmtM->bind_result($id_mes);
        $stmtM->fetch();
        $stmtM->close();
        if($id_mes >= 9){
            $nova_data = $ano_lectivo . '-' . $data;
            $sql = "UPDATE meses SET data = ? WHERE mes = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $nova_data, $nome);
            $stmt->execute();
        }else{
            $nova_data = intval($ano_lectivo + 1) . '-' . $data;
            $sql = "UPDATE meses SET data = ? WHERE mes = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $nova_data, $nome);
            $stmt->execute();
        }
    }

    $_SESSION['notification']="sucesso ao actualizar informações";
    $_SESSION['estado'] = "sucesso";
    header("Location: ../HtPags/actualizar_informacoes.php");
    exit();

}catch(Exception $ex){
    $_SESSION['notification']="Erro a actualizar as informações";
    $_SESSION['estado'] = "erro";
    header("Location: ../HtPags/actualizar_informacoes.php");
    exit();
}
} else {
    echo "<script>alert('Acesso inválido!'); window.location.href='configuracao.php';</script>";
}
?>