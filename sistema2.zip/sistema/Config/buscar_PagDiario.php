<?php
include('conexaoBD.php');

$query = "SELECT DATE(data_created) AS dia, SUM(total) AS total FROM pagamentos 
    WHERE DATE(data_created) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) GROUP BY DATE(data_created) ORDER BY dia ASC 
";
$result = $conn->query($query);

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode($data);
?>