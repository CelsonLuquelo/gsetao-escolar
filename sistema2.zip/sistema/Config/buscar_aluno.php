<?php
session_start();
require '../Config/conexaoBD.php';

$id_aluno = $_GET['id_aluno'];

if(isset($id_aluno)){
    $query = "SELECT * FROM alunos WHERE id_aluno = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id_aluno);
    $stmt->execute();

    $result = $stmt->get_result();
    $alunos = $result->fetch_assoc();
}


$query2 = "SELECT id_classe, nome FROM classe";
$resultF = $conn->query($query2);
$classes = [];

$query3 = "SELECT id_curso, curso FROM cursos";
$resultC = $conn->query($query3);
$cursos = [];



while($row1 = $resultF->fetch_assoc()){
    $classes[] = $row1;
}
while($row2 = $resultC->fetch_assoc()){
    $cursos[] = $row2;
}


$response =[
    'aluno' => $alunos,
    'classes' => $classes,
    'cursos' => $cursos
];

echo json_encode($response);
?>