<?php
session_start();
include 'conexaoBD.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_curso = $_POST['id_curso'];
    $curso = $_POST['curso'];
    $valorProprina = $_POST['ValorProprina'];

        $query = "UPDATE cursos SET curso = '$curso', valor_proprina = $valorProprina WHERE id_curso = $id_curso";
    if ($conn->query($query) === TRUE) {

        $_SESSION['notification'] = "Curso editado com sucesso.";
        $_SESSION['estado'] = "sucesso";
          header("Location: ../HtPags/Cursos.php");
    } else {
        $_SESSION['notification'] = "Erro ao editar curso.";
        $_SESSION['estado'] = "erro";
        header("Location: ../HtPags/Cursos.php");
        exit();
    }
}
?>
