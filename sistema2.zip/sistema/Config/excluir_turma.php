<?php
session_start();
include 'conexaoBD.php';

if (isset($_POST['id'])) {
    $id = $_POST['id'] ?? 0;

    try{
     
        $sql = "DELETE FROM turmas WHERE id_turma = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([":id"=>$id]);
        $_SESSION['notification'] = "Turma excluido com sucesso.";
        $_SESSION['estado'] = "sucesso";
        header("Location: ../HtPags/Turmas.php");
        
    }catch(Exception $ex){
        $_SESSION['notification'] = "Erro ao excluir turma.". $ex;
        $_SESSION['estado'] = "erro";
        header("Location: ../HtPags/Turmas.php");
        echo "Erro: " .$ex;
    
    } 

}
?>