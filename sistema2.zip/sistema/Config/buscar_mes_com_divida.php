<?php
require '../Config/conexaoBD.php';

session_start();

$id = $_GET['id'] ?? '';

$sql = "SELECT m.id FROM meses m
JOIN pagamentos p ON p.id_venda = m.id_venda
WHERE p.status = 'pago' AND CURDATE() >= data";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();
$meses = $result->fetch_all(MYSQLI_ASSOC);

echo json_encode($meses);

?>