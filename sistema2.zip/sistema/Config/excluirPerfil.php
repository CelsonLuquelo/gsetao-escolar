<?php

session_start();
require 'conexaoBD.php';


if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try{
        if (isset($_GET['id']) && $_GET['id'] !== '') {
            
            $id_usuario = $_GET['id'];
            $stmt = $pdo->prepare("DELETE FROM usuarios WHERE id_usuario = :id");
            $stmt->execute([':id' => $id_usuario]);
            $_SESSION['notification'] = "Usuário deletado com sucesso!, $nome";
            $_SESSION['estado'] = "sucesso";
            header("location: ../Htpags/login.php");
            exit();
        }else{
            $_SESSION['notification'] = "Erro ao deletar perfil do $nome";
            $_SESSION['estado'] = "erro";
            header("location: ../Htpags/logout.php");
            exit();
        }
    }
    catch(Exception $ex){
        $_SESSION['notification'] = "Erro ao deletar perfil do $ex";
        $_SESSION['estado'] = "erro";
        header("location: ../Htpags/login.php");
        exit();
    }
}


?>