<?php
session_start();
include 'conexaoBD.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_curso = intval($_POST['curso_id']);
    $turno = $_POST['turno'];
    $sala = $_POST['sala'];
	$id_classe = $_POST['id_classe'];
    $limite_aluno = $_POST['limite'];

try{   
    // Converter turno em código
    $codigo_turno = '';
    if ($turno === "Manhã") $codigo_turno = 'M';
    elseif ($turno === "Tarde") $codigo_turno = 'T';
    elseif ($turno === "Noite") $codigo_turno = 'N';
    else die("Turno inválido.");

    // Buscar todas turmas do curso e turno
    $stmt = $conn->prepare("SELECT nome FROM turmas WHERE id_classe = ? AND id_curso = ? AND nome LIKE ? ORDER BY nome DESC");
    $like = "%$codigo_turno";
    $stmt->bind_param("iis", $id_classe, $id_curso, $like);
    $stmt->execute();
    $result = $stmt->get_result();

      // Buscar todas turmas do curso e turno
    $stmt2 = $conn->prepare("SELECT turno, sala, id_curso, id_classe FROM turmas WHERE id_curso = ? AND id_classe = ?");
    $stmt2->bind_param("ii", $id_curso, $id_classe);
    $stmt2->execute();
    $result2 = $stmt2->get_result();


    // Verificar qual foi a última letra usada
    $ultima_letra = 'A'; // padrão se não existir turma
    if ($result->num_rows > 0) {
        $nomes = [];
        while ($row = $result->fetch_assoc()) {
            $nome = $row['nome'];
            if (substr($nome, -1) === $codigo_turno) {
                $letra = substr($nome, 0, 1);
                $nomes[] = $letra;
            }
        }

        // Obter próxima letra disponível do alfabeto
        $alfabeto = range('A', 'Z');
        foreach ($alfabeto as $letra) {
            if (!in_array($letra, $nomes)) {
                $ultima_letra = $letra;
                break;
            }
        }
    }

    $nome_turma = $ultima_letra . $codigo_turno;

    // Inserir nova turma
    $stmt = $conn->prepare("INSERT INTO turmas (nome, sala, turno, limite_aluno, id_curso, id_classe) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sisiii", $nome_turma, $sala, $turno, $limite_aluno, $id_curso, $id_classe);
    $stmt->execute();
    $stmt->close();
 
    $_SESSION['notification'] = "Turma cadastrada com sucesso.";
    $_SESSION['estado'] = "sucesso";
    header("Location: ../HtPags/Turmas.php");

    
}catch(Exception $ex){
        $_SESSION['notification'] = "Erro ao cadastar turma.". $ex;
        $_SESSION['estado'] = "erro";
        header("Location: ../HtPags/Turmas.php");
        exit();
    }
 
}
?>
