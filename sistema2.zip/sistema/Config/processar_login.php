
<?php
session_start();
require 'conexaoBD.php';
 
//Reiniciar a sessao
$_SESSION['id_usuario'] = null;
$_SESSION['id_cliente'] = null;
$_SESSION['nivel_acesso'] = "";
$_SESSION['nome'] = "";
$_SESSION['emailCliente'] = "";
$_SESSION['senhaCliente'] = "";

$_SESSION['nivel_acesso'] = "";
$_SESSION['nome'] = "";
$_SESSION['email'] = "";
$_SESSION['senha'] = "";

// Processa o formulário de login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';


    $stmtUsuarios = $conn->prepare("SELECT * FROM usuarios WHERE email = ? OR nome = ? LIMIT 1");
    $stmtUsuarios->bind_param("ss", $email, $email);
    $stmtUsuarios->execute();
    $resulUsuarios = $stmtUsuarios->get_result();

    $user = $resulUsuarios->fetch_assoc();

if($resulUsuarios->num_rows===1){
    $nome=$user['nome'];
    if(password_verify($senha, $user['senha'])) {
        $_SESSION['id_usuario'] = $user['id_usuario'];
        $_SESSION['nivel_acesso'] = $user['nivel_acesso'];
        $_SESSION['nome'] = $user['nome'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['senha'] = $user['senha'];

        $_SESSION['notification']="Entrando no sistema como o $nome";
        $_SESSION['estado'] = "sucesso";
        $_SESSION['sucesso'] = "sim";
        header("Location: ../HtPags/inicio.php");
        exit();
    }else{
        $_SESSION['notification']="Senha incorrecta ao entrar como $nome";
        $_SESSION['estado'] = "erro";
        $_SESSION['sucesso'] = "nao";
        header("Location: ../HtPags/login.php");
        exit();
    }
  }
  else{
    $_SESSION['notification']="Usuario não encontrado";
    $_SESSION['estado'] = "erro";
    header("Location: ../HtPags/login.php");
    exit();
  }
  $stmtCliente->close();
  $stmtUsuarios->close();
}
?>