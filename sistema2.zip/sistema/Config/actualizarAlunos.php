<?php
session_start();
require 'conexaoBD.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}
 try{
    // Busca os ano lectivo
    $sql1 = "SELECT * FROM anolectivo WHERE id = 1";
    $result1 = $conn->query($sql1);
    $info1 = $result1->fetch_assoc();

    $anoHoje = intval($info1['ano']);
    $anoHojeM = $anoHoje+1;


    // 
    $stmt = $conn->query("UPDATE alunos SET ano = $anoHoje   WHERE ano <> $anoHoje OR ano <> $anoHojeM");
    $total = $stmt->num_rows;

    $_SESSION['notification'] = "Foram actualizados $total alunos com sucesso.";
    header("Location: ../HtPags/Alunos.php");
    exit();
    
 }catch(Exception $ex){
    $_SESSION['notification'] = "Erro ao cadastar curso.";
    header("Location: ../HtPags/Alunos.php");
    exit();
 }


?>








function EditarAluno(id_aluno) {
    fetch(`../Config/buscar_aluno.php?id_aluno=${id_aluno}`)
        .then(Response => Response.json())
        .then(data => {
            const turma = document.getElementById('edit_turma');
            document.getElementById('edit_id').value = id_aluno;
            nome.value = data.aluno.nome;
            morada.value = data.aluno.morada;
            data_nasc.value = data.aluno.data_nascimento;
            NEncar.value = data.aluno.numero_encarregado;
            BI.value = data.aluno.BI;
            turma.innerHTML = '';
            
            fetch(`../Config/buscar_turma.php?id=${data.aluno.id_curso}`)
                .then(response => response.json())
                .then(data2 => {
                    turma.innerHTML = "<option value='' disabled>-- Selecione a Turma --</option>";
                    data2.turmas.forEach(tur => {
                        const option = document.createElement("option");
                        option.value = tur.id_turma;
                        const estaNaTurma = tur.id_turma == data.aluno.id_turma;
                        // Só desabilita a opção se a turma estiver cheia E o aluno não estiver nela
                        const disabled = (tur.total_alunos >= tur.limite_aluno && !estaNaTurma);
                        
                        if (disabled) {
                            option.disabled = true;
                            option.textContent = `${tur.nome} (${tur.total_alunos}/${tur.limite_aluno}) - CHEIA`;
                        } else {
                            option.textContent = `${tur.nome} (${tur.total_alunos}/${tur.limite_aluno})`;
                        }
                        
                        if (estaNaTurma) {
                            option.selected = true;
                        }
                        
                        turma.appendChild(option);
                    });
                });
            
            document.getElementById('edit_curso').innerHTML = "";
            document.getElementById('edit_classe').innerHTML = "";
            
            data.classes.forEach(classe => {
                const option = document.createElement("option");
                option.value = classe.id_classe;
                option.textContent = classe.nome;
                if (classe.id_classe == data.aluno.id_classe) {
                    option.selected = true;
                }
                id_classe.appendChild(option);
            });
            
            data.cursos.forEach(curso => {
                const option1 = document.createElement("option");
                option1.value = curso.id_curso;
                option1.textContent = curso.curso;
                if (curso.id_curso == data.aluno.id_curso) {
                    option1.selected = true;
                }
                id_curso.appendChild(option1);
            });
        })
        .catch((erro) => {
            console.log('Erro buscar dados no formulario', erro);
        });
        
    herancaAbrir = document.getElementById('modalEditar');
    document.getElementById('modalEditar').style.display = "flex";
}

// Vamos melhorar a função que verifica turmas disponíveis quando muda o curso
document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("edit_curso").addEventListener("change", function() {
        let id_curso = this.value;
        const turma_select = document.getElementById("edit_turma");
        const aluno_id = document.getElementById('edit_id').value;

        fetch(`../Config/buscar_turma.php?id=${id_curso}&aluno_id=${aluno_id}`)
            .then(response => response.json())
            .then(data => {
                turma_select.innerHTML = "<option value=''>-- Selecione a Turma --</option>";

                data.turmas.forEach(tur => {
                    const option = document.createElement("option");
                    option.value = tur.id_turma;
                    
                    // Verifica se a turma está cheia (aluno atual não conta)
                    const estaNaTurma = aluno_id && tur.alunos_ids && tur.alunos_ids.includes(parseInt(aluno_id));
                    const turmaCheia = tur.total_alunos >= tur.limite_aluno && !estaNaTurma;
                    
                    if (turmaCheia) {
                        option.disabled = true;
                        option.textContent = `${tur.nome} (${tur.total_alunos}/${tur.limite_aluno}) - CHEIA`;
                    } else {
                        option.textContent = `${tur.nome} (${tur.total_alunos}/${tur.limite_aluno})`;
                    }
                    
                    turma_select.appendChild(option);
                });
            })
            .catch((erro) => {
                console.log('Erro buscar dados para o formulário', erro);
            });
    });

    document.getElementById("curso_select").addEventListener("change", function() {
        let id_curso = this.value;
        const turma_select = document.getElementById("turma_select");

        fetch(`../Config/buscar_turma.php?id=${id_curso}`)
            .then(response => response.json())
            .then(data => {
                turma_select.innerHTML = "<option value=''>-- Selecione a Turma --</option>";

                data.turmas.forEach(tur => {
                    const option = document.createElement("option");
                    option.value = tur.id_turma;
                    
                    // Desabilita opções de turmas cheias para novas matrículas
                    if (tur.total_alunos >= tur.limite_aluno) {
                        option.disabled = true;
                        option.textContent = `${tur.nome} (${tur.total_alunos}/${tur.limite_aluno}) - CHEIA`;
                    } else {
                        option.textContent = `${tur.nome} (${tur.total_alunos}/${tur.limite_aluno})`;
                    }
                    
                    turma_select.appendChild(option);
                });
            })
            .catch((erro) => {
                console.log('Erro buscar dados para o formulário', erro);
            });
    });
    
    // Adicionar evento para formulário de edição
    const formEditar = document.getElementById("formEditar");
    if (formEditar) {
        formEditar.addEventListener("submit", function(e) {
            e.preventDefault();
            const turma_id = document.getElementById('edit_turma').value;
            const aluno_atual_id = document.getElementById('edit_id').value;
            
            // Verificar se o aluno já está nesta turma
            fetch(`../Config/verificar_aluno_turma.php?aluno_id=${aluno_atual_id}&turma_id=${turma_id}`)
                .then(response => response.json())
                .then(data => {
                    if (data.mesma_turma) {
                        // Se é a mesma turma, pode continuar
                        formEditar.submit();
                    } else {
                        // Se é uma turma diferente, verificar limite
                        VerificarLimite(turma_id, function() {
                            formEditar.submit();
                        });
                    }
                });
        });
    }
});












<?php
session_start();
include 'conexaoBD.php';

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $id_curso = $_GET['id'];
    $aluno_id = isset($_GET['aluno_id']) ? $_GET['aluno_id'] : null;
    
    // Busca turmas do curso
    $stmt = $pdo->prepare("SELECT t.id_turma, t.nome, t.limite_aluno FROM turmas t WHERE t.id_curso = ?");
    $stmt->execute([$id_curso]);
    $turmas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Para cada turma, conta o número de alunos
    foreach ($turmas as &$turma) {
        $stmt_count = $pdo->prepare("SELECT COUNT(*) as total, GROUP_CONCAT(id_aluno) as alunos_ids FROM alunos WHERE id_turma = ?");
        $stmt_count->execute([$turma['id_turma']]);
        $result = $stmt_count->fetch(PDO::FETCH_ASSOC);
        
        $turma['total_alunos'] = $result['total'];
        
        // Adiciona lista de IDs de alunos, se houver
        if ($result['alunos_ids']) {
            $turma['alunos_ids'] = explode(',', $result['alunos_ids']);
        } else {
            $turma['alunos_ids'] = [];
        }
    }
    
    echo json_encode(['turmas' => $turmas]);
    exit();
}
?>