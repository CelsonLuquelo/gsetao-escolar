<?php
session_start();
include 'conexaoBD.php';


  $id_aluno = $_GET['id_aluno'] ?? 0;

if ($_SERVER["REQUEST_METHOD"] == "GET") {

try{
    $modoPagamento = $_GET['modoPagamento'];
    $activaDeclaracao = $_GET['declaracao'] ?? null;

    $stmt = $pdo->prepare("SELECT * FROM informacoes_basicas");
    $stmt->execute();
    $infor = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt2 = $pdo->prepare("SELECT id_declaracao FROM outros_pagamentos WHERE id_aluno = $id_aluno");
    $stmt2->execute();
    $infor2 = $stmt2->fetch(PDO::FETCH_ASSOC);

    $Id_declaracao = $infor2['id_declaracao'];
    $valor_declaracao = $infor['valor_declaracao'];

    $stmt3 = $pdo->prepare("UPDATE declaracao SET declaracao.status = :estado, total_pago = :total WHERE id_declaracao = :id");
    $stmt3->execute([':estado' => 'pago', ':total' => $valor_declaracao, ':id' => $Id_declaracao]);


        $_SESSION['notification'] = "Declaração paga com sucesso.";
        $_SESSION['estado'] = "sucesso";
          header("Location: ../HtPags/imprimir_recibo.php?modoPagamento=$modoPagamento&declaracao=$activaDeclaracao&id_aluno=$id_aluno");
    }catch(Exception $ex){
        $_SESSION['notification'] = "Erro ao fazer o pagamento de declaração: ". $ex;
        $_SESSION['estado'] = "erro";
        header("Location: ../HtPags/detalhes_aluno.php?id=$id_aluno");
        exit();
    }
}
?>
