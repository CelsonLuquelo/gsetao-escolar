<?php
session_start();
require 'conexaoBD.php';


// Processa formulário de edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';
    $nivel_acesso = $_POST['nivel_acesso'] ?? 'administrador';
    $senha = password_hash($_POST['senha'], PASSWORD_BCRYPT);

    if (isset($_POST['id_usuario']) && $_POST['id_usuario'] !== '') {
        // Atualizar usuário existente
        $id_usuario = $_POST['id_usuario'];
        $stmt = $pdo->prepare("UPDATE usuarios SET nome = :nome, email = :email, senha = :senha, nivel_acesso = :nivel_acesso WHERE id_usuario = :id");
        $stmt->execute([':nome' => $nome, ':email' => $email, ':senha' => $senha, ':nivel_acesso' => $nivel_acesso, ':id' => $id_usuario]);
        $_SESSION['notification'] = "Usuário atualizado com sucesso!";
        $_SESSION['estado'] = "sucesso";
    }else{
        $_SESSION['notification'] = "Erro a Editar funcionário";
        $_SESSION['estado'] = "erro";
    }
    header("Location: ../HtPags/gerenciarUsuario.php");
    exit();
}


?>