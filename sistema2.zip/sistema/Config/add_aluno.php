<?php
session_start();
include 'conexaoBD.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $Bi = $_POST['BI'];
    $morada = $_POST['morada'];
    $numero_encarregado = $_POST['numero_encarregado'];
    $id_turma = $_POST['id_turma'];
    $data_nascimento = $_POST['data_nascimento'];
    $id_classe = $_POST['id_classe'];
    $id_curso = $_POST['id_curso'];
    $modoPagamento = $_POST['modoPagamento'];
    $tipoEstagio = $_POST['tipoEstagio'];
    $valorEstagio = $_POST['valorEstagio'] ?? 0;

try{


    // Busca o limite da turma
    $stmt_limite = $pdo->prepare("SELECT limite_aluno FROM turmas WHERE id_turma = ?");
    $stmt_limite->execute([$id_turma]);
    $dados_turma = $stmt_limite->fetch(PDO::FETCH_ASSOC);

    // Conta quantos alunos estão na turma
    $stmt_count = $pdo->prepare("SELECT COUNT(*) AS total FROM alunos WHERE id_turma = ?");
    $stmt_count->execute([$id_turma]); // anoHoje = ano atual
    $total_alunos = $stmt_count->fetch(PDO::FETCH_ASSOC)['total'];

    // Verifica se ultrapassou o limite
    if ($total_alunos >= $dados_turma['limite_aluno']) {
        // Redireciona de volta com mensagem de erro
        $_SESSION['notification'] = "Limite de alunos atingido para esta turma.";
        $_SESSION['sucesso'] = "erro";
        header("Location: ../HtPags/Alunos.php");
        exit();
    }

    // Caso contrário, continue com o cadastro...

    $dataActual = date('Y-m-d'); 
    $idade = intval($dataActual) - intval($data_nascimento);
    $matricula = 00;
    $foto = "default.jpg"; 
    if (!empty($_FILES["foto"]["name"])) {
        $foto = time() . "_" . $_FILES["foto"]["name"];
        copy($_FILES["foto"]["tmp_name"], "../arquivos/fotos_dos_alunos/" . $foto);
    }

     // Busca os dados atuais do sistema
     $sql = "SELECT ano FROM anolectivo WHERE id = 1";
     $result = $conn->prepare($sql);
     $result->execute();
     $dados = $result->get_result();
     $anolectivoArray=$dados->fetch_assoc();

     $anolectivo = $anolectivoArray['ano'];

    $query = "INSERT INTO alunos (id_curso, id_classe, ano, nome, idade, morada, numero_encarregado, id_turma, foto, data_nascimento, BI)
              VALUES (?, ?, $anolectivo, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmtAluno = $conn->prepare($query);
    $stmtAluno->bind_param("iisisiisss", $id_curso, $id_classe, $nome, $idade, $morada, $numero_encarregado, $id_turma, $foto, $data_nascimento, $Bi);

    $stmtAluno->execute();
    $Id_aluno = $stmtAluno->insert_id;
    
    $matriculaAl = $Id_aluno;
    $stmtPro = $conn->prepare("UPDATE alunos set matricula = ? WHERE id_aluno = ?");
    $stmtPro->bind_param("si", $matriculaAl, $Id_aluno);
    $stmtPro->execute();
 //Adiconar em outros pagamentos

    $stmtCer = $conn->prepare("INSERT INTO certificado (status) VALUES ('pendente')");
    $stmtCer->execute();
    $Id_certificado = $stmtCer->insert_id;

     $stmtEst = $conn->prepare("INSERT INTO estagio (status) VALUES ('pendente')");
    $stmtEst->execute();
    $Id_estagio = $stmtEst->insert_id;
     
    $stmtDec = $conn->prepare("INSERT INTO declaracao (status) VALUES ('pendente')");
    $stmtDec->execute();
    $Id_declaracao = $stmtDec->insert_id;

   $stmtOU =$conn->prepare("INSERT INTO outros_pagamentos (id_certificado, id_declaracao,id_estagio, id_aluno) VALUES ($Id_certificado, $Id_declaracao, $Id_estagio, $Id_aluno)");
    $stmtOU->execute();


    if(strlen($tipoEstagio)){
        $stmt = $pdo->prepare("SELECT * FROM informacoes_basicas");
        $stmt->execute();
        $infor = $stmt->fetch(PDO::FETCH_ASSOC);
        $valor_estagio = $infor['valor_estagio'] ?? 0;

        $stmtEst2 = $conn->prepare("UPDATE estagio SET status = 'pago', tipo = '$tipoEstagio', total_pago = $valor_estagio WHERE id_estagio = $Id_estagio");
        $stmtEst2->execute();
         header("location: ../HtPags/imprimir_recibo.php?id_aluno=$Id_aluno&modoPagamento=$modoPagamento&valor_estagio=$valorEstagio&tipoEstagio=$tipoEstagio");
        $_SESSION['notification'] = "Aluno cadastrado com sucesso.";
        $_SESSION['estado'] = "sucesso";

       exit();
    }else{
    header("location: ../HtPags/imprimir_recibo.php?id_aluno=$Id_aluno&modoPagamento=$modoPagamento&tipoEstagio=$tipoEstagio");
    $_SESSION['notification'] = "Aluno cadastrado com sucesso.";
    $_SESSION['estado'] = "sucesso";
    exit();
    }
}catch(Exception $ex){
        $_SESSION['notification'] = "Erro ao cadastar aluno." . $ex;
       header("location: ../HtPags/Alunos.php");
        $_SESSION['estado'] = "erro";
       echo "Erro ao cadastar aluno." . $ex;
        exit();
    }
}
?>