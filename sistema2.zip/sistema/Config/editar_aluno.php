<?php
session_start();
include 'conexaoBD.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $id = $_POST['id_aluno'];
    $nome = $_POST['nome'];
    $Bi = $_POST['BI'];
    $morada = $_POST['morada'];
    $numero_encarregado = $_POST['numero_encarregado'];
    $id_turma = $_POST['id_turma'];
    $data_nascimento = $_POST['data_nascimento'];
    $id_classe = $_POST['id_classe'];
    $id_curso = $_POST['id_curso'];


    $dataActual = date('Y-m-d'); 
    $idade = intval($dataActual) - intval($data_nascimento);
try{   
    // Verificar se uma nova foto foi enviada
    if (!empty($_FILES["foto"]["name"])) {
        $foto = time() . "_" . $_FILES["foto"]["name"];
        move_uploaded_file($_FILES["foto"]["tmp_name"], "../arquivos/fotos_dos_alunos/" . $foto);
        $query = "UPDATE alunos SET id_curso = $id_curso, id_classe = $id_classe, nome='$nome', idade=$idade, morada='$morada', numero_encarregado=$numero_encarregado, id_turma='$id_turma', foto='$foto', BI ='$Bi', data_nascimento='$data_nascimento' WHERE id_aluno=$id";
    } else {
        $query = "UPDATE alunos SET id_curso = $id_curso, id_classe = $id_classe, nome='$nome', idade=$idade, morada='$morada', numero_encarregado=$numero_encarregado, id_turma='$id_turma', BI ='$Bi', data_nascimento='$data_nascimento' WHERE id_aluno=$id";
    }

    if ($conn->query($query) === TRUE) {
        $_SESSION['notification'] = "Aluno editado com sucesso.";
        $_SESSION['estado'] = "sucesso";
        header("Location: ../HtPags/Alunos.php");        
          
    } else {
        $_SESSION['notification'] = "Erro ao editar aluno.";
        $_SESSION['estado'] = "erro";
        header("Location: ../HtPags/Alunos.php");
        exit();
    }
}catch(Exception $ex){
    $_SESSION['notification'] = "Erro ao editar aluno." . $ex;
    $_SESSION['estado'] = "erro";
   echo "Erro ao editar aluno." . $ex;
   header("Location: ../HtPags/Alunos.php");
    exit();
}
}
?>
