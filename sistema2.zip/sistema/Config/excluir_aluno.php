<?php
session_start();
include 'conexaoBD.php';

if (isset($_POST['id'])) {
    $id = $_POST['id'] ?? 0;

    try{
     
        $sql = "DELETE FROM alunos WHERE id_aluno = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([":id"=>$id]);
        $_SESSION['notification'] = "Aluno excluido com sucesso.";
        $_SESSION['estado'] = "sucesso";
        header("Location: ../HtPags/Alunos.php");
        
    }catch(Exception $ex){
        $_SESSION['notification'] = "Erro ao excluir aluno.". $ex;
        $_SESSION['estado'] = "erro";
        echo "Erro: " .$ex;
        header("Location: ../HtPags/Alunos.php");
    
    } 

}
?>