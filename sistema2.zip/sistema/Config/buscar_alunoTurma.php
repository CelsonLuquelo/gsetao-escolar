<?php
session_start();
require '../Config/conexaoBD.php';

$id_curso = $_GET['id_curso'];
$query4 = "SELECT id_turma, nome FROM turmas WHERE id_curso = ?";
$stmt = $conn->prepare($query4);
$stmt->bind_param("i", $id_curso);
$stmt->execute();

$result = $stmt->get_result();
$turma = $result->fetch_all(MYSQLI_ASSOC);

echo json_encode($turma);

?>