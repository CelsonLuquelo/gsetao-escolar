<?php
session_start();
include 'conexaoBD.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $curso = $_POST['curso'];
    $valorProprina = $_POST['ValorProprina'];
try{    
      // Busca os dados atuais do sistema
      $sql = "SELECT ano FROM anolectivo WHERE id = 1";
      $result = $conn->prepare($sql);
      $result->execute();
      $dados = $result->get_result();
      $anolectivoArray=$dados->fetch_assoc();
 
      $anolectivo = $anolectivoArray['ano'];

    $query = "INSERT INTO cursos (curso, valor_proprina, ano)
              VALUES (?, ?, $anolectivo)";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $curso, $valorProprina);
    $stmt->execute();

    $_SESSION['notification'] = "Curso cadastrado com sucesso.";
    
    header("Location: ../HtPags/Cursos.php");

    
    
}catch(Exception $ex){
        $_SESSION['notification'] = "Erro ao cadastar curso.";
        $_SESSION['estado'] = "erro";
        header("Location: ../HtPags/Cursos.php");
        exit();
    }
}
?>