<?php
require 'conexaoBD.php';

session_start();

$id = $_GET['id_aluno'] ?? '';

$sql = "SELECT id_mes FROM pagamentos WHERE id_aluno = ? AND status = 'pago' ORDER BY id_pagamento DESC LIMIT 1";
$stmt= $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();
$mes = $result->fetch_all(MYSQLI_ASSOC);
$row = [];
foreach($mes as $me){
  $row[] = $mes;
}
echo json_encode($mes);

?>