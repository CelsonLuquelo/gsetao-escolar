<?php

session_start();
require 'conexaoBD.php';

// Processa formulário de cadastro ou edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';
    $senha = password_hash($_POST['senha'], PASSWORD_BCRYPT);
    $nivel_acesso = $_POST['nivel_acesso'];

    try{
        if (isset($_POST['id_usuario']) && $_POST['id_usuario'] !== '') {
            // Atualizar usuário existente
            $id_usuario = $_POST['id_usuario'];
            $stmt = $pdo->prepare("UPDATE usuarios SET nome = :nome, email = :email, nivel_acesso = :nivel_acesso WHERE id_usuario = :id");
            $stmt->execute([':nome' => $nome, ':email' => $email, ':nivel_acesso' => $nivel_acesso, ':id' => $id_usuario]);
            $_SESSION['notification'] = "Usuário atualizado com sucesso!, $nome";
            $_SESSION['estado'] = "sucesso";
        }else{
            $_SESSION['notification'] = "Erro ao actualizar perfil do $nome";
            $_SESSION['estado'] = "erro";
        }
    }
    catch(Exception $ex){
        $_SESSION['notification'] = "Erro ao actualizar perfil do $ex";
        $_SESSION['estado'] = "erro";
    }
    header("Location: ../HtPags/gerenciarPerfil.php");
    exit();
}


?>