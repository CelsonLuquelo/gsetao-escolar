-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 05/05/2025 às 16:12
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `gestao_escolar`
--
CREATE DATABASE IF NOT EXISTS `gestao_escolar` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `gestao_escolar`;

-- --------------------------------------------------------

--
-- Estrutura para tabela `alunos`
--

CREATE TABLE `alunos` (
  `id_aluno` int(11) NOT NULL,
  `nome` varchar(300) NOT NULL,
  `matricula` varchar(200) NOT NULL DEFAULT '0000',
  `idade` int(11) NOT NULL,
  `morada` varchar(250) NOT NULL,
  `numero_encarregado` int(9) NOT NULL,
  `foto` varchar(255) NOT NULL DEFAULT 'defalt.png',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `BI` varchar(20) NOT NULL,
  `id_curso` int(11) NOT NULL,
  `id_turma` int(11) NOT NULL,
  `data_nascimento` date NOT NULL,
  `id_classe` int(11) NOT NULL,
  `ano` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `anolectivo`
--

CREATE TABLE `anolectivo` (
  `id` int(11) NOT NULL,
  `ano` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `anolectivo`
--

INSERT INTO `anolectivo` (`id`, `ano`) VALUES
(1, 2024);

-- --------------------------------------------------------

--
-- Estrutura para tabela `certificado`
--

CREATE TABLE `certificado` (
  `id_certificado` int(11) NOT NULL,
  `status` enum('pago','pendente') NOT NULL,
  `total_pago` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `classe`
--

CREATE TABLE `classe` (
  `id_classe` int(11) NOT NULL,
  `nome` varchar(10) NOT NULL,
  `valor_percentual` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `classe`
--

INSERT INTO `classe` (`id_classe`, `nome`, `valor_percentual`) VALUES
(1, '10', 5),
(2, '11', 10),
(3, '12', 15),
(4, '13', 20);

-- --------------------------------------------------------

--
-- Estrutura para tabela `cursos`
--

CREATE TABLE `cursos` (
  `id_curso` int(11) NOT NULL,
  `curso` varchar(300) NOT NULL,
  `valor_proprina` int(11) NOT NULL,
  `ano` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `cursos`
--

INSERT INTO `cursos` (`id_curso`, `curso`, `valor_proprina`, `ano`) VALUES
(13, 'Contabilidade de gestão', 12000, 2024),
(14, 'Informatica de gestão', 13000, 2024),
(15, 'Gestão Empresarial', 12000, 2024);

-- --------------------------------------------------------

--
-- Estrutura para tabela `declaracao`
--

CREATE TABLE `declaracao` (
  `id_declaracao` int(11) NOT NULL,
  `status` enum('pago','pendente') NOT NULL DEFAULT 'pendente',
  `total_pago` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `estagio`
--

CREATE TABLE `estagio` (
  `id_estagio` int(11) NOT NULL,
  `status` enum('pago','pendente') NOT NULL DEFAULT 'pendente',
  `tipo` enum('Interno','Externo') NOT NULL DEFAULT 'Interno',
  `total_pago` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `facturas`
--

CREATE TABLE `facturas` (
  `id_factura` int(11) NOT NULL,
  `id_aluno` int(11) NOT NULL,
  `id_pagamento` int(11) NOT NULL,
  `ano` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `informacoes_basicas`
--

CREATE TABLE `informacoes_basicas` (
  `id` int(11) NOT NULL,
  `IBAN` varchar(500) NOT NULL,
  `NIF` varchar(500) NOT NULL,
  `Contactos` varchar(500) NOT NULL,
  `multa_percentual` int(11) NOT NULL,
  `valor_Matricula` int(11) NOT NULL,
  `valor_uniforme` int(11) NOT NULL,
  `valor_cartao` int(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `valor_estagio` int(11) NOT NULL,
  `valor_declaracao` int(11) NOT NULL,
  `valor_certificado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `informacoes_basicas`
--

INSERT INTO `informacoes_basicas` (`id`, `IBAN`, `NIF`, `Contactos`, `multa_percentual`, `valor_Matricula`, `valor_uniforme`, `valor_cartao`, `email`, `valor_estagio`, `valor_declaracao`, `valor_certificado`) VALUES
(1, '0286267262762762', '18871892986198', '923533833', 10, 12000, 10000, 500, 'celsonclever4@gmail.com', 20000, 7000, 12000);

-- --------------------------------------------------------

--
-- Estrutura para tabela `meses`
--

CREATE TABLE `meses` (
  `id` int(11) NOT NULL,
  `mes` varchar(50) NOT NULL,
  `data` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `meses`
--

INSERT INTO `meses` (`id`, `mes`, `data`) VALUES
(1, 'Janeiro', '2025-01-01'),
(2, 'Fevereiro', '2025-02-01'),
(3, 'Março', '2025-03-01'),
(4, 'Abril', '2025-04-01'),
(5, 'Maio', '2025-05-01'),
(6, 'Junho', '2025-06-01'),
(7, 'Julho', '2025-07-01'),
(8, 'Agosto', '2025-08-01'),
(9, 'Setembro', '2024-09-01'),
(10, 'Outubro', '2024-10-01'),
(11, 'Novembro', '2024-11-01'),
(12, 'Dezembro', '2024-12-01');

-- --------------------------------------------------------

--
-- Estrutura para tabela `outros_pagamentos`
--

CREATE TABLE `outros_pagamentos` (
  `id_ouPagamento` int(11) NOT NULL,
  `id_certificado` int(11) NOT NULL,
  `id_declaracao` int(11) NOT NULL,
  `id_estagio` int(11) NOT NULL,
  `id_aluno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `pagamentos`
--

CREATE TABLE `pagamentos` (
  `id_pagamento` int(11) NOT NULL,
  `id_aluno` int(11) NOT NULL,
  `mes` varchar(100) NOT NULL,
  `ano` int(11) NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `multa` decimal(10,2) NOT NULL,
  `desconto` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `status` enum('pago','pendente') NOT NULL DEFAULT 'pendente',
  `id_mes` int(11) NOT NULL,
  `data_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `turmas`
--

CREATE TABLE `turmas` (
  `id_turma` int(11) NOT NULL,
  `id_curso` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `turno` varchar(20) NOT NULL,
  `sala` int(11) NOT NULL,
  `limite_aluno` int(11) NOT NULL DEFAULT 40,
  `id_classe` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `senha` varchar(200) NOT NULL,
  `nivel_acesso` enum('Administrador','secretario') NOT NULL DEFAULT 'secretario'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nome`, `email`, `senha`, `nivel_acesso`) VALUES
(5, 'Celson Luquelo', 'celsonclever3@gmail.com', '$2y$10$GGzCFLe8gv5p8xUsxDT0hepjiuf9D4WR.levrZCi4xSQqh0bbvk.i', 'Administrador'),
(7, 'Celson Luquelo', 'celsonclever4@gmail.com', '$2y$10$tASB2gqKJzZomh6/vRrm6.cCJYuQqdQViycEw.XilZhwdHGAFw8T6', 'secretario');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `alunos`
--
ALTER TABLE `alunos`
  ADD PRIMARY KEY (`id_aluno`),
  ADD UNIQUE KEY `numero_encarregado` (`numero_encarregado`,`BI`),
  ADD KEY `alunos_ibfk_1` (`id_classe`),
  ADD KEY `alunos_ibfk_2` (`id_curso`),
  ADD KEY `alunos_ibfk_3` (`id_turma`);

--
-- Índices de tabela `anolectivo`
--
ALTER TABLE `anolectivo`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `certificado`
--
ALTER TABLE `certificado`
  ADD PRIMARY KEY (`id_certificado`);

--
-- Índices de tabela `classe`
--
ALTER TABLE `classe`
  ADD PRIMARY KEY (`id_classe`);

--
-- Índices de tabela `cursos`
--
ALTER TABLE `cursos`
  ADD PRIMARY KEY (`id_curso`);

--
-- Índices de tabela `declaracao`
--
ALTER TABLE `declaracao`
  ADD PRIMARY KEY (`id_declaracao`);

--
-- Índices de tabela `estagio`
--
ALTER TABLE `estagio`
  ADD PRIMARY KEY (`id_estagio`);

--
-- Índices de tabela `facturas`
--
ALTER TABLE `facturas`
  ADD PRIMARY KEY (`id_factura`),
  ADD KEY `facturas_ibfk_1` (`id_aluno`),
  ADD KEY `facturas_ibfk_2` (`id_pagamento`);

--
-- Índices de tabela `informacoes_basicas`
--
ALTER TABLE `informacoes_basicas`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `meses`
--
ALTER TABLE `meses`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `outros_pagamentos`
--
ALTER TABLE `outros_pagamentos`
  ADD PRIMARY KEY (`id_ouPagamento`),
  ADD KEY `id_aluno` (`id_aluno`),
  ADD KEY `id_certificado` (`id_certificado`),
  ADD KEY `outros_pagamentos_ibfk_4` (`id_estagio`),
  ADD KEY `id_declaracao` (`id_declaracao`);

--
-- Índices de tabela `pagamentos`
--
ALTER TABLE `pagamentos`
  ADD PRIMARY KEY (`id_pagamento`),
  ADD KEY `pagamentos_ibfk_1` (`id_aluno`);

--
-- Índices de tabela `turmas`
--
ALTER TABLE `turmas`
  ADD PRIMARY KEY (`id_turma`),
  ADD KEY `id_curso` (`id_curso`),
  ADD KEY `id_classe` (`id_classe`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `alunos`
--
ALTER TABLE `alunos`
  MODIFY `id_aluno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT de tabela `anolectivo`
--
ALTER TABLE `anolectivo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `certificado`
--
ALTER TABLE `certificado`
  MODIFY `id_certificado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT de tabela `classe`
--
ALTER TABLE `classe`
  MODIFY `id_classe` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `cursos`
--
ALTER TABLE `cursos`
  MODIFY `id_curso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de tabela `declaracao`
--
ALTER TABLE `declaracao`
  MODIFY `id_declaracao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT de tabela `estagio`
--
ALTER TABLE `estagio`
  MODIFY `id_estagio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT de tabela `facturas`
--
ALTER TABLE `facturas`
  MODIFY `id_factura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT de tabela `informacoes_basicas`
--
ALTER TABLE `informacoes_basicas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `meses`
--
ALTER TABLE `meses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `outros_pagamentos`
--
ALTER TABLE `outros_pagamentos`
  MODIFY `id_ouPagamento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `pagamentos`
--
ALTER TABLE `pagamentos`
  MODIFY `id_pagamento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=196;

--
-- AUTO_INCREMENT de tabela `turmas`
--
ALTER TABLE `turmas`
  MODIFY `id_turma` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `alunos`
--
ALTER TABLE `alunos`
  ADD CONSTRAINT `alunos_ibfk_1` FOREIGN KEY (`id_classe`) REFERENCES `classe` (`id_classe`) ON UPDATE CASCADE,
  ADD CONSTRAINT `alunos_ibfk_2` FOREIGN KEY (`id_curso`) REFERENCES `cursos` (`id_curso`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `alunos_ibfk_3` FOREIGN KEY (`id_turma`) REFERENCES `turmas` (`id_turma`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para tabelas `facturas`
--
ALTER TABLE `facturas`
  ADD CONSTRAINT `facturas_ibfk_1` FOREIGN KEY (`id_aluno`) REFERENCES `alunos` (`id_aluno`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `facturas_ibfk_2` FOREIGN KEY (`id_pagamento`) REFERENCES `pagamentos` (`id_pagamento`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para tabelas `outros_pagamentos`
--
ALTER TABLE `outros_pagamentos`
  ADD CONSTRAINT `outros_pagamentos_ibfk_1` FOREIGN KEY (`id_aluno`) REFERENCES `alunos` (`id_aluno`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `outros_pagamentos_ibfk_2` FOREIGN KEY (`id_certificado`) REFERENCES `certificado` (`id_certificado`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `outros_pagamentos_ibfk_4` FOREIGN KEY (`id_estagio`) REFERENCES `estagio` (`id_estagio`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `outros_pagamentos_ibfk_5` FOREIGN KEY (`id_declaracao`) REFERENCES `declaracao` (`id_declaracao`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para tabelas `pagamentos`
--
ALTER TABLE `pagamentos`
  ADD CONSTRAINT `pagamentos_ibfk_1` FOREIGN KEY (`id_aluno`) REFERENCES `alunos` (`id_aluno`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para tabelas `turmas`
--
ALTER TABLE `turmas`
  ADD CONSTRAINT `turmas_ibfk_1` FOREIGN KEY (`id_curso`) REFERENCES `cursos` (`id_curso`),
  ADD CONSTRAINT `turmas_ibfk_2` FOREIGN KEY (`id_classe`) REFERENCES `classe` (`id_classe`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
